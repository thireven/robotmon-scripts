// Converted from index.js - TypeScript port.
"use strict";
// Named `TsumTaskController` rather than `TaskController` to avoid colliding
// with the DOM lib's built-in `TaskController` (Prioritized Task Scheduling
// API) that ships in lib.dom.d.ts.
var TsumTaskController = /** @class */ (function () {
    function TsumTaskController() {
        this.tasks = {};
        this.isRunning = false;
        this.interval = 200;
        this.errorCount = 0;
    }
    // Pick the highest-priority task that is due to run again. Among due tasks,
    // lower `priority` wins; ties break toward the larger interval, then the
    // least-recently-run task. Returns "" when nothing is due.
    TsumTaskController.prototype.getFirstPriorityTaskName = function () {
        var best = null;
        var now = Date.now();
        for (var name_1 in this.tasks) {
            var task = this.tasks[name_1];
            if (now - task.lastRunTime < task.interval) {
                continue;
            }
            if (best !== null) {
                if (task.priority < best.priority) {
                    best = task;
                }
                else if (task.interval > best.interval) {
                    best = task;
                }
                else if (task.lastRunTime < best.lastRunTime) {
                    best = task;
                }
            }
            else {
                best = task;
            }
        }
        return best === null ? "" : best.name;
    };
    TsumTaskController.prototype.loop = function () {
        console.log("loop start");
        while (this.isRunning) {
            var name_2 = this.getFirstPriorityTaskName();
            var task = this.tasks[name_2];
            if (task !== undefined) {
                // Layer 1: swallow uncaught errors so one bad task can't kill the whole
                // controller. A run of consecutive errors bounces the game app.
                try {
                    task.run();
                    this.errorCount = 0;
                }
                catch (e) {
                    this.errorCount++;
                    log("[Watchdog] task '" + name_2 + "' threw (" + this.errorCount + "): " + e);
                    if (this.errorCount >= 5) {
                        log("[Watchdog] 5 consecutive errors, restarting Tsum app");
                        try {
                            ts.taskTsumAppRestart();
                        }
                        catch (e2) {
                            log("[Watchdog] restart failed: " + e2);
                        }
                        this.errorCount = 0;
                    }
                }
                task.lastRunTime = Date.now();
                task.runTimes--;
                if (task.runTimes === 0) {
                    delete this.tasks[name_2];
                }
            }
            sleep(this.interval);
        }
        this.isRunning = false;
        console.log("loop stop");
    };
    TsumTaskController.prototype.updateRunInterval = function (interval) {
        if (interval < this.interval && interval >= 50) {
            this.interval = interval;
        }
    };
    TsumTaskController.prototype.newTaskObject = function (name, run, interval, runTimes, priority) {
        return {
            name: name,
            run: run,
            interval: interval || 1000,
            runTimes: runTimes || 0,
            priority: priority,
            lastRunTime: 0,
            status: 0
        };
    };
    TsumTaskController.prototype.newTask = function (name, run, interval, runTimes, runOnce) {
        if (runOnce === undefined) {
            runOnce = false;
        }
        if (typeof run === "function") {
            var task_1 = this.newTaskObject(name, run, interval, runTimes, 0);
            if (runOnce) {
                task_1.lastRunTime = Date.now();
            }
            this.updateRunInterval(task_1.interval);
            var systemName = "system_newTask_" + name;
            var self_1 = this;
            var systemTask = this.newTaskObject(systemName, function () { self_1.tasks[name] = task_1; }, 0, 1, -20);
            this.tasks[systemName] = systemTask;
            return task_1;
        }
        console.log("Error not a function", name, run);
        return undefined;
    };
    TsumTaskController.prototype.removeTask = function (name) {
        var systemName = "system_removeTask_" + Date.now().toString();
        var self = this;
        var systemTask = this.newTaskObject(systemName, function () { delete self.tasks[name]; }, 0, 1, -20);
        this.tasks[systemName] = systemTask;
    };
    TsumTaskController.prototype.removeAllTasks = function () {
        var systemName = "system_removeAllTask_" + Date.now().toString();
        var self = this;
        var systemTask = this.newTaskObject(systemName, function () {
            for (var key in self.tasks) {
                delete self.tasks[key];
            }
        }, 0, 1, -20);
        this.tasks[systemName] = systemTask;
    };
    TsumTaskController.prototype.start = function () {
        if (!this.isRunning) {
            this.isRunning = true;
            this.loop();
        }
    };
    TsumTaskController.prototype.stop = function () {
        if (this.isRunning) {
            this.isRunning = false;
            console.log("wait loop stop...");
        }
    };
    return TsumTaskController;
}());
// The two script-wide globals. Declared here rather than in globals.d.ts
// because they are real `var`s in the bundle, not ambient declarations.
//
// Both are `undefined` before start() and again after stop() clears them, which
// is why the type says so: log() runs on both sides of that window and already
// guards, and the guards are now checked rather than merely conventional.
var ts;
var gTaskController;
// Utils
/**
 * Per-channel distance. A missing channel yields NaN, which is deliberate and
 * relied upon by both callers below -- see the note on `ColorLike`. The `!`s
 * say "undefined is possible here and NaN is the intended result", not "this
 * can never be undefined".
 */
function channelDiff(a, b) {
    return Math.abs(a - b);
}
function isSameColor(c1, c2, diff) {
    if (diff === undefined) {
        diff = 20;
    }
    return channelDiff(c1.r, c2.r) <= diff
        && channelDiff(c1.g, c2.g) <= diff
        && channelDiff(c1.b, c2.b) <= diff;
}
function absColor(c1, c2) {
    return channelDiff(c1.r, c2.r) + channelDiff(c1.g, c2.g) + channelDiff(c1.b, c2.b);
}
function nowTime() {
    var offset = (new Date().getTimezoneOffset()) * 60 * 1000;
    return Date.now() + offset;
}
function debug() {
    var parts = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        parts[_i] = arguments[_i];
    }
    if (Config.debugLogs) {
        var newArgs = ['*DEBUG*'];
        log.apply(null, newArgs.concat(parts));
    }
}
function log() {
    var parts = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        parts[_i] = arguments[_i];
    }
    sleep(10);
    var args = [];
    if (ts !== undefined && ts.showHeartLog && ts.record && ts.record["hearts_count" /* RecordKey.HeartsCount */]) {
        var msg = "";
        msg += "R:" + ts.record["hearts_count" /* RecordKey.HeartsCount */].receivedCount + " ";
        msg += "S:" + ts.record["hearts_count" /* RecordKey.HeartsCount */].sentCount;
        if (gTaskController !== undefined && gTaskController.tasks !== undefined) {
            var sendTask = gTaskController.tasks["sendHearts"];
            if (sendTask !== undefined) {
                if (sendTask.lastRunTime === 0) {
                    msg += "/0";
                }
                else {
                    var next = (nowTime() - (sendTask.lastRunTime + sendTask.interval)) / 60000;
                    msg += "/" + (+next.toFixed(0));
                }
            }
        }
        args.push("[" + msg + "]");
    }
    for (var i = 0; i < parts.length; i++) {
        var part = parts[i];
        if (typeof part == 'object') {
            part = JSON.stringify(part, null, 2);
        }
        else if (typeof part == 'function') {
            if (Config.debugLogs)
                part = part();
            else
                part = "";
        }
        args.push(part);
    }
    console.log.apply(console, args);
}
// ============================TSUM=============================== //
var Config = {
    recordDir: 'tsum_record',
    tsumWidth: 16,
    tsumBoundW: 13, // tsumWidth / 2 + 2
    tsumBoundH: 13,
    screenResize: 200,
    gameContinueDelay: 400,
    colors: [[255, 0, 0], [0, 255, 0], [0, 0, 255], [0, 255, 255], [255, 0, 255]],
    // Longest chain the board scan may return, as TsumBeta ("Maximum Chain
    // Number", 3-15). 0 is not reachable from the settings UI and is treated as
    // "no limit" so a config written before this setting existed still runs.
    maxChain: 3,
    debugLogs: false
};
// Top of the square play area in logical coordinates. The board occupies the
// 1080x1080 square below this line; everything above is score/timer chrome.
var PlayAreaTopY = 465;
// --- Tiara Minnie+ ------------------------------------------------------
//
// Her skill shows Minnie with a thought bubble containing one present, then a
// screen of presents to pick the matching one from. The bubble appears once per
// activation and is not shown again, so an activation is exactly one pick. A
// correct one adds a present to the next activation's screen (2 up to 6); a
// wrong one resets it to 2 -- which is why every layout has to be handled, but
// also why the count never needs to be tracked between activations.
//
// The presents always land on the same centres for a given count, so there is
// nothing to search for: crop each known centre, crop the bubble, and compare
// the pictures directly. Centres are logical 1080x1920 and were read off the
// reference frames in ../com.r2studio.TsumThi/doc/screenshots/TiaraMinnie/
// (2..6.png; blob centres agreed within ~20px).
var TiaraLayouts = {
    2: [{ x: 292, y: 973 }, { x: 781, y: 1059 }],
    3: [{ x: 781, y: 829 }, { x: 666, y: 1275 }, { x: 306, y: 987 }],
    4: [{ x: 292, y: 1232 }, { x: 263, y: 829 }, { x: 796, y: 757 }, { x: 796, y: 1117 }],
    5: [{ x: 234, y: 1117 }, { x: 882, y: 1102 }, { x: 292, y: 771 }, { x: 839, y: 742 },
        { x: 551, y: 1304 }],
    6: [{ x: 752, y: 757 }, { x: 378, y: 728 }, { x: 176, y: 973 }, { x: 896, y: 1001 },
        { x: 349, y: 1232 }, { x: 680, y: 1261 }]
};
// Presents shrink as more of them appear; these are the crop sides that put the
// present in the same fraction of the frame at every count (measured widths ran
// 270/275/252/237/237 for counts 2..6).
var TiaraSlotSide = {
    2: 300, 3: 295, 4: 280, 5: 265, 6: 260
};
var TiaraMinnieConfig = {
    // Resolution the play square is captured at for matching.
    //
    // Was briefly dropped to 300 for speed on the strength of the offline sweep
    // finding 270-720 all scoring 20/20 -- and wrong taps appeared on the device.
    // Do not lower it again without re-running the harness: the sweep varied this
    // alone against static frames, which is not the same claim as "300 is safe",
    // and a cell is only ~5.6 capture pixels wide there, so cell centres snap to
    // the grid with a tenth of a cell of error and the blur has less to work with.
    captureSize: 420,
    // Blur radius, in capture pixels, that makes one pixel read stand in for the
    // average of its cell -- so it has to stay in proportion to captureSize.
    captureBlur: 7,
    // The thought bubble is drawn at a fixed spot, so the template is a fixed
    // crop -- no searching. Verified at (250..255, 870..875) on every dream frame
    // where the present could be isolated, and +/-16px of error still ranked the
    // right present first.
    bubbleX: 252,
    bubbleY: 872,
    bubbleSide: 240,
    // Cloud test, used to tell "bubble is up" from "presents are up" and from
    // "the skill is over". Measured 0.484-0.503 on bubble frames vs 0.019-0.060
    // on present frames, so the threshold sits in a very wide gap.
    cloudBox: { x0: 60, y0: 690, x1: 450, y1: 1050 },
    cloudSatMax: 70,
    cloudValMin: 180,
    // Sample spacing inside the box, leaving 162 samples.
    //
    // Was briefly 40 (64 samples). The gap between a bubble frame and a present
    // frame is wide enough for that, but the fraction is also read *during* the
    // bubble's fade, where the true value passes through the threshold: at 64
    // samples the standard error there is 0.06, so a mid-fade reading can call
    // the cloud gone early, and matching then starts on the hand-over frames.
    // The sample count is not really buying precision at the extremes, it is
    // buying it in the middle.
    cloudStep: 24,
    cloudMinFrac: 0.25,
    // This test is polled in a loop, and it is only asking whether a big pale
    // blob is present, so it gets its own small capture with no blur. At the
    // matching resolution each check cost a 420x420 grab plus a 7px blur, which
    // made the poll slower than the interval it was polling on.
    //
    // This is the resolution the whole play square would be captured at; only
    // cloudBox is actually grabbed, scaled to match. Nothing outside the box is
    // ever read, so capturing the rest of the board was pure overhead.
    cloudCaptureSize: 120,
    // Comparison grid. Each crop is reduced to grid x grid cells; cells are
    // compared only where the template says the present is, which drops the board
    // background (dark tsums) and the bubble background (white cloud) alike.
    // 10 through 20 all scored the same offline, so this is the cheap end of the
    // range that still held up: 12x12 cells over 20 candidates is 2880 reads.
    grid: 12,
    satMin: 70,
    valMin: 170,
    // Per-cell differences are divided by this and clipped at 1, so the score
    // counts clearly-disagreeing cells instead of averaging away small ones.
    // Raised the worst-case margin from 0.095 to 0.264 against the same frames.
    cellSpread: 0.30,
    // A tap needs both of these. The score alone cannot say whether the presents
    // are up yet: a green template scores 0.461 against ordinary green tsums, so
    // a board with no presents on it would clear any floor low enough to keep the
    // real matches (which fall to ~0.44 if the presents are 10px off the table).
    //
    // The margin does separate the two, because bare board has no standout winner
    // -- it reached 0.096 at best, where a real choice screen never scored under
    // 0.278. So the floor rejects noise and the margin proves a present is there.
    confidenceFloor: 0.42,
    marginFloor: 0.12,
    // Tapping a present detonates an area of the board, so the blast wants a full,
    // still board under it. The play loop clears a chain immediately before the
    // skill fires (and may have just used the fan), so at activation the tsums are
    // almost always mid-fall and a blast then catches very few of them.
    //
    // How long that takes varies with how much was cleared, so it is measured
    // rather than guessed: take a coarse brightness fingerprint of the board twice
    // and watch how much it changes. Falling tsums move it a lot, a settled board
    // barely at all (only sparkles and the fever glow).
    //
    // For scale, that measure is 0 between identical frames, ~0.06 between two
    // frames of a similar scene, and 0.20-0.30 between wholly different screens.
    // settleMaxDiff is the one number here not pinned down by measurement -- there
    // were no consecutive-frame pairs to calibrate falling tsums against -- so it
    // is set loose rather than tight: too strict just means every activation waits
    // out settleWaitMs, which is the delay this was added to avoid. The timeout
    // logs the diff it actually saw, which is what to tune from.
    settleWaitMs: 320,
    settleMinMs: 60,
    settlePollMs: 30,
    settleCapture: 64,
    settleGrid: 16,
    settleMaxDiff: 0.03,
    settleQuietScans: 2,
    // Timings. The bubble is shown once, ~2s after the skill fires, and the
    // presents ~1s after that. The game timer is stopped while the presents are
    // up, so the checks made there are free; everything before them costs real
    // game time, which is what these two are sized against.
    //
    // Nothing can happen until the skill animation has played, so sit that out
    // rather than spending ~15 screenshots polling for something that cannot have
    // happened yet.
    dreamLeadMs: 1500,
    // Covers the lead plus a bubble arriving late. Only ever spent in full when
    // the skill did not actually fire.
    dreamWaitMs: 3000,
    dreamSettleMs: 250,
    // After the bubble clears, the presents take about a second to arrive. Waiting
    // most of that out first means the matcher never sees the hand-over frames.
    //
    // This lead and pollMs have to be read together: matching starts at (however
    // late the poll noticed the cloud go) + this. Trading one against the other
    // by their averages is what caused wrong taps -- pollMs 100->200 raises the
    // mean lag by 50ms but the *minimum* stays 0, so taking 100ms off this lead
    // moved the earliest possible start from 500ms to 400ms after the bubble
    // cleared. It is the earliest start that decides whether the matcher can see
    // a present still sliding into place, and a present caught in transit can sit
    // convincingly on a centre belonging to another layout.
    choiceLeadMs: 500,
    choiceWaitMs: 6000,
    pollMs: 100,
    // The matching loop keeps its own interval: it is not waiting on a known
    // animation but on the presents becoming readable, and it leaves the moment
    // two scans agree, so a slower cadence here would just delay the tap.
    matchPollMs: 100,
    agreeScans: 2,
    pickTaps: 2,
    pickTapDuring: 60,
    pickTapGapMs: 50
};
// --- Game bubbles -------------------------------------------------------
//
// Tiara Minnie+ makes a bubble popped as a chain goes off clear a bigger area,
// so bubbles are worth tapping the instant a long chain lands rather than on
// the play loop's periodic sweep (which is ~50 blind taps and far too slow to
// land inside a chain).
//
// A bubble is a circle like a tsum, only much bigger, so it falls out of the
// same grayscale Hough pass findTsums already runs -- on the capture the scan
// already took, which is what makes locating them cost nothing extra.
var GameBubbleConfig = {
    // Circle geometry in the 200px play-square space findTsums works in, where a
    // tsum is radius 8-14.
    //
    // NOT YET CALIBRATED: there is no saved frame with a bubble on the board to
    // measure against, so this range is reasoned from a bubble being noticeably
    // larger than a tsum, not measured. Getting it wrong costs stray taps on bare
    // board, which the game ignores -- a tap is not a drag, so nothing links.
    minRadius: 16,
    maxRadius: 30,
    minDist: 30,
    param1: 20,
    param2: 26,
    // Chain length that earns a pop, and a cap so a frame full of false circles
    // cannot turn into a long burst of taps mid-chain.
    minChainForPop: 4,
    maxTaps: 3,
    tapDuring: 10
};
var Button = {
    gameBubblesFrom: { x: 100, y: 632 },
    gameBubblesTo: { x: 1000, y: 1532 },
    gameQuestionCancel: { x: 400, y: 1352 },
    gameQuestionCancel2: { x: 400, y: 1072 },
    gameStop: { x: 440, y: 1072 },
    gameSkill1: { x: 160, y: 1702 },
    gameSkill2: { x: 95, y: 1702 },
    gameRand: { x: 985, y: 1652, color: { "a": 0, "b": 6, "g": 180, "r": 232 } },
    gamePause: { x: 983, y: 322, color: { "a": 0, "b": 9, "g": 188, "r": 239 } },
    gameContinue: { x: 540, y: 1342, color: { "a": 0, "b": 13, "g": 175, "r": 240 } },
    // The seven bonus-item toggles on the pre-game screen, in screen order.
    //
    // Positional: checkGameItem() walks this alongside an `isItemsOn` array built
    // in the same order, so index 5 meaning "5>4" is load-bearing and was only
    // ever recorded in these comments. The labelled tuple puts it in the type,
    // and fixes the length -- adding an eighth toggle here without updating
    // checkGameItem is now a build error rather than a silently ignored item.
    outGameItems: [
        { x: 205, y: 889 }, // +Score
        { x: 435, y: 893 }, // +Coin
        { x: 651, y: 889 }, // +Exp
        { x: 871, y: 893 }, // +Time
        { x: 201, y: 1167 }, // +Bubble
        { x: 424, y: 1170 }, // 5>4
        { x: 610, y: 1175 } // +Combo
    ],
    outStart: { x: 500, y: 1592, color: { "a": 0, "b": 129, "g": 111, "r": 236 } }, // 開始
    outClose: { x: 500, y: 1592, color: { "a": 0, "b": 7, "g": 180, "r": 236 } }, // 關閉
    outReceive: { x: 910, y: 422 },
    outReceiveAll: { x: 800, y: 1422 },
    outReceiveOk: { x: 835, y: 1092, color: { "a": 0, "b": 6, "g": 175, "r": 236 } },
    outReceiveAllHeartsDisabledJP: { x: 679, y: 880, color: { "a": 0, "b": 214, "g": 129, "r": 41 } },
    outReceiveAllRubiesEnabledJP: { x: 261, y: 705, color: { "a": 0, "b": 33, "g": 178, "r": 247 } },
    outReceiveAllOkJP: { x: 835, y: 1258, color: { "a": 0, "b": 6, "g": 175, "r": 236 } },
    outReceiveItemSetOk: { x: 830, y: 1260, color: { "a": 0, "b": 8, "g": 176, "r": 238 } },
    outReceiveClose: { x: 530, y: 1372 },
    outReceiveOneBase: { y: 569 },
    outReceiveOne: { x: 840, color: { "a": 0, "b": 30, "g": 181, "r": 235 }, color2: { "a": 0, "b": 119, "g": 74, "r": 40 } },
    outReceiveOneRubyBase: { y: 651 }, // ruby
    outReceiveOneRuby: { x: 295, color: { r: 224, g: 93, b: 101 } }, // ruby
    outReceiveOneAdBase: { y: 672 }, // ad
    outReceiveOneAd: { x: 290, color: { r: 90, g: 57, b: 25 } }, // ad
    outReceiveTimeout: { x: 600, y: 1092, color: { "a": 0, "b": 11, "g": 171, "r": 235 } },
    outSendHeartTop: { x: 910, y: 502 },
    outSendHeart0: { x: 910, y: 698, color: { "a": 0, "b": 142, "g": 60, "r": 209 }, color2: { "a": 0, "b": 140, "g": 65, "r": 3 } },
    outSendHeart1: { x: 910, y: 895, color: { "a": 0, "b": 142, "g": 60, "r": 209 }, color2: { "a": 0, "b": 140, "g": 65, "r": 3 } },
    outSendHeart2: { x: 910, y: 1102, color: { "a": 0, "b": 142, "g": 60, "r": 209 }, color2: { "a": 0, "b": 140, "g": 65, "r": 3 } },
    outSendHeart3: { x: 910, y: 1304, color: { "a": 0, "b": 142, "g": 60, "r": 209 }, color2: { "a": 0, "b": 140, "g": 65, "r": 3 } },
    outSendHeartBottom: { x: 910, y: 1500 },
    outSendHeartClose: { x: 666, y: 1426, color: { r: 236, g: 178, b: 9 } },
    outSendHeartFrom: { x: 910, y: 602 },
    outSendHeartTo: { x: 910, y: 1322 },
    outSendHeartEnd: { x: 328, y: 1266, color: { "a": 0, "b": 132, "g": 85, "r": 47 } },
    outSendHeartEnd2: { x: 227, y: 1262, color: { "a": 0, "b": 123, "g": 78, "r": 44 } },
    outSendHeartEnd3: { x: 316, y: 1224, color: { r: 55, g: 91, b: 139 } },
    outFriendScoreFrom: { x: 550, y: 935, color: { "a": 0, "b": 140, "g": 93, "r": 55 } },
    outFriendScoreTo: { x: 760, y: 935 },
    outHomePage: { x: 60, y: 1000 },
    outFriendPage: { x: 60, y: 1130 },
    skillLuke1: { x: 1000, y: 1372 },
    skillLuke2: { x: 830, y: 1402 },
    skillLuke3: { x: 670, y: 1447 },
    skillLuke4: { x: 960, y: 1232 },
    skillCptLy1: { x: 670, y: 1050 },
    skillCptLy2: { x: 310, y: 1050 },
    skillCptLy3: { x: 540, y: 414 },
    outReceiveNameFromBase: { y: 532 },
    outReceiveNameFrom: { x: 150 },
    outReceiveNameToBase: { y: 670 },
    outReceiveNameTo: { x: 660 },
    moneyInfoBox: { x: 430, y: 188, w: 230, h: 56 },
    outOpenTsumCollectionOrder: { x: 983, y: 890, r: 165, g: 85, b: 49 },
    outCloseTsumCollectionOrderOld: { x: 552, y: 1365, r: 247, g: 174, b: 8 },
    outTsumCollectionOrderByReleaseDateOld: { name: 'By Release Date', x: 331, y: 774, r: 247, g: 178, b: 8 },
    outTsumCollectionOrderFavoritesOld: { name: 'By Favorites', x: 765, y: 769, r: 247, g: 174, b: 8 },
    outTsumCollectionOrderBySkillOld: { name: 'By Skill', x: 310, y: 988, r: 247, g: 174, b: 8 },
    outTsumCollectionOrderByLevelLockOld: { name: 'By Level Lock', x: 766, y: 984, r: 247, g: 174, b: 8 },
    outCloseTsumCollectionOrderNew: { x: 552, y: 1585, r: 247, g: 185, b: 8 },
    outTsumCollectionOrderByReleaseDateNew: { name: 'By Release Date', x: 330, y: 673, r: 247, g: 178, b: 8 },
    outTsumCollectionOrderFavoritesNew: { name: 'By Favorites', x: 765, y: 668, r: 247, g: 174, b: 8 },
    outTsumCollectionOrderBySkillNew: { name: 'By Skill', x: 310, y: 900, r: 247, g: 174, b: 8 },
    outTsumCollectionOrderByLevelLockNew: { name: 'By Level Lock', x: 766, y: 894, r: 247, g: 174, b: 8 },
    outTsumCollectionOrderByEntryDateNew: { name: 'By Entry Date', x: 310, y: 1125, r: 247, g: 174, b: 8 },
    outTsumCollectionDoUnlock: { x: 111, y: 760, r: 173, g: 109, b: 57 }
};
// `satisfies` rather than a plain annotation: every entry is still checked
// against PageDef, but the inferred type keeps the exact key set, so
// `Page.ClosePage.back` resolves to the coordinates below. It also keeps each
// entry's `name` as its literal type rather than widening it to `PageName`.
// The fingerprint loops that walk the table by string key cast to `PageMap` for
// an index signature (see findPageObject).
var Page = {
    TodayMissions: {
        name: "TodayMissions" /* PageName.TodayMissions */,
        colors: [
            { x: 764, y: 445, r: 248, g: 190, b: 15, match: true, threshold: 80 },
            { x: 781, y: 436, r: 165, g: 92, b: 63, match: true, threshold: 80 },
            { x: 823, y: 445, r: 248, g: 249, b: 249, match: true, threshold: 80 },
            { x: 554, y: 444, r: 45, g: 111, b: 142, match: true, threshold: 80 },
            { x: 550, y: 1421, r: 33, g: 196, b: 231, match: true, threshold: 80 },
            { x: 593, y: 1423, r: 240, g: 175, b: 8, match: true, threshold: 80 },
            { x: 176, y: 1658, r: 238, g: 172, b: 8, match: true, threshold: 80 },
            { x: 55, y: 1649, r: 238, g: 172, b: 8, match: true, threshold: 80 },
            { x: 25, y: 1655, r: 8, g: 16, b: 26, match: true, threshold: 80 }
        ],
        back: { x: 176, y: 1662 },
        next: { x: 176, y: 1662 }
    },
    TodayMission: {
        name: "TodayMission" /* PageName.TodayMission */,
        colors: [
            { x: 540, y: 1480, r: 238, g: 181, b: 12, match: true, threshold: 80 },
            { x: 975, y: 500, r: 161, g: 224, b: 231, match: true, threshold: 80 },
            { x: 554, y: 1332, r: 24, g: 189, b: 219, match: true, threshold: 80 }
        ],
        back: { x: 558, y: 1473 },
        next: { x: 558, y: 1473 }
    },
    ScorePage: {
        name: "ScorePage" /* PageName.ScorePage */,
        colors: [
            { x: 302, y: 1581, r: 235, g: 184, b: 7, match: true, threshold: 80 },
            { x: 777, y: 1588, r: 248, g: 142, b: 20, match: true, threshold: 80 },
            { x: 774, y: 500, r: 243, g: 248, b: 242, match: true, threshold: 80 }
        ],
        back: { x: 309, y: 1653 },
        next: { x: 784, y: 1653 }
    },
    ProfilePageJp: {
        name: "ProfilePage" /* PageName.ProfilePage */,
        colors: [
            { x: 540, y: 1592, r: 246, g: 135, b: 17, match: true, threshold: 80 }, // top of the start button
            { x: 187, y: 1599, r: 240, g: 218, b: 72, match: true, threshold: 80 }, // top of the card button
            { x: 799, y: 1653, r: 232, g: 170, b: 7, match: true, threshold: 80 }, // left of the myTsum button
            { x: 698, y: 464, r: 244, g: 249, b: 243, match: true, threshold: 80 }, // above the ranking title
            { x: 34, y: 1004, r: 247, g: 178, b: 8, match: true, threshold: 80 }, // left home tab button
            { x: 6, y: 1120, r: 46, g: 135, b: 232, match: true, threshold: 80 }, // left ranking tab button
            { x: 6, y: 1270, r: 44, g: 134, b: 233, match: true, threshold: 80 } // left square tab button
        ],
        back: { x: 31, y: 1126 },
        next: { x: 31, y: 1126 },
        tsums: { x: 900, y: 1653 }
    },
    ProfilePageIntl: {
        name: "ProfilePage" /* PageName.ProfilePage */,
        colors: [
            { x: 540, y: 1592, r: 246, g: 135, b: 17, match: true, threshold: 80 }, // top of the start button
            { x: 187, y: 1599, r: 240, g: 218, b: 72, match: true, threshold: 80 }, // top of the card button
            { x: 799, y: 1653, r: 232, g: 170, b: 7, match: true, threshold: 80 }, // left of the myTsum button
            { x: 698, y: 464, r: 244, g: 249, b: 243, match: true, threshold: 80 }, // above the ranking title
            { x: 34, y: 1004, r: 247, g: 178, b: 8, match: true, threshold: 80 }, // left home tab button
            { x: 6, y: 1120, r: 46, g: 135, b: 232, match: true, threshold: 80 }, // left ranking tab button
            { x: 6, y: 1270, r: 52, g: 98, b: 143, match: true, threshold: 80 } // left border where in JP left square tab button is
        ],
        back: { x: 31, y: 1126 },
        next: { x: 31, y: 1126 },
        tsums: { x: 900, y: 1653 }
    },
    SquarePage: {
        name: "SquarePage" /* PageName.SquarePage */,
        colors: [
            { x: 540, y: 1592, r: 246, g: 135, b: 17, match: true, threshold: 80 }, // top of the start button
            { x: 187, y: 1599, r: 240, g: 218, b: 72, match: true, threshold: 80 }, // top of the card button
            { x: 799, y: 1653, r: 232, g: 170, b: 7, match: true, threshold: 80 }, // left of the myTsum button
            { x: 18, y: 994, r: 46, g: 135, b: 234, match: true, threshold: 80 }, // left home tab button
            { x: 16, y: 1120, r: 46, g: 135, b: 232, match: true, threshold: 80 }, // left ranking tab button
            { x: 34, y: 1270, r: 247, g: 175, b: 8, match: true, threshold: 80 } // left square tab button
        ],
        back: { x: 31, y: 1126 },
        next: { x: 31, y: 1126 }
    },
    FriendPage: {
        name: "FriendPage" /* PageName.FriendPage */,
        colors: [
            { x: 540, y: 1592, r: 246, g: 135, b: 17, match: true, threshold: 80 }, // top of the start button
            { x: 187, y: 1599, r: 240, g: 218, b: 72, match: true, threshold: 80 }, // top of the card button
            { x: 799, y: 1653, r: 232, g: 170, b: 7, match: true, threshold: 80 }, // left of the myTsum button
            { x: 698, y: 464, r: 244, g: 249, b: 243, match: true, threshold: 80 }, // left top of the ranking time
            { x: 960, y: 430, r: 24, g: 192, b: 231, match: true, threshold: 80 } // right bottom next to the mailbox icon
        ],
        back: { x: 547, y: 1653 },
        next: { x: 547, y: 1653 },
        tsums: { x: 900, y: 1653 }
    },
    FriendPage2: {
        name: "FriendPage" /* PageName.FriendPage */,
        colors: [
            { x: 540, y: 1649, r: 175, g: 188, b: 197, match: true, threshold: 80 }, // center of the Tsum Hades
            { x: 187, y: 1599, r: 240, g: 218, b: 72, match: true, threshold: 80 }, // top of the card button
            { x: 799, y: 1653, r: 232, g: 170, b: 7, match: true, threshold: 80 }, // left of the myTsum button
            { x: 698, y: 464, r: 244, g: 249, b: 243, match: true, threshold: 80 }, // left top of the ranking time
            { x: 960, y: 430, r: 24, g: 192, b: 231, match: true, threshold: 80 } // right bottom next to the mailbox icon
        ],
        back: { x: 547, y: 1653 },
        next: { x: 547, y: 1653 },
        tsums: { x: 900, y: 1653 }
    },
    FriendPage3: {
        name: "FriendPage" /* PageName.FriendPage */,
        colors: [
            { x: 540, y: 1649, r: 203, g: 192, b: 237, match: true, threshold: 80 }, // center of the Tsum Ursula
            { x: 187, y: 1599, r: 240, g: 218, b: 72, match: true, threshold: 80 }, // top of the card button
            { x: 799, y: 1653, r: 232, g: 170, b: 7, match: true, threshold: 80 }, // left of the myTsum button
            { x: 698, y: 464, r: 244, g: 249, b: 243, match: true, threshold: 80 }, // left top of the ranking time
            { x: 960, y: 430, r: 24, g: 192, b: 231, match: true, threshold: 80 } // right bottom next to the mailbox icon
        ],
        back: { x: 547, y: 1653 },
        next: { x: 547, y: 1653 },
        tsums: { x: 900, y: 1653 }
    },
    FriendPage4: {
        name: "FriendPage" /* PageName.FriendPage */,
        colors: [
            { x: 540, y: 1649, r: 79, g: 89, b: 94, match: true, threshold: 80 }, // center of the Tsum Maleficentd
            { x: 187, y: 1599, r: 240, g: 218, b: 72, match: true, threshold: 80 }, // top of the card button
            { x: 799, y: 1653, r: 232, g: 170, b: 7, match: true, threshold: 80 }, // left of the myTsum button
            { x: 698, y: 464, r: 244, g: 249, b: 243, match: true, threshold: 80 }, // left top of the ranking time
            { x: 960, y: 430, r: 24, g: 192, b: 231, match: true, threshold: 80 } // right bottom next to the mailbox icon
        ],
        back: { x: 547, y: 1653 },
        next: { x: 547, y: 1653 },
        tsums: { x: 900, y: 1653 }
    },
    GiftHeart: {
        name: "GiftHeart" /* PageName.GiftHeart */,
        colors: [
            { x: 216, y: 1084, r: 233, g: 172, b: 6, match: true, threshold: 80 },
            { x: 673, y: 1080, r: 235, g: 174, b: 8, match: true, threshold: 80 },
            { x: 468, y: 803, r: 214, g: 61, b: 143, match: true, threshold: 100 },
            { x: 572, y: 561, r: 30, g: 193, b: 224, match: true, threshold: 80 },
            { x: 583, y: 1195, r: 28, g: 186, b: 221, match: true, threshold: 80 }
        ],
        back: { x: 774, y: 1095 },
        next: { x: 320, y: 1091 }
    },
    MailBox: {
        name: "MailBox" /* PageName.MailBox */,
        colors: [
            { x: 738, y: 414, r: 240, g: 245, b: 239, match: true, threshold: 80 },
            { x: 550, y: 1581, r: 238, g: 187, b: 10, match: true, threshold: 80 },
            { x: 604, y: 1419, r: 234, g: 171, b: 6, match: true, threshold: 80 }
        ],
        back: { x: 561, y: 1653 },
        next: { x: 561, y: 1653 }
    },
    MailBox2: {
        name: "MailBox" /* PageName.MailBox */,
        colors: [
            { x: 738, y: 414, r: 240, g: 245, b: 239, match: true, threshold: 80 },
            { x: 550, y: 1581, r: 238, g: 187, b: 10, match: true, threshold: 80 },
            { x: 619, y: 1426, r: 19, g: 137, b: 175, match: true, threshold: 80 }
        ],
        back: { x: 561, y: 1653 },
        next: { x: 561, y: 1653 }
    },
    ReceiveHeart: {
        name: "ReceiveHeart" /* PageName.ReceiveHeart */,
        colors: [
            { x: 208, y: 1080, r: 233, g: 172, b: 6, match: true, threshold: 80 },
            { x: 662, y: 1080, r: 232, g: 171, b: 5, match: true, threshold: 80 },
            { x: 561, y: 554, r: 28, g: 191, b: 222, match: true, threshold: 80 },
            { x: 565, y: 1210, r: 30, g: 195, b: 225, match: true, threshold: 80 },
            { x: 334, y: 817, r: 213, g: 62, b: 143, match: true, threshold: 90 },
            { x: 586, y: 821, r: 248, g: 249, b: 51, match: true, threshold: 100 }
        ],
        back: { x: 774, y: 1095 },
        next: { x: 320, y: 1091 }
    },
    Received: {
        name: "Received" /* PageName.Received */,
        colors: [
            { x: 799, y: 716, r: 30, g: 188, b: 223, match: true, threshold: 80 },
            { x: 806, y: 889, r: 45, g: 80, b: 122, match: true, threshold: 80 },
            { x: 799, y: 1048, r: 27, g: 188, b: 217, match: true, threshold: 80 }
        ],
        back: { x: 774, y: 1095 },
        next: { x: 320, y: 1091 }
    },
    Received2: {
        name: "Received" /* PageName.Received */,
        colors: [
            { x: 799, y: 716, r: 30, g: 188, b: 223, match: true, threshold: 80 },
            { x: 889, y: 824, r: 40, g: 72, b: 111, match: true, threshold: 80 },
            { x: 799, y: 1048, r: 27, g: 188, b: 217, match: true, threshold: 80 }
        ],
        back: { x: 774, y: 1095 },
        next: { x: 320, y: 1091 }
    },
    StartPage: {
        name: "StartPage" /* PageName.StartPage */,
        colors: [
            { x: 752, y: 471, r: 244, g: 249, b: 243, match: true, threshold: 80 },
            { x: 856, y: 1430, r: 30, g: 193, b: 224, match: true, threshold: 80 },
            { x: 169, y: 1581, r: 239, g: 188, b: 11, match: true, threshold: 80 },
            { x: 547, y: 1581, r: 235, g: 118, b: 134, match: true, threshold: 80 },
            { x: 792, y: 1660, r: 234, g: 171, b: 8, match: true, threshold: 100 }
        ],
        back: { x: 190, y: 1646 },
        next: { x: 558, y: 1635 },
        tsums: { x: 900, y: 1653 }
    },
    StartPage2: {
        name: "StartPage" /* PageName.StartPage */,
        colors: [
            { x: 820, y: 515, r: 245, g: 250, b: 244, match: true, threshold: 80 },
            { x: 954, y: 1426, r: 31, g: 190, b: 220, match: true, threshold: 80 },
            { x: 180, y: 1584, r: 235, g: 182, b: 8, match: true, threshold: 80 },
            { x: 540, y: 1584, r: 238, g: 115, b: 133, match: true, threshold: 80 },
            { x: 1011, y: 1675, r: 229, g: 166, b: 11, match: true, threshold: 100 }
        ],
        back: { x: 190, y: 1646 },
        next: { x: 558, y: 1635 }
    },
    StartPage3: {
        name: "StartPage" /* PageName.StartPage */,
        colors: [
            { x: 400, y: 1672, r: 245, g: 85, b: 115, match: true, threshold: 80 },
            { x: 680, y: 1672, r: 245, g: 85, b: 115, match: true, threshold: 80 },
            { x: 540, y: 1722, r: 235, g: 70, b: 90, match: true, threshold: 80 }
        ],
        back: { x: 190, y: 1646 },
        next: { x: 558, y: 1635 }
    },
    TsumsPage: {
        name: "TsumsPage" /* PageName.TsumsPage */,
        colors: [
            { x: 27, y: 901, r: 197, g: 243, b: 254, match: true, threshold: 80 }, // light header bar, far left (sort-independent)
            { x: 436, y: 902, r: 247, g: 247, b: 247, match: true, threshold: 80 }, // white header gap between "Collection" and the dropdowns (sort-independent)
            { x: 713, y: 900, r: 247, g: 187, b: 16, match: true, threshold: 80 }, // "All Tsums" (left) dropdown gold fill
            { x: 1030, y: 900, r: 249, g: 190, b: 19, match: true, threshold: 80 } // right (sort) dropdown gold beside the arrow -- right-anchored, survives every sort label
        ],
        // The pale badge behind the padlock on a level-locked Tsum, sampled at the
        // eight card positions of one collection page. Re-measured for the current
        // client (was 234-237/244-246/253-254; TsumBeta v84).
        lockIcons: [
            { x: 196, y: 1195, r: 239, g: 247, b: 255 },
            { x: 430, y: 1195, r: 239, g: 247, b: 255 },
            { x: 665, y: 1195, r: 239, g: 247, b: 255 },
            { x: 900, y: 1195, r: 239, g: 247, b: 255 },
            { x: 196, y: 1450, r: 239, g: 247, b: 255 },
            { x: 430, y: 1450, r: 239, g: 247, b: 255 },
            { x: 665, y: 1450, r: 239, g: 247, b: 255 },
            { x: 900, y: 1450, r: 239, g: 247, b: 255 }
        ],
        back: { x: 176, y: 1592 },
        next: { x: 176, y: 1592 },
        store: { x: 910, y: 1592 }
    },
    TsumTsum2025StorePage: {
        name: "TsumTsumStorePage" /* PageName.TsumTsumStorePage */,
        colors: [
            { x: 30, y: 910, r: 16, g: 53, b: 93, match: true, threshold: 30 },
            { x: 60, y: 910, r: 233, g: 171, b: 8, match: true, threshold: 30 },
            { x: 520, y: 910, r: 237, g: 174, b: 8, match: true, threshold: 30 },
            { x: 545, y: 840, r: 22, g: 65, b: 107, match: true, threshold: 30 },
            { x: 570, y: 910, r: 29, g: 85, b: 159, match: true, threshold: 30 },
            { x: 10, y: 955, r: 37, g: 71, b: 115, match: true, threshold: 30 },
            { x: 170, y: 1490, r: 48, g: 81, b: 130, match: true, threshold: 30 },
            { x: 170, y: 1515, r: 8, g: 164, b: 213, match: true, threshold: 30 },
            { x: 170, y: 1570, r: 247, g: 194, b: 16, match: true, threshold: 30 }
        ],
        back: { x: 190, y: 1650 },
        next: { x: 1000, y: 690, r: 238, g: 172, b: 8 }
    },
    ConfirmPurchaseBoxPage: {
        name: "ConfirmPurchasePage" /* PageName.ConfirmPurchasePage */,
        colors: [
            { x: 208, y: 1070, r: 247, g: 176, b: 8, match: true, threshold: 30 }, // left of Cancel button
            { x: 420, y: 1070, r: 247, g: 176, b: 8, match: true, threshold: 30 }, // right of Cancel button
            { x: 540, y: 1070, r: 54, g: 93, b: 146, match: true, threshold: 30 }, // between buttons
            { x: 650, y: 1070, r: 247, g: 176, b: 8, match: true, threshold: 30 }, // left of OK button
            { x: 880, y: 1070, r: 247, g: 176, b: 8, match: true, threshold: 30 }, // right of OK button
            { x: 948, y: 1066, r: 33, g: 69, b: 107, match: true, threshold: 30 }, // right next to OK button
            { x: 805, y: 1265, r: 239, g: 167, b: 8, match: true, threshold: 50 } // left of List button
        ],
        back: { x: 310, y: 1070 }, // Cancel button
        next: { x: 760, y: 1070 } // OK button
    },
    Confirm2025PurchaseBoxPage: {
        name: "ConfirmPurchasePage" /* PageName.ConfirmPurchasePage */,
        colors: [
            { x: 208, y: 1070, r: 247, g: 186, b: 8, match: true, threshold: 30 }, // left of Cancel button
            { x: 420, y: 1070, r: 247, g: 184, b: 8, match: true, threshold: 30 }, // right of Cancel button
            { x: 540, y: 1070, r: 54, g: 90, b: 141, match: true, threshold: 30 }, // between buttons
            { x: 650, y: 1070, r: 247, g: 190, b: 8, match: true, threshold: 30 }, // left of OK button
            { x: 880, y: 1070, r: 247, g: 191, b: 14, match: true, threshold: 30 }, // right of OK button
            { x: 948, y: 1066, r: 40, g: 70, b: 113, match: true, threshold: 30 }, // right next to OK button
            { x: 785, y: 1320, r: 238, g: 171, b: 8, match: true, threshold: 50 } // left of List button
        ],
        back: { x: 310, y: 1070 }, // Cancel button
        next: { x: 760, y: 1070 } // OK button
    },
    ConfirmPurchaseCapsulePage: {
        name: "ConfirmPurchasePage" /* PageName.ConfirmPurchasePage */,
        colors: [
            { x: 200, y: 1444, r: 247, g: 178, b: 8, match: true, threshold: 30 }, // left of Cancel button
            { x: 426, y: 1444, r: 247, g: 178, b: 8, match: true, threshold: 30 }, // right of Cancel button
            { x: 540, y: 1444, r: 54, g: 93, b: 146, match: true, threshold: 30 }, // between buttons
            { x: 660, y: 1444, r: 247, g: 174, b: 8, match: true, threshold: 30 }, // left of OK button
            { x: 860, y: 1444, r: 247, g: 178, b: 8, match: true, threshold: 30 }, // right of OK button
            { x: 940, y: 1444, r: 33, g: 65, b: 107, match: true, threshold: 30 }, // right next to OK button
            { x: 416, y: 790, r: 239, g: 28, b: 49, match: true, threshold: 30 } // red top of big pickup capsule image
        ],
        back: { x: 320, y: 1444 }, // Cancel button
        next: { x: 766, y: 1444 } // OK button
    },
    Confirm2025PurchaseCapsulePage: {
        name: "ConfirmPurchasePage" /* PageName.ConfirmPurchasePage */,
        colors: [
            { x: 200, y: 1464, r: 247, g: 178, b: 8, match: true, threshold: 30 }, // left of Cancel button
            { x: 426, y: 1464, r: 247, g: 178, b: 8, match: true, threshold: 30 }, // right of Cancel button
            { x: 540, y: 1464, r: 54, g: 93, b: 146, match: true, threshold: 30 }, // between buttons
            { x: 660, y: 1464, r: 247, g: 174, b: 8, match: true, threshold: 30 }, // left of OK button
            { x: 860, y: 1464, r: 247, g: 178, b: 8, match: true, threshold: 30 }, // right of OK button
            { x: 940, y: 1464, r: 33, g: 65, b: 107, match: true, threshold: 30 }, // right next to OK button
            { x: 836, y: 1152, r: 255, g: 255, b: 255, match: true, threshold: 30 }, // lower left of slash in "15/15"
            { x: 860, y: 1081, r: 255, g: 255, b: 255, match: true, threshold: 30 }, // upper right of slash in "15/15"
            { x: 860, y: 1152, r: 48, g: 81, b: 127, match: true, threshold: 30 } // blue area under slash in "15/15"
        ],
        back: { x: 320, y: 1464 }, // Cancel button
        next: { x: 766, y: 1464 } // OK button
    },
    TapOpenPageBox: {
        name: "TapOpenPage" /* PageName.TapOpenPage */,
        colors: [
            { x: 641, y: 328, r: 255, g: 255, b: 231, match: true, threshold: 30 },
            { x: 641, y: 243, r: 255, g: 255, b: 247, match: true, threshold: 30 },
            { x: 180, y: 520, r: 247, g: 182, b: 189, match: true, threshold: 30 },
            { x: 899, y: 777, r: 140, g: 121, b: 156, match: true, threshold: 30 },
            { x: 68, y: 1265, r: 33, g: 73, b: 107, match: true, threshold: 30 },
            { x: 964, y: 1265, r: 33, g: 73, b: 115, match: true, threshold: 30 },
            { x: 534, y: 1840, r: 33, g: 190, b: 231, match: true, threshold: 30 }
        ],
        back: { x: 500, y: 1600 },
        next: { x: 500, y: 1600 }
    },
    TapOpenPageCapsule: {
        name: "TapOpenPage" /* PageName.TapOpenPage */,
        colors: [
            { x: 70, y: 560, r: 24, g: 85, b: 132, match: true, threshold: 30 },
            { x: 899, y: 777, r: 137, g: 117, b: 148, match: true, threshold: 30 },
            { x: 68, y: 1265, r: 33, g: 73, b: 107, match: true, threshold: 30 },
            { x: 964, y: 1265, r: 33, g: 73, b: 115, match: true, threshold: 30 },
            { x: 405, y: 1397, r: 255, g: 255, b: 255, match: true, threshold: 30 }, // T from "TAP!"
            { x: 546, y: 1429, r: 255, g: 255, b: 255, match: true, threshold: 30 }, // A from "TAP!"
            { x: 664, y: 1407, r: 255, g: 255, b: 255, match: true, threshold: 30 }, // P from "TAP!"
            { x: 709, y: 1381, r: 255, g: 255, b: 255, match: true, threshold: 30 } // ! from "TAP!"
        ],
        back: { x: 500, y: 1600 },
        next: { x: 500, y: 1600 }
    },
    TapOpenPageCapsuleDeprecated: {
        name: "TapOpenPageDeprecated" /* PageName.TapOpenPageDeprecated */,
        colors: [
            { x: 620, y: 328, r: 205, g: 13, b: 34, match: true, threshold: 30 },
            { x: 641, y: 243, r: 146, g: 0, b: 0, match: true, threshold: 30 },
            { x: 70, y: 560, r: 24, g: 85, b: 132, match: true, threshold: 30 },
            { x: 899, y: 777, r: 137, g: 117, b: 148, match: true, threshold: 30 },
            { x: 68, y: 1265, r: 33, g: 73, b: 107, match: true, threshold: 30 },
            { x: 964, y: 1265, r: 33, g: 73, b: 115, match: true, threshold: 30 },
            { x: 534, y: 1840, r: 33, g: 190, b: 231, match: true, threshold: 30 }
        ],
        back: { x: 500, y: 1600 },
        next: { x: 500, y: 1600 }
    },
    BoxPurchasedPage: {
        name: "BoxPurchasedPage" /* PageName.BoxPurchasedPage */,
        colors: [
            { x: 156, y: 1077, r: 33, g: 195, b: 231, match: true, threshold: 30 },
            { x: 48, y: 998, r: 24, g: 52, b: 82, match: true, threshold: 30 },
            { x: 131, y: 1134, r: 33, g: 65, b: 107, match: true, threshold: 30 },
            { x: 928, y: 1077, r: 33, g: 203, b: 239, match: true, threshold: 30 },
            { x: 923, y: 1183, r: 33, g: 65, b: 107, match: true, threshold: 30 },
            { x: 904, y: 1396, r: 33, g: 199, b: 239, match: true, threshold: 30 },
            { x: 389, y: 1634, r: 247, g: 174, b: 8, match: true, threshold: 30 },
            { x: 279, y: 1627, r: 41, g: 77, b: 115, match: true, threshold: 30 },
            { x: 525, y: 1823, r: 24, g: 158, b: 189, match: true, threshold: 30 }
        ],
        back: { x: 550, y: 1630 }, // Close button
        next: { x: 550, y: 1630 } // Close button
    },
    PremiumPlusBoxPurchasedPage: {
        name: "BoxPurchasedPage" /* PageName.BoxPurchasedPage */,
        colors: [
            { x: 156, y: 1077, r: 33, g: 195, b: 231, match: true, threshold: 30 },
            { x: 48, y: 998, r: 33, g: 66, b: 99, match: true, threshold: 30 },
            { x: 131, y: 1137, r: 33, g: 62, b: 101, match: true, threshold: 30 },
            { x: 928, y: 1075, r: 33, g: 203, b: 236, match: true, threshold: 30 },
            { x: 922, y: 1184, r: 33, g: 65, b: 107, match: true, threshold: 30 },
            { x: 904, y: 1396, r: 33, g: 199, b: 239, match: true, threshold: 30 },
            { x: 389, y: 1634, r: 238, g: 174, b: 8, match: true, threshold: 30 },
            { x: 280, y: 1626, r: 63, g: 103, b: 147, match: true, threshold: 30 },
            { x: 525, y: 1823, r: 40, g: 210, b: 247, match: true, threshold: 30 }
        ],
        back: { x: 550, y: 1630 }, // Close button
        next: { x: 550, y: 1630 } // Close button
    },
    GamePause: {
        name: "GamePause" /* PageName.GamePause */,
        colors: [
            { x: 165, y: 1077, r: 234, g: 173, b: 7, match: true, threshold: 80 },
            { x: 586, y: 1080, r: 239, g: 174, b: 7, match: true, threshold: 80 },
            { x: 367, y: 774, r: 24, g: 191, b: 225, match: true, threshold: 80 },
            { x: 738, y: 612, r: 248, g: 244, b: 245, match: true, threshold: 80 },
            { x: 550, y: 1336, r: 247, g: 185, b: 8, match: true, threshold: 80 }
        ],
        back: { x: 331, y: 1080 },
        next: { x: 561, y: 1422 }
    },
    GamePlaying480x800: {
        name: "GamePlaying" /* PageName.GamePlaying */,
        colors: [
            { x: 916, y: 198, r: 253, g: 216, b: 0, match: true, threshold: 80 }, // above pause
            { x: 916, y: 318, r: 241, g: 161, b: 8, match: true, threshold: 80 }, // below pause
            { x: 916, y: 1688, r: 242, g: 161, b: 8, match: true, threshold: 80 } // below fan
        ],
        back: { x: 986, y: 273 },
        next: { x: 986, y: 273 }
    },
    GamePlayingLastSeconds: {
        name: "GamePlaying" /* PageName.GamePlaying */,
        colors: [
            { x: 916, y: 198, r: 181, g: 207, b: 74, match: true, threshold: 80 }, // above pause
            { x: 916, y: 318, r: 190, g: 174, b: 57, match: true, threshold: 80 }, // below pause
            { x: 916, y: 1688, r: 181, g: 178, b: 74, match: true, threshold: 80 } // below fan
        ],
        back: { x: 986, y: 273 },
        next: { x: 986, y: 273 }
    },
    GamePlaying: {
        name: "GamePlaying" /* PageName.GamePlaying */,
        colors: [
            { x: 916, y: 198, r: 230, g: 200, b: 20, match: true, threshold: 80 }, // above pause
            { x: 916, y: 318, r: 214, g: 191, b: 28, match: true, threshold: 80 }, // below pause
            { x: 916, y: 1688, r: 214, g: 191, b: 28, match: true, threshold: 80 } // below fan
        ],
        back: { x: 986, y: 273 },
        next: { x: 986, y: 273 }
    },
    GamePlaying2: {
        name: "GamePlaying" /* PageName.GamePlaying */,
        colors: [
            { x: 980, y: 258, r: 190, g: 244, b: 70, match: true, threshold: 80 }, // right of pause
            { x: 852, y: 258, r: 244, g: 197, b: 20, match: true, threshold: 80 }, // left of pause
            { x: 916, y: 1688, r: 230, g: 150, b: 25, match: true, threshold: 80 } // below fan
        ],
        back: { x: 986, y: 273 },
        next: { x: 986, y: 273 }
    },
    // Root-detection warning (a native Android AlertDialog) as it looks on a
    // handful of emulators. All variants share the page name so the navigation
    // loops handle them the same way: hand the screen to dismissSystemDialog(),
    // which finds the real "PERMIT" button in device pixels. The back/next
    // coordinates below belong to one specific emulator and dpi each, so they are
    // only a last-resort hint -- see dialogs.ts for why they cannot be trusted.
    // The matched variant's key is still logged, so detection stays diagnosable.
    RootDetectionLdp1080p480dpiEn: {
        name: "RootDetection" /* PageName.RootDetection */,
        colors: [
            { x: 80, y: 690, r: 255, g: 255, b: 255, match: true, threshold: 25 },
            { x: 70, y: 680, r: 255, g: 255, b: 255, match: false, threshold: 25 },
            { x: 1000, y: 1300, r: 255, g: 255, b: 255, match: true, threshold: 25 },
            { x: 1010, y: 1310, r: 255, g: 255, b: 255, match: false, threshold: 25 }
        ],
        back: { x: 855, y: 1224 },
        next: { x: 855, y: 1224 },
        onDetect: switchToStartupMode
    },
    RootDetectionLdp1080p480dpiJp: {
        name: "RootDetection" /* PageName.RootDetection */,
        colors: [
            { x: 80, y: 635, r: 255, g: 255, b: 255, match: true, threshold: 25 },
            { x: 70, y: 625, r: 255, g: 255, b: 255, match: false, threshold: 25 },
            { x: 1000, y: 1360, r: 255, g: 255, b: 255, match: true, threshold: 25 },
            { x: 1010, y: 1370, r: 255, g: 255, b: 255, match: false, threshold: 25 }
        ],
        back: { x: 850, y: 1280 },
        next: { x: 850, y: 1280 },
        onDetect: switchToStartupMode
    },
    RootDetectionLdp480x800x160dpiEn: {
        name: "RootDetection" /* PageName.RootDetection */,
        colors: [
            { x: 90, y: 780, r: 253, g: 253, b: 253, match: true, threshold: 25 },
            { x: 65, y: 745, r: 255, g: 255, b: 255, match: false, threshold: 25 },
            { x: 990, y: 1190, r: 252, g: 252, b: 252, match: true, threshold: 25 },
            { x: 1015, y: 1225, r: 255, g: 255, b: 255, match: false, threshold: 25 }
        ],
        back: { x: 885, y: 1135 },
        next: { x: 885, y: 1135 },
        onDetect: switchToStartupMode
    },
    RootDetectionNox1080p360dpiEn: {
        name: "RootDetection" /* PageName.RootDetection */,
        colors: [
            { x: 135, y: 795, r: 255, g: 255, b: 255, match: true, threshold: 25 },
            { x: 125, y: 785, r: 255, g: 255, b: 255, match: false, threshold: 25 },
            { x: 945, y: 1170, r: 255, g: 255, b: 255, match: true, threshold: 25 },
            { x: 955, y: 1180, r: 255, g: 255, b: 255, match: false, threshold: 25 }
        ],
        back: { x: 850, y: 1115 },
        next: { x: 850, y: 1115 },
        onDetect: switchToStartupMode
    },
    RootDetectionNox480x800x160dpiJp: {
        name: "RootDetection" /* PageName.RootDetection */,
        colors: [
            { x: 85, y: 735, r: 255, g: 255, b: 255, match: true, threshold: 25 },
            { x: 75, y: 725, r: 255, g: 255, b: 255, match: false, threshold: 25 },
            { x: 995, y: 1240, r: 255, g: 255, b: 255, match: true, threshold: 25 },
            { x: 1005, y: 1250, r: 255, g: 255, b: 255, match: false, threshold: 25 }
        ],
        back: { x: 885, y: 1170 },
        next: { x: 885, y: 1170 },
        onDetect: switchToStartupMode
    },
    RootDetectionNox480x800x160dpiEn: {
        name: "RootDetection" /* PageName.RootDetection */,
        colors: [
            { x: 85, y: 760, r: 255, g: 255, b: 255, match: true, threshold: 25 },
            { x: 75, y: 750, r: 255, g: 255, b: 255, match: false, threshold: 25 },
            { x: 995, y: 1215, r: 255, g: 255, b: 255, match: true, threshold: 25 },
            { x: 1005, y: 1225, r: 255, g: 255, b: 255, match: false, threshold: 25 }
        ],
        back: { x: 885, y: 1150 },
        next: { x: 885, y: 1150 },
        onDetect: switchToStartupMode
    },
    RootDetectionSamsungA20En: {
        name: "RootDetection" /* PageName.RootDetection */,
        colors: [
            { x: 60, y: 440, r: 255, g: 255, b: 255, match: true, threshold: 25 },
            { x: 50, y: 440, r: 255, g: 255, b: 255, match: false, threshold: 25 },
            { x: 60, y: 430, r: 255, g: 255, b: 255, match: false, threshold: 25 },
            { x: 1020, y: 1310, r: 255, g: 255, b: 255, match: true, threshold: 25 },
            { x: 1020, y: 1320, r: 255, g: 255, b: 255, match: false, threshold: 25 },
            { x: 1010, y: 1325, r: 255, g: 255, b: 255, match: false, threshold: 25 }
        ],
        back: { x: 850, y: 1230 },
        next: { x: 850, y: 1230 },
        onDetect: switchToStartupMode
    },
    // White AlertDialog variant on 1080x1920 portrait: a white popup box over a
    // dimmed grey background, with blue "REFUSE" / "PERMIT" link-style buttons
    // bottom-right.
    // Only the panel/scrim probes are kept: probes on the button text itself never
    // matched, because findPageObject reads a screenshot downscaled to 360px wide
    // and JPEG-compressed, which leaves nothing of a thin blue glyph at a guessed
    // position. The panel/scrim shape is coarse on purpose -- the tap that follows
    // is located and verified by dismissSystemDialog(), not by these coordinates.
    RootDetection1080pEn: {
        name: "RootDetection" /* PageName.RootDetection */,
        colors: [
            { x: 950, y: 868, r: 255, g: 255, b: 255, match: true, threshold: 25 }, // white dialog interior (top-right)
            { x: 540, y: 1100, r: 255, g: 255, b: 255, match: true, threshold: 25 }, // white dialog interior (below buttons)
            { x: 540, y: 300, r: 255, g: 255, b: 255, match: false, threshold: 25 }, // dimmed grey overlay above dialog
            { x: 540, y: 1500, r: 255, g: 255, b: 255, match: false, threshold: 25 } // dimmed grey overlay below dialog
        ],
        back: { x: 932, y: 1059 }, // estimated PERMIT position, hint only
        next: { x: 932, y: 1059 },
        onDetect: switchToStartupMode
    },
    MagicalTime: {
        name: "MagicalTime" /* PageName.MagicalTime */,
        colors: [
            { x: 817, y: 507, r: 244, g: 249, b: 243, match: true, threshold: 80 },
            { x: 594, y: 857, r: 248, g: 102, b: 121, match: true, threshold: 100 },
            { x: 208, y: 1217, r: 236, g: 175, b: 9, match: true, threshold: 80 },
            { x: 662, y: 1213, r: 232, g: 171, b: 5, match: true, threshold: 80 }
        ],
        back: { x: 381, y: 1221 },
        next: { x: 856, y: 1221 }
    },
    OutOfMedals: {
        name: "OutOfMedals" /* PageName.OutOfMedals */,
        colors: [
            { x: 127, y: 873, r: 74, g: 74, b: 74, match: true, threshold: 80 }, // mickey left-side ear
            { x: 186, y: 898, r: 255, g: 213, b: 188, match: true, threshold: 80 }, // mickey face
            { x: 865, y: 879, r: 247, g: 251, b: 255, match: true, threshold: 80 }, // donald face
            { x: 474, y: 1065, r: 238, g: 174, b: 8, match: true, threshold: 80 }, // left button
            { x: 540, y: 1070, r: 56, g: 91, b: 140, match: true, threshold: 80 }, // blue between both buttons
            { x: 595, y: 1066, r: 238, g: 171, b: 8, match: true, threshold: 80 } // right button
        ],
        back: { x: 300, y: 1080 },
        next: { x: 300, y: 1080 }
    },
    NetworkDisable: {
        name: "NetworkDisable" /* PageName.NetworkDisable */,
        colors: [
            { x: 478, y: 1080, r: 236, g: 94, b: 116, match: true, threshold: 80 },
            { x: 932, y: 1077, r: 232, g: 171, b: 5, match: true, threshold: 80 }
        ],
        back: { x: 885, y: 1080 },
        next: { x: 885, y: 1084 }
    },
    NetworkTimeout: {
        name: "NetworkTimeout" /* PageName.NetworkTimeout */,
        colors: [
            { x: 530, y: 590, r: 33, g: 197, b: 234, match: true, threshold: 80 },
            { x: 530, y: 620, r: 59, g: 94, b: 148, match: true, threshold: 80 },
            { x: 478, y: 1080, r: 232, g: 171, b: 5, match: true, threshold: 80 },
            { x: 932, y: 1077, r: 232, g: 171, b: 5, match: true, threshold: 80 },
            { x: 530, y: 1150, r: 59, g: 94, b: 148, match: true, threshold: 80 },
            { x: 530, y: 1170, r: 33, g: 197, b: 234, match: true, threshold: 80 }
        ],
        back: { x: 885, y: 1084 },
        next: { x: 885, y: 1084 }
    },
    FriendInfo: {
        name: "FriendInfo" /* PageName.FriendInfo */,
        colors: [
            { x: 565, y: 576, r: 31, g: 190, b: 220, match: true, threshold: 80 },
            { x: 547, y: 1195, r: 27, g: 192, b: 222, match: true, threshold: 80 },
            { x: 554, y: 1332, r: 238, g: 186, b: 12, match: true, threshold: 80 }
        ],
        back: { x: 576, y: 1408 },
        next: { x: 576, y: 1408 }
    },
    LevelUp: {
        name: "LevelUp" /* PageName.LevelUp */,
        colors: [
            { x: 140, y: 1656, r: 233, g: 175, b: 6, match: true, threshold: 80 }, // left of the close button
            { x: 450, y: 1656, r: 233, g: 175, b: 6, match: true, threshold: 80 }, // right of the close button
            { x: 620, y: 1656, r: 233, g: 175, b: 6, match: true, threshold: 80 }, // left of the share button
            { x: 930, y: 1656, r: 233, g: 175, b: 6, match: true, threshold: 80 } // right of the share button
        ],
        back: { x: 300, y: 1660 },
        next: { x: 300, y: 1660 }
    },
    HighScore: {
        name: "HighScore" /* PageName.HighScore */,
        colors: [
            { x: 576, y: 1325, r: 238, g: 187, b: 10, match: true, threshold: 80 }, // top yellow of close button
            { x: 576, y: 1082, r: 33, g: 194, b: 231, match: true, threshold: 80 }, // bottom light blue of highscore cell
            { x: 576, y: 762, r: 33, g: 194, b: 231, match: true, threshold: 80 }, // top light blue of highscore cell
            { x: 576, y: 820, r: 64, g: 109, b: 171, match: true, threshold: 80 } // inner dark blue of highscore cell
        ],
        back: { x: 576, y: 1325 },
        next: { x: 576, y: 1325 }
    },
    ClosePage: {
        name: "ClosePage" /* PageName.ClosePage */, // the close button at center bottom
        colors: [
            { x: 540, y: 1588, r: 233, g: 180, b: 10, match: true, threshold: 80 } // top right of the close button
        ],
        back: { x: 576, y: 1660 },
        next: { x: 576, y: 1660 }
    },
    // *** Following commented out because detection is way too unspecific and I don't know what it should detect.
    // InvitePage: {
    //   name: 'InvitePage', // the close button at left bottom
    //   colors: [
    //     {x: 180, y: 1592, r: 238, g: 180, b: 11, match: true, threshold: 80}
    //   ],
    //   back: {x: 176, y: 1592},
    //   next: {x: 176, y: 1592}
    // },
    ReceiveSkillTicket: {
        name: "ReceiveSkillTicket" /* PageName.ReceiveSkillTicket */,
        colors: [
            { x: 405, y: 806, r: 240, g: 155, b: 20, match: true, threshold: 80 },
            { x: 488, y: 839, r: 244, g: 164, b: 23, match: true, threshold: 80 },
            { x: 502, y: 821, r: 255, g: 255, b: 255, match: true, threshold: 40 },
            { x: 390, y: 824, r: 58, g: 92, b: 142, match: true, threshold: 80 },
            { x: 522, y: 812, r: 60, g: 95, b: 147, match: true, threshold: 80 },
            { x: 874, y: 1098, r: 238, g: 174, b: 8, match: true, threshold: 80 },
            { x: 198, y: 1095, r: 239, g: 174, b: 8, match: true, threshold: 80 },
            { x: 160, y: 1545, r: 0, g: 4, b: 8, match: true, threshold: 80 },
            { x: 526, y: 553, r: 33, g: 195, b: 231, match: true, threshold: 80 }
        ],
        back: { x: 198, y: 1095 },
        next: { x: 874, y: 1098 }
    },
    ReceivePremiumTicket: {
        name: "ReceivePremiumTicket" /* PageName.ReceivePremiumTicket */,
        colors: [
            { x: 405, y: 806, r: 216, g: 20, b: 25, match: true, threshold: 80 },
            { x: 488, y: 839, r: 208, g: 20, b: 23, match: true, threshold: 80 },
            { x: 502, y: 821, r: 255, g: 247, b: 181, match: true, threshold: 40 },
            { x: 390, y: 824, r: 58, g: 92, b: 142, match: true, threshold: 80 },
            { x: 522, y: 812, r: 60, g: 95, b: 147, match: true, threshold: 80 },
            { x: 874, y: 1098, r: 238, g: 174, b: 8, match: true, threshold: 80 },
            { x: 198, y: 1095, r: 239, g: 174, b: 8, match: true, threshold: 80 },
            { x: 160, y: 1545, r: 0, g: 4, b: 8, match: true, threshold: 80 },
            { x: 526, y: 553, r: 33, g: 195, b: 231, match: true, threshold: 80 }
        ],
        back: { x: 198, y: 1095 },
        next: { x: 874, y: 1098 }
    },
    ReceiveHeartWithoutCoins: {
        name: "ReceiveHeartWithoutCoins" /* PageName.ReceiveHeartWithoutCoins */,
        colors: [
            { x: 360, y: 570, r: 33, g: 198, b: 233, match: true, threshold: 30 },
            { x: 400, y: 620, r: 61, g: 94, b: 147, match: true, threshold: 30 },
            { x: 460, y: 820, r: 222, g: 61, b: 148, match: true, threshold: 30 },
            { x: 420, y: 1100, r: 238, g: 174, b: 8, match: true, threshold: 30 },
            { x: 860, y: 1100, r: 238, g: 174, b: 8, match: true, threshold: 30 },
            { x: 540, y: 1100, r: 58, g: 94, b: 146, match: true, threshold: 30 },
            { x: 550, y: 1600, r: 49, g: 36, b: 0, match: true, threshold: 30 }
        ],
        back: { x: 420, y: 1100 },
        next: { x: 860, y: 1100 }
    },
    ExtraUpdateJp: {
        name: "ExtraUpdate" /* PageName.ExtraUpdate */,
        colors: [
            { x: 104, y: 556, r: 36, g: 204, b: 239, match: true, threshold: 80 }, // light blue top left
            { x: 104, y: 1194, r: 36, g: 204, b: 239, match: true, threshold: 80 }, // light blue bottom left
            { x: 700, y: 1100, r: 238, g: 174, b: 8, match: true, threshold: 80 }, // OK button
            { x: 200, y: 1100, r: 238, g: 174, b: 8, match: true, threshold: 80 }, // Cancel button
            { x: 644, y: 676, r: 248, g: 248, b: 248, match: true, threshold: 80 }, // Left of big white "o" letter
            { x: 694, y: 676, r: 248, g: 248, b: 248, match: true, threshold: 80 }, // Right of big white "o" letter
            { x: 668, y: 676, r: 58, g: 93, b: 148, match: true, threshold: 80 }, // Middle of big white "o" letter
            { x: 422, y: 998, r: 48, g: 93, b: 148, match: true, threshold: 80 }, // Middle of small white "o" letter
            { x: 406, y: 998, r: 248, g: 248, b: 248, match: true, threshold: 80 }, // Left of small white "o" letter
            { x: 434, y: 998, r: 248, g: 248, b: 248, match: true, threshold: 80 } // Right of small white "o" letter
        ],
        back: { x: 770, y: 1100 },
        next: { x: 770, y: 1100 }
    },
    ExtraUpdateEn: {
        name: "ExtraUpdate" /* PageName.ExtraUpdate */,
        colors: [
            { x: 104, y: 556, r: 36, g: 204, b: 239, match: true, threshold: 80 }, // light blue top left
            { x: 104, y: 1194, r: 36, g: 204, b: 239, match: true, threshold: 80 }, // light blue bottom left
            { x: 700, y: 1100, r: 238, g: 174, b: 8, match: true, threshold: 80 }, // OK button
            { x: 200, y: 1100, r: 238, g: 174, b: 8, match: true, threshold: 80 }, // Cancel button
            { x: 520, y: 680, r: 248, g: 248, b: 248, match: true, threshold: 80 }, // Left of big white "o" letter
            { x: 558, y: 680, r: 248, g: 248, b: 248, match: true, threshold: 80 }, // Right of big white "o" letter
            { x: 538, y: 680, r: 55, g: 94, b: 148, match: true, threshold: 80 }, // Middle of big white "o" letter
            { x: 674, y: 1002, r: 60, g: 100, b: 150, match: true, threshold: 80 }, // Middle of small white "o" letter
            { x: 662, y: 1002, r: 240, g: 240, b: 240, match: true, threshold: 80 }, // Left of small white "o" letter
            { x: 686, y: 1002, r: 240, g: 240, b: 240, match: true, threshold: 80 } // Right of small white "o" letter
        ],
        back: { x: 770, y: 1100 },
        next: { x: 770, y: 1100 }
    },
    RubyResetDifficulty: {
        name: "RubyResetDifficulty" /* PageName.RubyResetDifficulty */,
        colors: [
            { x: 594, y: 972, r: 247, g: 81, b: 82, match: true, threshold: 80 }, // red arrow between numbers
            { x: 610, y: 1166, r: 189, g: 0, b: 41, match: true, threshold: 80 }, // ruby next to "10"
            { x: 588, y: 1096, r: 25, g: 174, b: 214, match: true, threshold: 80 }, // light blue next to above ruby
            { x: 867, y: 1270, r: 238, g: 174, b: 8, match: true, threshold: 80 }, // OK button
            { x: 425, y: 1275, r: 238, g: 174, b: 8, match: true, threshold: 80 } // Cancel button
        ],
        back: { x: 425, y: 1275 },
        next: { x: 867, y: 1270 }
    }
};
// page callbacks (this = actual Tsum instance)
function switchToStartupMode() {
    this.isStartupPhase = true;
}
// predefined log messages
//
// Deliberately un-annotated: the inferred type is the exact key set, which is
// what makes `this.logs.recognitionStart` resolve to the message below and a
// misspelling an error. `LogsTW` is then typed as `typeof Logs`, so a
// translation that gains or loses a key stops the build.
var Logs = {
    start: '[TsumTsum] Start',
    stop: '[TsumTsum] Stop',
    sendMessage: 'Send Message...',
    TaskControllerStop: 'TaskController Stop',
    updateApp: 'Please update Robotmon and restart service',
    UnknownState: 'Unknown state, Exiting',
    totalTsums: 'Total Tsums',
    removeSameTsums: 'Remove same Tsums',
    recognizedTsums: 'Recognized Tsums',
    recognizingTsums: 'Recognizing Tsums',
    recognitionStart: 'Start Tsums recognition',
    recognitionTime: 'Time consumed',
    myTsum: 'myTsum',
    clearBubbles: 'Clear bubbles',
    bubbleGenerated: 'Bubble generated',
    calculationPathStart: 'Start path calculation ',
    calculatedPath: 'Calculated path',
    pathLengths: 'Chain lengths',
    recalculatingPath: 'Connections 0, Recalculating path',
    useSkill: 'Use skill',
    tiaraNoDream: '[Tiara] No thought bubble appeared',
    tiaraBusy: '[Tiara] Board still moving, firing anyway; diff',
    tiaraDream: '[Tiara] Bubble shows',
    tiaraPicked: '[Tiara] Tapped',
    tiaraUnsure: '[Tiara] No present matched confidently, stopping',
    gameStart: 'Game Start',
    gaming: 'Gaming (Slow version)',
    fastGaming: 'Gaming (Fast version)',
    gameOver: 'Game Over',
    confirmingGameOver: 'Screen not recognized, confirming game over (skill animation?)',
    detectScreen: 'Detecting screen (top and bosttom)',
    calculateScreenSize: 'Calculating screen size',
    offset: 'Offset (X, Y, H, W)',
    startTsumTsumApp: 'Start TsumTsum app',
    currentPage: 'Pg:',
    friendsPage: 'Friends page',
    checkBonusItems: 'Check bonus items',
    receiveAllGifts: 'Receive all gifts',
    receiveGiftsOneByOne: 'Receive gift one by one',
    receiveGiftAgain: 'Receive gift again',
    allGiftsReceived: 'All gifts received',
    receivingGiftsCompleted: 'Receiving gifts completed',
    checkUnreceivedGift: 'Check unreceived gift',
    readRecords: 'Reading records',
    saveRecords: 'Saving records',
    recognizingHeartSender: 'Recognizing heart sender',
    calculatingHeartSender: 'Calculating heart sender',
    receiveHeartFromHeartSender: 'Receive',
    recognitionScore: 'Recognition score',
    saveNewFriend: 'Save new friend',
    saveNewFriendAgain: 'Save new friend again',
    hearts: 'hearts from heart sender today',
    startSendingHearts: 'Start sending hearts',
    checkSendingHearts: 'Check sending hearts',
    sendingHearts: 'Sending',
    sendingZeroScore: 'hearts',
    timeIsUp: 'Time\'s up',
    tsumsPage: 'Tsum collection page',
    startUnlockLevel: 'Check for level locked Tsums',
    endUnlockLevel: 'Finished unlocking Tsum levels'
};
var LogsTW = {
    start: '[TsumTsum] 啟動',
    stop: '[TsumTsum] 停止',
    sendMessage: '送出訊息中...',
    TaskControllerStop: 'TaskController 停止',
    updateApp: '請更新 Robotmon 並重新啟動 Service',
    UnknownState: '未知狀態，離開',
    totalTsums: 'Tsums 總數',
    removeSameTsums: '移除相同 Tsums 後總數',
    recognizedTsums: '成功辨識 Tsums',
    recognizingTsums: '辨識 Tsums 中',
    recognitionStart: '開始辨識 Tsums',
    recognitionTime: '耗時',
    myTsum: '我的Tsum',
    clearBubbles: '清除泡泡',
    bubbleGenerated: '產生泡泡',
    calculationPathStart: '開始計算路徑',
    calculatedPath: '成功計算路徑',
    pathLengths: '連鎖長度',
    recalculatingPath: '路徑數量為 0, 重新辨識',
    useSkill: '使用技能',
    tiaraNoDream: '[皇冠米妮] 沒有出現想像泡泡',
    tiaraBusy: '[皇冠米妮] 畫面仍在變動，仍然發動；差異',
    tiaraDream: '[皇冠米妮] 泡泡顯示',
    tiaraPicked: '[皇冠米妮] 點擊',
    tiaraUnsure: '[皇冠米妮] 沒有禮物符合，停止',
    gameStart: '遊戲開始',
    gaming: '遊戲中 (慢速版)',
    fastGaming: '遊戲中 (快速版)',
    gameOver: '遊戲結束',
    confirmingGameOver: '無法辨識畫面，確認遊戲是否結束（技能動畫中？）',
    detectScreen: '偵測畫面 (頂部與底部)',
    calculateScreenSize: '計算螢幕大小',
    offset: '位移 (X, Y, H, W)',
    startTsumTsumApp: '啟動 TsumTsum 應用程式',
    currentPage: '目前頁面',
    friendsPage: '朋友頁面',
    checkBonusItems: '檢查道具',
    receiveAllGifts: '接收所有禮物',
    receiveGiftsOneByOne: '一個一個接收禮物',
    receiveGiftAgain: '再嘗試接收禮物一次',
    allGiftsReceived: '已接收所有禮物',
    receivingGiftsCompleted: '完成接收禮物',
    checkUnreceivedGift: '檢查未接收的禮物',
    readRecords: '讀取紀錄',
    saveRecords: '儲存紀錄',
    recognizingHeartSender: '辨識送心者',
    calculatingHeartSender: '計算送心者',
    receiveHeartFromHeartSender: '今天送心者已送出',
    recognitionScore: '辨識分數',
    saveNewFriend: '儲存新朋友',
    saveNewFriendAgain: '重新儲存新朋友',
    hearts: '顆愛心',
    startSendingHearts: '開始送愛心',
    checkSendingHearts: '檢查送愛心',
    sendingHearts: '已送出',
    sendingZeroScore: '顆愛心',
    timeIsUp: '送心時間結束',
    tsumsPage: 'Tsum收集页面',
    startUnlockLevel: '检查等级锁定的Tsum',
    endUnlockLevel: '已完成解锁 Tsum 关卡'
};
// Utils for sending message
var _userPlan = -1;
var _lastSendingTime = 0;
/**
 * Whether a host API is actually present. Robotmon builds differ in what they
 * expose, so the callers guard on this before using an optional native.
 */
function checkFunction(f) {
    return typeof (f) == 'function';
}
function checkCanSendMessage() {
    _userPlan = -1;
    if (getUserPlan !== undefined && checkFunction(sendNormalMessage)) {
        _userPlan = getUserPlan();
    }
    console.log('User Plan', _userPlan);
}
function canSendMessage() {
    if (_userPlan === -1) {
        return false;
    }
    var during = Date.now() - _lastSendingTime;
    return _userPlan >= 0 && during > 60 * 60 * 1000;
}
function sendMessage(topMsg, msg) {
    if (canSendMessage()) {
        _lastSendingTime = Date.now();
        console.log(sendNormalMessage(topMsg, msg));
    }
}
checkCanSendMessage();
// Utils for Tsum
function usingTimeString(startTime) {
    return Date.now() - startTime;
}
/** Squared distance -- the callers only ever compare it, so the sqrt is skipped. */
function getDistance(t1, t2) {
    var dx = t1.x - t2.x;
    var dy = t1.y - t2.y;
    return dx * dx + dy * dy;
}
/**
 * Adjacency list over one colour group: `neighbors[i]` holds the indices of the
 * tsums within linking range of `tsums[i]`.
 */
function buildTsumNeighbors(tsums, maxDistSq) {
    var neighbors = [];
    for (var i = 0; i < tsums.length; i++) {
        neighbors.push([]);
    }
    for (var i = 0; i < tsums.length; i++) {
        for (var j = i + 1; j < tsums.length; j++) {
            if (getDistance(tsums[i], tsums[j]) <= maxDistSq) {
                neighbors[i].push(j);
                neighbors[j].push(i);
            }
        }
    }
    return neighbors;
}
/** The connected components of the adjacency list, each a list of node indices. */
function findTsumComponents(neighbors) {
    var n = neighbors.length;
    var seen = new Array(n);
    for (var i = 0; i < n; i++) {
        seen[i] = false;
    }
    var components = [];
    for (var s = 0; s < n; s++) {
        if (seen[s]) {
            continue;
        }
        var comp = [];
        var stack = [s];
        seen[s] = true;
        while (stack.length > 0) {
            var v = stack.pop(); // guarded by the loop condition
            comp.push(v);
            var nbrs = neighbors[v];
            for (var k = 0; k < nbrs.length; k++) {
                if (!seen[nbrs[k]]) {
                    seen[nbrs[k]] = true;
                    stack.push(nbrs[k]);
                }
            }
        }
        components.push(comp);
    }
    return components;
}
// Bounded DFS backtracking — searches for the longest simple path inside one
// connected component. Each starting node gets its own step budget so a
// dead-end branch can't starve the rest of the search. After picking the best
// chain, a second pass tries to extend it from both endpoints into the
// remaining unvisited subgraph, which rescues cases where the initial DFS
// began in the middle of a longer chain and could only walk one direction.
//
// maxLen caps the chain the search may return (Infinity for no cap). It is a
// stopping condition rather than a post-hoc trim: once a chain of that length
// exists there is nothing better to find, so the search returns immediately —
// which is where the speed-up of a short cap comes from.
function findLongestTsumPath(neighbors, comp, budgetPerStart, maxLen) {
    // Bound to a const because `dfs` closes over it; a narrowing on the parameter
    // itself would not survive into the closure.
    var cap = (maxLen === undefined || !(maxLen > 0)) ? Infinity : maxLen;
    var n = neighbors.length;
    var visited = new Array(n);
    var path = [];
    var state = { steps: 0, budget: 0, bestLen: 0, best: null };
    // Order each adjacency list by ascending degree so the search tries the most
    // constrained branches first — dead ends prune quickly and leaves get
    // consumed before they become unreachable.
    var sortedNbrs = new Array(n);
    for (var i = 0; i < n; i++) {
        var arr = neighbors[i].slice();
        arr.sort(function (a, b) { return neighbors[a].length - neighbors[b].length; });
        sortedNbrs[i] = arr;
    }
    function dfs(idx) {
        state.steps++;
        visited[idx] = true;
        path.push(idx);
        if (path.length > state.bestLen) {
            state.bestLen = path.length;
            state.best = path.slice();
        }
        if (state.steps < state.budget && state.bestLen < cap) {
            var nbrs = sortedNbrs[idx];
            for (var k = 0; k < nbrs.length; k++) {
                if (!visited[nbrs[k]]) {
                    dfs(nbrs[k]);
                    if (state.steps >= state.budget || state.bestLen >= cap) {
                        break;
                    }
                }
            }
        }
        visited[idx] = false;
        path.pop();
    }
    function runDfs(startIdx, prefilled) {
        for (var i = 0; i < n; i++) {
            visited[i] = prefilled ? prefilled[i] : false;
        }
        visited[startIdx] = false;
        path.length = 0;
        state.steps = 0;
        state.budget = budgetPerStart;
        state.bestLen = 0;
        state.best = null;
        dfs(startIdx);
        return state.best || [];
    }
    // Sort component nodes by ascending degree — true endpoints (degree 1) lie
    // on long paths and make the best DFS starts.
    var starts = comp.slice();
    starts.sort(function (a, b) { return neighbors[a].length - neighbors[b].length; });
    var globalBest = [];
    var maxStarts = Math.min(starts.length, 6);
    for (var s = 0; s < maxStarts; s++) {
        var candidate = runDfs(starts[s], null);
        if (candidate.length > globalBest.length) {
            globalBest = candidate;
        }
        if (globalBest.length >= comp.length || globalBest.length >= cap) {
            break;
        }
    }
    // Bidirectional extension: if the chain doesn't cover the component, try to
    // extend from each endpoint into the remaining nodes. Recovers chains when
    // DFS started from a node that wasn't a true endpoint.
    if (globalBest.length > 0 && globalBest.length < comp.length && globalBest.length < cap) {
        var inChain = new Array(n);
        for (var i = 0; i < n; i++) {
            inChain[i] = false;
        }
        for (var i = 0; i < globalBest.length; i++) {
            inChain[globalBest[i]] = true;
        }
        for (var e = 0; e < 2; e++) {
            var room = cap - globalBest.length;
            if (room <= 0) {
                break;
            }
            var ep = (e === 0) ? globalBest[0] : globalBest[globalBest.length - 1];
            var extension = runDfs(ep, inChain);
            if (extension.length > 1) {
                // The extension starts on the endpoint itself, so only what follows it
                // is new — and only as much of it as the cap still has room for.
                var extra = extension.slice(1, 1 + room);
                if (e === 0) {
                    extra.reverse();
                    globalBest = extra.concat(globalBest);
                }
                else {
                    globalBest = globalBest.concat(extra);
                }
                for (var i = 0; i < extra.length; i++) {
                    inChain[extra[i]] = true;
                }
            }
        }
    }
    return globalBest;
}
function calculatePaths(board, logs, myTsumIdx, prioritizeMyTsum) {
    var startTime = Date.now();
    var groups = {};
    for (var t in board) {
        var tsum = board[t];
        if (groups[tsum.tsumIdx] === undefined) {
            groups[tsum.tsumIdx] = [];
        }
        groups[tsum.tsumIdx].push(tsum);
    }
    var threshold = Config.tsumWidth * 2.8;
    var maxDistSq = threshold * threshold;
    var paths = [];
    // A cap makes the search stop as soon as a chain that long is found, so short
    // caps also make the scan cheaper — which is the point for tsums that play
    // better on many quick chains than on a few long ones.
    var maxLen = Config.maxChain > 0 ? Config.maxChain : Infinity;
    for (var tsumIdx in groups) {
        var group = groups[tsumIdx];
        if (group.length < 3) {
            continue;
        }
        var neighbors = buildTsumNeighbors(group, maxDistSq);
        var components = findTsumComponents(neighbors);
        for (var c = 0; c < components.length; c++) {
            var comp = components[c];
            if (comp.length < 3) {
                continue;
            }
            // Per-start budget — multiplied across up to 6 starts + 2 extensions.
            var budgetPerStart = Math.min(1500, 100 + comp.length * comp.length * 6);
            var bestIndices = findLongestTsumPath(neighbors, comp, budgetPerStart, maxLen);
            if (bestIndices.length >= 3) {
                var pathPoints = [];
                for (var p = 0; p < bestIndices.length; p++) {
                    pathPoints.push(group[bestIndices[p]]);
                }
                pathPoints.tsumIdx = +tsumIdx;
                paths.push(pathPoints);
            }
        }
    }
    // With "Link MyTsum first" on, MyTsum chains play first (longest first), then
    // other colors by length. Otherwise, just take the longest available chain
    // regardless of color so anything connectable goes out as soon as possible.
    paths.sort(function (a, b) {
        if (prioritizeMyTsum) {
            var aMy = (myTsumIdx >= 0 && a.tsumIdx === myTsumIdx);
            var bMy = (myTsumIdx >= 0 && b.tsumIdx === myTsumIdx);
            if (aMy !== bMy) {
                return aMy ? -1 : 1;
            }
        }
        if (a.length < b.length) {
            return 1;
        }
        return -1;
    });
    debug(logs.calculatedPath, paths.length, '(' + (Date.now() - startTime) + 'ms)');
    // Lengths in play order, which is what "Maximum chain length" and
    // "Chains per board scan" are tuned against. Built lazily: log() only calls
    // the thunk when debug logs are on.
    debug(logs.pathLengths, function () {
        var lens = [];
        for (var i = 0; i < paths.length; i++) {
            lens.push(paths[i].length);
        }
        return lens.join(',');
    });
    return paths;
}
// The longest chain reachable from the tsum nearest to a touch point, in the
// same shape calculatePaths returns. Used by Click Assist: the user points at a
// tsum, this works out which of its color-mates are connected to it and in what
// order to draw them.
function findChainAtTouch(board, touchX, touchY) {
    if (!board || board.length === 0) {
        return null;
    }
    var nearestAllIdx = -1;
    var nearestAllDistSq = Infinity;
    var maxTouchDistSq = (Config.tsumWidth * 1.8) * (Config.tsumWidth * 1.8);
    for (var i = 0; i < board.length; i++) {
        var dx = board[i].x - touchX;
        var dy = board[i].y - touchY;
        var d = dx * dx + dy * dy;
        if (d < nearestAllDistSq) {
            nearestAllDistSq = d;
            nearestAllIdx = i;
        }
    }
    if (nearestAllIdx === -1 || nearestAllDistSq > maxTouchDistSq) {
        return null;
    }
    var tsumIdx = board[nearestAllIdx].tsumIdx;
    var group = [];
    var nearestInGroup = -1;
    for (var i = 0; i < board.length; i++) {
        if (board[i].tsumIdx === tsumIdx) {
            if (i === nearestAllIdx) {
                nearestInGroup = group.length;
            }
            group.push(board[i]);
        }
    }
    if (group.length < 3 || nearestInGroup === -1) {
        return null;
    }
    var threshold = Config.tsumWidth * 2.8;
    var maxDistSq = threshold * threshold;
    var neighbors = buildTsumNeighbors(group, maxDistSq);
    // Flood fill from the touched tsum: only the component it actually belongs to
    // can be linked, however many same-colored tsums sit elsewhere on the board.
    var n = group.length;
    var seen = new Array(n);
    for (var i = 0; i < n; i++) {
        seen[i] = false;
    }
    var queue = [nearestInGroup];
    seen[nearestInGroup] = true;
    var comp = [];
    while (queue.length > 0) {
        var v = queue.shift(); // guarded by the loop condition
        comp.push(v);
        var nbrs = neighbors[v];
        for (var k = 0; k < nbrs.length; k++) {
            if (!seen[nbrs[k]]) {
                seen[nbrs[k]] = true;
                queue.push(nbrs[k]);
            }
        }
    }
    if (comp.length < 3) {
        return null;
    }
    var budgetPerStart = Math.min(1500, 100 + comp.length * comp.length * 6);
    // No cap here: "Maximum chain length" is about how the auto-player paces
    // itself. Click Assist is the user pointing at a chain and asking for it, so
    // it always draws the whole thing.
    var bestIndices = findLongestTsumPath(neighbors, comp, budgetPerStart, Infinity);
    if (bestIndices.length < 3) {
        return null;
    }
    var pathPoints = [];
    for (var p = 0; p < bestIndices.length; p++) {
        pathPoints.push(group[bestIndices[p]]);
    }
    pathPoints.tsumIdx = +tsumIdx;
    return pathPoints;
}
function convertTo2DArray(arr, size) {
    var result = [];
    for (var i = 0; i < arr.length; i = i + size) {
        result.push(arr.slice(i, i + size));
    }
    return result;
}
// Game bubbles are circles too, just a good deal bigger than a tsum, so they
// come out of the same grayscale Hough pass at a larger radius. Runs on the
// board capture the scan already holds, so locating them costs no screenshot --
// which is the point: the taps have to land while the chain is still going off.
function findGameBubbles(img) {
    var cfg = GameBubbleConfig;
    var grayImg = null;
    try {
        var tmpImg = clone(img);
        grayImg = bgrToGray(tmpImg);
        releaseImage(tmpImg);
        smooth(grayImg, 2, 9);
        // houghCircles returns centres, unlike the board points findTsums feeds the
        // pathfinder (those are shifted to a tsum's top-left corner).
        var found = houghCircles(grayImg, 3, 1, cfg.minDist, cfg.param1, cfg.param2, cfg.minRadius, cfg.maxRadius);
        var out = [];
        for (var k in found) {
            out.push({ x: found[k].x, y: found[k].y, r: found[k].r });
        }
        return out;
    }
    finally {
        if (grayImg != null) {
            releaseImage(grayImg);
        }
    }
}
function findTsums(img) {
    // Every native image allocated here must be released even when a native
    // call throws mid-scan: the task controller swallows task errors and
    // retries, so a leak on this hot path would silently recur on every scan.
    var hsvImg = clone(img);
    var grayImg = null;
    var debugImg = null;
    try {
        // Circle detection runs on a plain grayscale copy, NOT a colour mask. The
        // old HSV outRange masks filtered blue tsums out before detection, so their
        // circles were never found and blue chains went unplayed. Grayscale is
        // colour-agnostic: it detects every tsum, and colour is then sampled from
        // the HSV image and clustered separately in classifyTsums.
        var tmpImg = clone(img);
        grayImg = bgrToGray(tmpImg);
        releaseImage(tmpImg);
        smooth(grayImg, 2, 9);
        convertColor(hsvImg, 40);
        // Circle geometry is expressed against the screenResize base (200px) via a
        // scale factor so it can be retuned in one place if that base ever changes.
        var scale = 1;
        var dp = 1; // accumulator resolution (lower = finer)
        var minDist = Math.round(22 * scale); // min gap between circle centers
        var param1 = 20; // Canny high threshold
        var param2 = Math.round(10 * scale); // accumulator vote threshold
        var minRadius = Math.round(8 * scale);
        var maxRadius = Math.round(14 * scale);
        var points = houghCircles(grayImg, 3, dp, minDist, param1, param2, minRadius, maxRadius);
        releaseImage(grayImg);
        grayImg = null;
        if (ts.debug) {
            debugImg = clone(img);
            for (var dk in points) {
                var pt = points[dk];
                drawCircle(debugImg, pt.x, pt.y, minRadius, 255, 0, 0, 1);
            }
            saveImage(debugImg, ts.storagePath + "/tmp/" + ts.runTimes + "-detectedHoughCircles.jpg");
            releaseImage(debugImg);
            debugImg = null;
        }
        // Heavy blur to smear out face features, then a 5-pixel cross average at
        // the circle center.
        smooth(hsvImg, 1, 22);
        var results = [];
        for (var k in points) {
            var p = points[k];
            var hsv1 = void 0, hsv2 = void 0, hsv3 = void 0, hsv4 = void 0, hsv5 = void 0;
            hsv5 = hsv4 = hsv3 = hsv2 = hsv1 = getImageColor(hsvImg, p.x, p.y);
            if (p.x - 1 >= 0) {
                hsv2 = getImageColor(hsvImg, p.x - 1, p.y);
            }
            if (p.x + 1 < Config.screenResize) {
                hsv3 = getImageColor(hsvImg, p.x + 1, p.y);
            }
            if (p.y - 1 >= 0) {
                hsv4 = getImageColor(hsvImg, p.x, p.y - 1);
            }
            if (p.y + 1 < Config.screenResize) {
                hsv5 = getImageColor(hsvImg, p.x, p.y + 1);
            }
            var avgb = (hsv1.b + hsv2.b + hsv3.b + hsv4.b + hsv5.b) / 5;
            var avgg = (hsv1.g + hsv2.g + hsv3.g + hsv4.g + hsv5.g) / 5;
            var avgr = (hsv1.r + hsv2.r + hsv3.r + hsv4.r + hsv5.r) / 5;
            results.push({ x: p.x, y: p.y, z: p.r, b: avgb, g: avgg, r: avgr });
        }
        if (ts.debug) {
            saveImage(hsvImg, ts.storagePath + "/tmp/" + ts.runTimes + "-hsvImg.jpg");
        }
        return results;
    }
    finally {
        if (grayImg != null) {
            releaseImage(grayImg);
        }
        if (debugImg != null) {
            releaseImage(debugImg);
        }
        releaseImage(hsvImg);
    }
}
// Distance between two sampled tsum colors. The image is HSV at this point,
// so b/g/r hold H/S/V.
function distance3D(p1, p2) {
    var d0 = Math.sqrt((p1.b - p2.b) * (p1.b - p2.b) + (p1.g - p2.g) * (p1.g - p2.g) + (p1.r - p2.r) * (p1.r - p2.r));
    if (Math.abs(p1.b - p2.b) < 20) {
        d0 -= 10;
    }
    if (Math.abs(p1.g - p2.g) < 20) {
        d0 -= 10;
    }
    if (p1.r < 120 && p2.r < 120) {
        d0 -= 20;
    }
    return d0;
}
// Greedy single pass against a drifting running mean, fixed merge threshold,
// unbounded cluster count. Each point joins the CLOSEST cluster within the
// threshold rather than the first one found: when two clusters both fall inside
// the merge distance (common once blue variants are detected), first-match
// could bleed a point into the wrong colour and drift both means; nearest-match
// keeps the assignment stable.
function classifyTsums(points) {
    var threshold = 15;
    if (!Array.isArray(points) || points.length === 0) {
        return [];
    }
    var clusters = [];
    for (var i = 0; i < points.length; i++) {
        var p = points[i];
        var bestCluster = null;
        var minDistance = Infinity;
        // Find the closest existing cluster within threshold.
        for (var j = 0; j < clusters.length; j++) {
            var cluster = clusters[j];
            var d = distance3D(cluster, p);
            if (d < threshold && d < minDistance) {
                minDistance = d;
                bestCluster = cluster;
            }
        }
        if (bestCluster) {
            // Add to the nearest cluster and update its running mean colour.
            bestCluster.points.push(p);
            var count = bestCluster.points.length;
            bestCluster.sumb += p.b;
            bestCluster.sumg += p.g;
            bestCluster.sumr += p.r;
            bestCluster.b = bestCluster.sumb / count;
            bestCluster.g = bestCluster.sumg / count;
            bestCluster.r = bestCluster.sumr / count;
        }
        else {
            clusters.push({ sumb: p.b, sumg: p.g, sumr: p.r, b: p.b, g: p.g, r: p.r, points: [p] });
        }
    }
    return clusters;
}
function detectOffsetYInGame() {
    var img = getScreenshot();
    // var img = openImage('/sdcard/img2.jpg');
    try {
        var size = getImageSize(img);
        console.log('deviceW', size.width, 'deviceH', size.height);
        var centerY = Math.floor(size.height / 2);
        // find top black
        var topBlackY = 0;
        var y = void 0;
        var color = void 0;
        for (y = centerY; y >= 0; y--) {
            color = getImageColor(img, size.width * 0.9, y);
            if (isSameColor({ r: 0, g: 0, b: 0 }, color, 6)) {
                // black color found
                topBlackY = y;
                break;
            }
        }
        console.log('topBlackY', topBlackY);
        var bottomBlackY = size.height;
        for (y = centerY; y < size.height; y++) {
            color = getImageColor(img, size.width * 0.9, y);
            if (isSameColor({ r: 0, g: 0, b: 0 }, color, 6)) {
                // black color found
                bottomBlackY = y;
                break;
            }
        }
        console.log('bottomBlackY', bottomBlackY);
        console.log('screenHeight', bottomBlackY - topBlackY + 1);
        return -topBlackY;
    }
    finally {
        releaseImage(img);
    }
}
// Tsum struct
// The 87 methods attached below and in the other six files are declared in
// `interface Tsum` (globals.d.ts), which merges with this class. That is what
// types `this` and the parameters inside every `Tsum.prototype.NAME = function`
// assignment -- they need no annotations of their own.
//
// A class rather than a constructor function purely so `new Tsum(...)` has a
// construct signature and `Tsum.prototype` is typed. At an ES5 target it emits
// the same `var Tsum = (function () { function Tsum(...) {...} return Tsum; }())`
// shape the hand-written version had, and the field declarations below emit
// nothing at all.
var Tsum = /** @class */ (function () {
    function Tsum(isJP, detect, logs) {
        this.debug = false;
        this.autoLaunch = false;
        this.isRunning = true;
        this.isStartupPhase = true;
        this.runTimes = 0;
        this.myTsum = '';
        this.myTsumColor = null;
        this.myTsumIdx = -1;
        this.storagePath = getStoragePath();
        // screen size config
        /** @type {{width: number, height: number}}  */
        var size = getScreenSize();
        this.originScreenWidth = size.width;
        this.originScreenHeight = size.height;
        this.screenHeight = size.height;
        this.screenWidth = size.width;
        this.gameOffsetX = 0;
        this.gameOffsetY = 0;
        this.gameHeight = 0;
        this.gameWidth = 0;
        this.resizeRatio = Math.max(1, this.screenWidth / 360); // normalize page screenshots to 360px width
        this.captureGameRatio = 0;
        // playing game screen size config
        this.playOffsetX = 0;
        this.playOffsetY = 0;
        this.playHeight = 0;
        this.playWidth = 0;
        this.playResizeWidth = Config.screenResize;
        this.playResizeHeight = Config.screenResize;
        this.tsumCount = 5;
        this.maxChainsPerScan = 6;
        // Link MyTsum chains ahead of longer ones of other colors, so the skill gauge
        // fills faster (see calculatePaths). Off by default: it costs raw chain
        // length, and only pays off when the skill is worth more than the tsums.
        this.prioritizeMyTsum = false;
        this.isJP = isJP;
        this.logs = logs;
        this.scoreItem = false;
        this.coinItem = false;
        this.expItem = false;
        this.timeItem = false;
        this.bubbleItem = false;
        this.comboItem = false;
        this.isPause = false;
        this.receiveOneItem = false;
        this.sentToZero = false;
        this.recordReceive = true;
        this.skillInterval = 3000;
        this.skillLevel = 3;
        this.skillType = "" /* SkillType.Unset */;
        // Bubble positions from the last board scan, tapped after a long chain.
        this.gameBubbles = [];
        // Optional safety poll: fire the skill the instant it's ready, even mid-link,
        // rather than only at the end of each board-scan cycle (see maybeAutoTapSkill).
        this.skillAutoTap = false;
        this.skillAutoTapInterval = 500;
        this._lastSkillAutoTap = 0;
        // Burst-skill overload: set after a link batch so the next scan issues one
        // carry-over tap on the skill button (see link / scanBoardQuick).
        this.overloadPending = false;
        this.unlockLevelHoursWait = 0;
        this.sendHearts = false;
        this.keepRuby = false;
        this.showHeartLog = true;
        this.sendHeartMaxDuring = 0;
        this.useFan = true;
        // record
        this.record = {
            hearts_count: {
                receivedCount: 0,
                sentCount: 0
            }
        };
        this.recordImages = {};
        // Cap on sender portraits kept in native memory for matching (the on-disk
        // PNGs and record.txt stats are unaffected). Unbounded retention grew with
        // every recorded friend and dragged emulator FPS down over long sessions.
        this.maxRecordImages = 200;
        this.receiveCheckLimit = 5;
        this.clearBubbles = true;
        this.autobuyBoxes = 0;
        this.noSkillLastFeverSec = 0;
        this.claimAllWithoutCoins = false;
        this.nextMonitorExecution = 0;
        this.lastVisitedPages = { init1: true, init2: true, init3: true }; // trigger initial monitor call on script startup
        // Layer 2 watchdog: track when the game last made progress. _lastProgress is
        // bumped whenever new lastVisitedPages keys appear; if it stalls past the
        // threshold the watchdog restarts the app.
        this._lastProgress = Date.now();
        this._lastSeenCount = 3; // matches the 3 init keys above
        this.stuckTimeoutMs = 180 * 1000;
        // "Handle Long Skill Animations": off means TsumBeta's original game-over
        // check (one 500ms recheck, then assume the game ended), on means the
        // positive confirmation in confirmGameOver.
        this.handleLongSkillAnimations = false;
        // How long the play loop tolerates an unrecognized screen before accepting
        // game over (see confirmGameOver). Must outlast the longest burst-skill
        // animation; a real game over exits earlier via ScorePage detection.
        this.gameOverGraceMs = 20 * 1000;
        this.sendHeartsDownwards = true;
        // Both were previously left undefined and read through `|| 0` guards; seeding
        // them here is the same value on every read, just stated once.
        this._uiDumpFailures = 0;
        this._lastDebugShot = 0;
        this.init(detect);
    }
    return Tsum;
}());
Tsum.prototype.init = function (detect) {
    log(this.logs.calculateScreenSize);
    var isFat = false;
    if (this.screenHeight / this.screenWidth < 1.5) {
        isFat = true;
        this.gameHeight = this.screenHeight;
        this.gameWidth = this.screenHeight / 1.5;
        this.gameOffsetY = Math.floor((this.gameWidth * 16 / 9 - this.gameHeight) / 2);
        this.gameOffsetX = Math.floor((this.gameWidth - this.screenWidth) / 2);
    }
    else {
        this.gameWidth = this.screenWidth;
        this.gameHeight = this.screenWidth / 9 * 16;
        this.gameOffsetX = 0;
        this.gameOffsetY = Math.floor((this.gameHeight - this.screenHeight) / 2);
        console.log('??', this.gameHeight, this.screenHeight, this.gameWidth);
    }
    if (detect && this.screenHeight / this.screenWidth > 16 / 9) {
        log('detect screen size (special screen ratio)');
        this.gameWidth = this.screenWidth;
        this.gameHeight = this.gameWidth * 1.5;
        this.gameOffsetX = 0;
        this.gameOffsetY = detectOffsetYInGame();
    }
    this.captureGameRatio = this.gameWidth / 1080;
    if (isFat) {
        this.playWidth = this.gameWidth;
        this.playOffsetX = Math.max(-this.gameOffsetX, 0);
    }
    else {
        this.playWidth = this.screenWidth;
        this.playOffsetX = 0;
    }
    // noinspection JSSuspiciousNameCombination
    this.playHeight = this.playWidth; // game has square dimension
    this.playOffsetY = PlayAreaTopY * this.captureGameRatio - this.gameOffsetY;
    this.sleep(200);
    log(this.logs.offset, this.gameOffsetX, this.gameOffsetY, this.screenHeight, this.screenWidth);
    this.sleep(1000);
    execute("mkdir -p " + this.storagePath + '/tmp');
    this.sleep(200);
    execute("mkdir -p " + this.storagePath + '/' + Config.recordDir);
};
Tsum.prototype.sendMoneyInfo = function () {
    if (!canSendMessage()) {
        return;
    }
    var x = Math.floor(Button.moneyInfoBox.x * this.captureGameRatio - this.gameOffsetX);
    var y = Math.floor(Button.moneyInfoBox.y * this.captureGameRatio - this.gameOffsetY);
    var w = Math.floor(Button.moneyInfoBox.w * this.captureGameRatio);
    var h = Math.floor(Button.moneyInfoBox.h * this.captureGameRatio);
    var img = getScreenshotModify(x, y, w, h, Button.moneyInfoBox.w / 2, Button.moneyInfoBox.h / 2, 80);
    var base64;
    try {
        base64 = getBase64FromImage(img);
    }
    finally {
        releaseImage(img);
    }
    log(this.logs.sendMessage);
    sendMessage("Tsum Tsum", base64);
};
Tsum.prototype.isAppOn = function () {
    if (!this.autoLaunch) {
        return true;
    }
    var result = execute('dumpsys window').split('mCurrentFocus');
    if (result.length < 2) {
        return false;
    }
    result = result[1].split(" ");
    if (result.length < 3) {
        return false;
    }
    result = result[2].split("/");
    if (result.length < 2) {
        return false;
    }
    var packageName = result[0];
    return packageName.indexOf('LGTMTM') !== -1;
};
function getPackageName(isJP) {
    var packageName = 'com.linecorp.LGTMTM';
    if (!isJP) {
        packageName += 'G';
    }
    return packageName;
}
// Robotmon's shell starts without a BOOTCLASSPATH, so java-backed commands
// (`am`, `uiautomator`) cannot boot their VM without this prefix.
var ShellBootClassPath = 'BOOTCLASSPATH=/system/framework/core.jar:/system/framework/conscrypt.jar:/system/framework/okhttp.jar:/system/framework/core-junit.jar:/system/framework/bouncycastle.jar:/system/framework/ext.jar:/system/framework/framework.jar:/system/framework/framework2.jar:/system/framework/telephony-common.jar:/system/framework/voip-common.jar:/system/framework/mms-common.jar:/system/framework/android.policy.jar:/system/framework/services.jar:/system/framework/apache-xml.jar:/system/framework/webviewchromium.jar';
function startTsumTsumApp(isJP) {
    var packageName = getPackageName(isJP);
    execute(ShellBootClassPath +
        ' am start --activity-single-top -n ' + packageName + '/com.linecorp.LGTMTM.TsumTsum');
}
Tsum.prototype.startApp = function () {
    if (!this.autoLaunch) {
        return;
    }
    log(this.logs.startTsumTsumApp);
    startTsumTsumApp(this.isJP);
    this.sleep(10000);
    log("TsumTsum app starting.");
};
// Bounce the game app. Deliberately does not navigate anywhere afterwards (that
// is taskTsumAppRestart's job) so the recovery paths inside the navigation loops
// can call it without recursing back into themselves.
Tsum.prototype.forceRestartApp = function () {
    if (!this.autoLaunch) {
        log("Not restarting the game app: 'Auto launch app' is off.");
        return false;
    }
    execute("am force-stop " + getPackageName(this.isJP));
    this.sleep(3000);
    this.isStartupPhase = true;
    this.startApp();
    return true;
};
Tsum.prototype.screenshot = function () {
    return getScreenshotModify(0, 0, this.originScreenWidth, this.originScreenHeight, this.originScreenWidth / this.resizeRatio, this.originScreenHeight / this.resizeRatio, 80);
};
Tsum.prototype.playScreenshotSquare = function () {
    return getScreenshotModify(this.playOffsetX, this.playOffsetY, this.playWidth, this.playHeight, this.playResizeWidth, this.playResizeHeight, 100);
};
Tsum.prototype.toResizeXY = function (x, y) {
    var rx = Math.floor((x * this.captureGameRatio - this.gameOffsetX) / this.resizeRatio);
    var ry = Math.floor((y * this.captureGameRatio - this.gameOffsetY) / this.resizeRatio);
    return { x: rx, y: ry };
};
Tsum.prototype.toResizeXYs = function (xy) {
    return this.toResizeXY(xy.x, xy.y);
};
Tsum.prototype.getColor = function (img, xy) {
    var rxy = this.toResizeXYs(xy);
    return getImageColor(img, Math.max(rxy.x, 0), Math.max(rxy.y, 0));
};
Tsum.prototype.toRealXY = function (x, y) {
    var rx = Math.floor(x * this.captureGameRatio - this.gameOffsetX);
    var ry = Math.floor(y * this.captureGameRatio - this.gameOffsetY);
    return { x: rx, y: ry };
};
Tsum.prototype.toRealXYs = function (xy) {
    return this.toRealXY(xy.x, xy.y);
};
Tsum.prototype.tap = function (xy, during) {
    if (during === undefined) {
        during = 50;
    }
    var rxy = this.toRealXYs(xy);
    tap(rxy.x, rxy.y, during);
};
Tsum.prototype.tapDown = function (xy, during) {
    if (during === undefined) {
        during = 50;
    }
    var rxy = this.toRealXYs(xy);
    tapDown(rxy.x, rxy.y, during);
};
Tsum.prototype.moveTo = function (xy, during) {
    if (during === undefined) {
        during = 50;
    }
    var rxy = this.toRealXYs(xy);
    moveTo(rxy.x, rxy.y, during);
};
Tsum.prototype.tapUp = function (xy, during) {
    if (during === undefined) {
        during = 50;
    }
    var rxy = this.toRealXYs(xy);
    tapUp(rxy.x, rxy.y, during);
};
Tsum.prototype.linkTsums = function (path) {
    // Drag timings (ms), held identical to TsumBeta so the two scripts can be
    // compared without the input path being a variable.
    //
    // These were 30/20/20 here for a while: at 10ms the game was observed to
    // miss the initial press or skip intermediate tsums, so a found 3+ chain
    // never cleared. If that shows up again it will show up in Beta too — raise
    // both together, or the comparison stops meaning anything.
    var grabDuring = 10;
    var moveDuring = 10;
    var releaseDuring = 10;
    for (var j = 0; j < path.length; j++) {
        var point = path[j];
        var x = Math.floor(this.playOffsetX + (point.x + Config.tsumWidth / 2) * this.playWidth / this.playResizeWidth);
        var y = Math.floor(this.playOffsetY + (point.y + Config.tsumWidth / 2) * this.playHeight / this.playResizeHeight);
        if (j === 0) {
            tapDown(x, y, grabDuring);
        }
        moveTo(x, y, moveDuring);
        if (j === path.length - 1) {
            tapUp(x, y, releaseDuring);
        }
    }
};
// Tap the bubbles the last board scan found. Taps only -- the positions were
// worked out at scan time -- so this stays inside the window where the chain is
// still clearing. A tap that misses costs nothing: it is not a drag, so it
// links nothing and the game ignores it.
Tsum.prototype.popGameBubbles = function () {
    var bubbles = this.gameBubbles;
    if (!bubbles || bubbles.length === 0) {
        return;
    }
    var cfg = GameBubbleConfig;
    var count = Math.min(bubbles.length, cfg.maxTaps);
    for (var i = 0; i < count; i++) {
        var b = bubbles[i];
        var x = Math.floor(this.playOffsetX + b.x * this.playWidth / this.playResizeWidth);
        var y = Math.floor(this.playOffsetY + b.y * this.playHeight / this.playResizeHeight);
        tap(x, y, cfg.tapDuring);
    }
    if (this.debug) {
        console.log('[Bubbles] popped ' + count);
    }
    // A bubble only pops once; forget them until the next scan finds them again.
    this.gameBubbles = [];
};
Tsum.prototype.link = function (paths, board) {
    var isBubble = false;
    // Overloading (burst skills): erased MyTsums keep counting into the gauge
    // for a moment after the drag, and firing the skill right as the gauge tops
    // off lets the rest of that count spill into the next gauge instead of
    // capping at 100%. Tapping a not-yet-full skill button is a no-op the game
    // ignores, so the cheap way to catch the fill instant is a single
    // fire-and-forget tap after each drag: no screenshots, no waits (a gauge
    // check costs ~10x a tap), no change to the link cadence. The game itself
    // fires the skill on whichever tap lands first after the gauge fills.
    // Choreographed skills can't ride blind taps (activating without the
    // follow-up aiming wastes the skill) and go through maybeAutoTapSkill,
    // which verifies readiness before handing over to useSkill.
    // TODO: Revisit this after refactor merge
    // const blindTap = skillBareTapActivates(this.skillType);
    for (var i in paths) {
        var path = paths[i];
        // >= 7 should be correct, but practically the real chain is always shorter
        // so using a bigger value than theoretically correct
        if (path.length >= 12) {
            isBubble = true;
        }
        this.linkTsums(path);
        // Pop whatever the last scan saw the moment a long chain lands: with Tiara
        // Minnie+ a bubble popped as a chain goes off clears a bigger area.
        if (path.length >= GameBubbleConfig.minChainForPop) {
            this.popGameBubbles();
        }
        // if (blindTap) {
        //   this.tap(Button.gameSkill1, 10);
        // } else {
        //   // Linking a full batch of chains can take several seconds; check between
        //   // chains so a gauge that fills mid-batch fires right away.
        //   this.maybeAutoTapSkill(board);
        // }
        // Linking a full batch of chains can take several seconds; check between
        // chains so a gauge that fills mid-batch fires right away.
        this.maybeAutoTapSkill(board);
    }
    // if (blindTap && paths.length > 0) {
    //   // The last chains' count-in lands after the batch: one spaced tail tap
    //   // now, one more after the next scan's capture (overloadPending).
    //   this.sleep(60);
    //   this.tap(Button.gameSkill1, 10);
    //   this.overloadPending = true;
    // }
    return isBubble;
};
Tsum.prototype.findPageObject = function (times, timeout) {
    if (times === undefined) {
        times = 2;
    }
    if (timeout === undefined) {
        timeout = 700;
    }
    var start = Date.now();
    var page = null;
    while (this.isRunning) {
        var currentPage = null;
        for (var t = 0; t < times; t++) {
            var img = this.screenshot();
            try {
                // Walks the whole table by key, so it needs the index-signature view of
                // it rather than the literal type that gives Page.X its click-through.
                for (var key in Page) {
                    page = Page[key];
                    currentPage = null;
                    var pageColors = page.colors || [];
                    for (var i = 0; i < pageColors.length; i++) {
                        var diff = absColor(pageColors[i], this.getColor(img, pageColors[i]));
                        if ((diff < pageColors[i].threshold) === pageColors[i].match) {
                            currentPage = page;
                        }
                        else {
                            currentPage = null;
                            break;
                        }
                    }
                    if (currentPage !== null) {
                        debug(this.logs.currentPage, currentPage.name + ' (' + key + ')', 'findPageObject');
                        break;
                    }
                }
            }
            finally {
                releaseImage(img);
            }
            this.sleep(100);
        } // for times
        if (currentPage !== null) {
            // trigger callback if defined
            if (typeof currentPage.onDetect === "function") {
                var callback = currentPage.onDetect;
                log("Applying fn " + callback.name + "...");
                callback.apply(this);
                log("Applied fn " + callback.name + ".");
            }
            return currentPage;
        }
        if (Date.now() - start > timeout) {
            return null;
        }
    }
    // Reached only when isRunning went false mid-scan (the script is stopping).
    // Previously fell through to `undefined`; every caller tests `!= null`, so
    // returning null here is the same to all of them and honest about the type.
    return null;
};
Tsum.prototype.findPage = function (times, timeout) {
    var page = this.findPageObject(times, timeout);
    if (page !== null) {
        var name_3 = page.name;
        switch (name_3) {
            case "GamePause":
            case "GamePlaying":
            case "StartPage":
            case "TsumsPage":
            case "TsumTsumStorePage":
                this.isStartupPhase = false;
        }
    }
    return page != null ? page.name : "unknown" /* PageName.Unknown */;
};
Tsum.prototype.matchesPage = function (pageName) {
    var found = false;
    var img = null;
    try {
        for (var pageId in Page) {
            var page = Page[pageId];
            if (pageName === page.name) {
                if (img == null) {
                    // lazy init only if page exists
                    img = this.screenshot();
                }
                var colors = page.colors || [];
                found = false;
                for (var i = 0; i < colors.length; i++) {
                    var color = colors[i];
                    found = isSameColor(this.getColor(img, color), color, 20);
                    if (!found) {
                        break; // try next page
                    }
                }
                if (found)
                    break; // exit search
            }
        }
    }
    finally {
        if (img != null) {
            releaseImage(img);
        }
    }
    debug("*** Found", pageName, "=", found);
    return found;
};
Tsum.prototype.exitUnknownPage = function () {
    // A native dialog (root warning, permission prompt) is not a game screen, and
    // the blind keycodes below can activate its *negative* button -- "REFUSE" on
    // the root warning quits the game. Handle it properly and leave.
    if (this.dismissSystemDialog()) {
        return;
    }
    keycode("KEYCODE_DPAD_DOWN" /* KeyCode.DpadDown */, 50);
    this.sleep(500);
    keycode("KEYCODE_ENTER" /* KeyCode.Enter */, 50);
    this.tap(Button.gameQuestionCancel);
    this.tap(Button.gameQuestionCancel2);
    this.tap(Button.outClose);
    this.tap(Button.gameStop);
    this.sleep(500);
};
Tsum.prototype.goFriendPage = function () {
    var guard = this.newStallGuard('goFriendPage');
    while (this.isRunning) {
        if (!this.isAppOn()) {
            this.startApp();
        }
        if (this.isStartupPhase) {
            // sleep longer to safely detect new event windows which might initially take longer to load
            this.sleep(5000);
        }
        var pageObj = this.findPageObject(2, 1000);
        // `page` is derived from `pageObj`, so every branch below other than
        // 'unknown' implies pageObj is non-null -- a correlation the compiler
        // cannot see, hence the `!`s.
        var page = pageObj != null ? pageObj.name : "unknown" /* PageName.Unknown */;
        log(this.logs.currentPage, page, "goFriend");
        if (page === "FriendPage" /* PageName.FriendPage */) {
            // check again with 3 seoconds delay (Event notification/page might fly in)
            this.sleep(3000);
            page = this.findPage(1, 500);
            if (page === "FriendPage" /* PageName.FriendPage */) {
                this.sendMoneyInfo();
                this.isStartupPhase = false;
                return;
            }
        }
        else if (page === "RootDetection" /* PageName.RootDetection */) {
            // Never tap the recorded coordinates blind: they belong to whichever
            // emulator/dpi variant matched, which is not necessarily this device.
            this.dismissSystemDialog(pageObj.next);
        }
        else if (page === "ClosePage" /* PageName.ClosePage */) {
            this.tap(pageObj.back);
            this.tap({ x: 310, y: 1588 - 140 });
        }
        else if (page === "unknown" /* PageName.Unknown */) {
            this.exitUnknownPage();
        }
        else {
            this.tap(pageObj.back);
        }
        this.checkStall(guard, page);
        this.sleep(1000);
    }
};
Tsum.prototype.checkGameItem = function () {
    // Same positions as Button.outGameItems; the two tuples share the order.
    var isItemsOn = [false, false, false, false, false, false, false];
    if (this.scoreItem) {
        isItemsOn[0] = true;
    }
    if (this.coinItem) {
        isItemsOn[1] = true;
    }
    if (this.expItem) {
        isItemsOn[2] = true;
    }
    if (this.timeItem) {
        isItemsOn[3] = true;
    }
    if (this.bubbleItem) {
        isItemsOn[4] = true;
    }
    if (this.tsumCount === 4) {
        isItemsOn[5] = true;
    }
    if (this.comboItem) {
        isItemsOn[6] = true;
    }
    for (var t = 0; t < 3; t++) {
        var img = this.screenshot();
        var isChange = false;
        try {
            for (var i = 0; i < Button.outGameItems.length; i++) {
                var c = this.getColor(img, Button.outGameItems[i]);
                if (c.b > 128) { // off
                    if (isItemsOn[i]) {
                        this.tap(Button.outGameItems[i]);
                        isChange = true;
                        this.sleep(500);
                    }
                }
                else { // on
                    if (!isItemsOn[i]) {
                        this.tap(Button.outGameItems[i]);
                        isChange = true;
                        this.sleep(500);
                    }
                }
            }
        }
        finally {
            releaseImage(img);
        }
        console.log("Bonus items changed = " + isChange);
        if (!isChange) {
            break;
        }
        this.sleep(500);
    }
    debug(this.logs.checkBonusItems, isItemsOn);
};
Tsum.prototype.goGamePlayingPage = function () {
    var guard = this.newStallGuard('goGamePlayingPage');
    while (this.isRunning) {
        if (!this.isAppOn()) {
            this.startApp();
        }
        var pageObj = this.findPageObject(2, 2000);
        // See goFriendPage on the `!`s: a non-'unknown' page implies a non-null
        // pageObj, which the compiler cannot derive.
        var page = pageObj != null ? pageObj.name : "unknown" /* PageName.Unknown */;
        log(this.logs.currentPage, page, "play");
        switch (page) {
            case "RootDetection" /* PageName.RootDetection */: {
                this.dismissSystemDialog(pageObj.next);
                this.sleep(1000);
                break;
            }
            case "FriendPage" /* PageName.FriendPage */: {
                this.tap(pageObj.next);
                this.sleep(3000);
                this.lastVisitedPages.gameFriend = true;
                break;
            }
            case "StartPage" /* PageName.StartPage */: {
                this.sleep(500);
                this.checkGameItem();
                this.sendMoneyInfo();
                this.tap(Button.outStart);
                this.sleep(5000); // avoid checking items again!
                this.lastVisitedPages.gameStart = true;
                break;
            }
            case "GamePlaying" /* PageName.GamePlaying */: {
                page = this.findPage(1, 500);
                if (page === "GamePlaying" /* PageName.GamePlaying */) {
                    this.isStartupPhase = false;
                    return;
                }
                break;
            }
            case "GamePause" /* PageName.GamePause */: {
                this.isStartupPhase = false;
                this.tap(pageObj.next);
                this.sleep(500);
                break;
            }
            case "unknown" /* PageName.Unknown */: {
                this.exitUnknownPage();
                break;
            }
            case "ClosePage" /* PageName.ClosePage */: {
                this.tap(Page.ClosePage.back);
                this.tap({ x: 310, y: 1588 - 140 });
                this.sleep(1000);
                break;
            }
            default: {
                this.tap(pageObj.back);
                this.sleep(1000);
            }
        }
        this.checkStall(guard, page);
    }
};
Tsum.prototype.goTsumsPage = function () {
    if (!this.isAppOn()) {
        this.startApp();
    }
    this.goFriendPage();
    var guard = this.newStallGuard('goTsumsPage');
    while (this.isRunning) {
        var page = this.findPageObject(2, 2000);
        if (page != null)
            log(this.logs.currentPage, page.name, "goTsumPage");
        if (page === null) {
            this.exitUnknownPage();
        }
        else if (page.name === "TsumsPage" /* PageName.TsumsPage */) {
            // check again
            page = this.findPageObject(1, 500);
            if (page != null && page.name === "TsumsPage" /* PageName.TsumsPage */) {
                return;
            }
        }
        else if (page.name === "RootDetection" /* PageName.RootDetection */) {
            this.dismissSystemDialog(page.next);
            this.sleep(1000);
        }
        else if (page.hasOwnProperty('tsums')) {
            this.tap(page.tsums); // the hasOwnProperty check above is the guard
            this.sleep(3000);
        }
        else {
            this.tap(page.back);
            this.sleep(1000);
        }
        this.checkStall(guard, page === null ? "unknown" /* PageName.Unknown */ : page.name);
    }
};
Tsum.prototype.goTsumTsumStorePage = function () {
    if (this.isRunning) {
        if (!this.isAppOn()) {
            this.startApp();
        }
        this.goTsumsPage();
        var pageName = "undefined";
        var page = null;
        for (var i = 0; i < 3; i++) {
            // Unguarded on purpose -- this is pre-existing behaviour, and both `!`s
            // mark a real crash risk: goTsumsPage() above only returns on TsumsPage,
            // but a page fingerprinted without a `store` anchor would throw here.
            this.tap(this.findPageObject().store);
            this.sleep(3000);
            page = this.findPageObject(5, 2000);
            pageName = page != null ? page.name : "unknown" /* PageName.Unknown */;
            log("Pg: ", pageName);
            if (page !== null && page.name === "TsumTsumStorePage" /* PageName.TsumTsumStorePage */) {
                var img = this.screenshot();
                var nextColor = void 0;
                try {
                    nextColor = this.getColor(img, page.next);
                }
                finally {
                    releaseImage(img);
                }
                return isSameColor(page.next, nextColor, 50);
            }
        }
        log('Unexpected page found:', page, 'goTsumTsumStorePage');
        return false;
    }
    return false; // not running: nothing was opened
};
Tsum.prototype.clearAllBubbles = function (startDelay, endDelay, fromY, delayBetweenLines) {
    delayBetweenLines = delayBetweenLines || 0;
    if (typeof startDelay === 'number' && startDelay > 0) {
        this.sleep(startDelay);
    }
    var fy = Button.gameBubblesFrom.y;
    if (typeof fromY == 'number') {
        fy = fromY;
    }
    for (var by = fy; by <= Button.gameBubblesTo.y; by += 140) {
        for (var bx = Button.gameBubblesFrom.x; bx <= Button.gameBubblesTo.x; bx += 140) {
            this.tap({ x: bx, y: by }, 10);
        }
        this.sleep(delayBetweenLines);
    }
    if (typeof endDelay === 'number' && endDelay > 0) {
        this.sleep(endDelay);
    }
};
Tsum.prototype.sampleMyTsumColor = function () {
    // The MyTsum portrait is the circular icon inside the skill button at the
    // bottom-left of the play area. Sample a small region around its center,
    // run the same smooth + HSV pipeline as findTsums, and average central
    // pixels so the result is directly comparable to tsum cluster colors.
    var center = this.toRealXY(Button.gameSkill1.x, Button.gameSkill1.y);
    var sampleR = Math.max(4, Math.floor(40 * this.captureGameRatio));
    var x = Math.max(0, center.x - sampleR);
    var y = Math.max(0, center.y - sampleR);
    var img = getScreenshotModify(x, y, sampleR * 2, sampleR * 2, 40, 40, 100);
    try {
        smooth(img, 1, 7);
        convertColor(img, 40);
        smooth(img, 1, 22);
        var sumB = 0, sumG = 0, sumR = 0, count = 0;
        for (var dy = -3; dy <= 3; dy++) {
            for (var dx = -3; dx <= 3; dx++) {
                var c = getImageColor(img, 20 + dx, 20 + dy);
                sumB += c.b;
                sumG += c.g;
                sumR += c.r;
                count++;
            }
        }
        return { b: sumB / count, g: sumG / count, r: sumR / count };
    }
    finally {
        releaseImage(img);
    }
};
Tsum.prototype.scanBoardQuick = function () {
    // load game tsums
    var startTime = Date.now();
    var srcImg = this.playScreenshotSquare();
    // Overload carry-over: the last batch's count-in may top the gauge off
    // during this scan; one blind tap catches it. After the capture so the tap
    // can't disturb the frame; skipped in pause mode (the pause menu is open).
    if (this.overloadPending) {
        this.overloadPending = false;
        if (!this.isPause) {
            this.tap(Button.gameSkill1, 10);
        }
    }
    var board = [];
    try {
        if (this.isPause) {
            this.tap(Button.gamePause);
            this.sleep(20);
            this.tap(Button.gamePause);
        }
        var points = findTsums(srcImg);
        // Read bubble positions off this same capture and remember them, so popping
        // one after a chain is taps only -- no screenshot in the middle of a batch,
        // which would stall the link cadence and the combo timer with it. Bubbles
        // are big and drift slowly, so a position a second old still lands.
        this.gameBubbles = findGameBubbles(srcImg);
        if (this.debug && this.gameBubbles.length > 0) {
            console.log('[Bubbles] found ' + this.gameBubbles.length);
        }
        debug(this.logs.recognitionStart);
        var tcs = classifyTsums(points);
        tcs.sort(function (a, b) { return a.points.length > b.points.length ? -1 : 1; });
        if (this.debug) {
            // HSV cluster centers — compare these (and the inter-cluster distance3D)
            // against the boardImg circles when tuning the color-clustering settings.
            for (var ci = 0; ci < tcs.length; ci++) {
                var line = 'cluster ' + ci + ': n=' + tcs[ci].points.length
                    + ' hsv=(' + Math.round(tcs[ci].b) + ',' + Math.round(tcs[ci].g) + ',' + Math.round(tcs[ci].r) + ')';
                for (var cj = 0; cj < ci; cj++) {
                    line += ' d' + cj + '=' + Math.round(distance3D(tcs[ci], tcs[cj]));
                }
                console.log(line);
            }
        }
        // Identify which color cluster (if any) is the player's MyTsum by matching
        // the skill-button portrait color against cluster centers. Only the
        // "Link MyTsum first" setting reads myTsumIdx, so with it off the whole
        // thing is skipped -- the portrait sample is a screenshot per game.
        this.myTsumIdx = -1;
        if (this.prioritizeMyTsum) {
            if (!this.myTsumColor) {
                this.myTsumColor = this.sampleMyTsumColor();
                if (this.debug) {
                    console.log('MyTsum color', JSON.stringify(this.myTsumColor));
                }
            }
            var bestMyDist = 30;
            for (var ci = 0; ci < tcs.length && ci < this.tsumCount - 1; ci++) {
                var dMy = distance3D(tcs[ci], this.myTsumColor);
                if (dMy < bestMyDist) {
                    bestMyDist = dMy;
                    this.myTsumIdx = ci;
                }
            }
        }
        for (var i in tcs) {
            if (+i >= this.tsumCount - 1) {
                break;
            }
            var tc = tcs[i];
            for (var j in tc.points) {
                var p = tc.points[j];
                board.push({ tsumIdx: i, x: p.x - (Config.tsumWidth / 2), y: p.y - (Config.tsumWidth / 2) });
                if (this.debug) {
                    drawCircle(srcImg, p.x, p.y, 4, Config.colors[i][0], Config.colors[i][1], Config.colors[i][2], 0);
                }
            }
        }
        if (this.debug) {
            saveImage(srcImg, this.storagePath + "/tmp/" + ts.runTimes + "-boardImg.jpg");
        }
    }
    finally {
        releaseImage(srcImg);
    }
    debug(this.logs.recognizedTsums, board.length);
    sleep(30);
    debug(this.logs.recognitionTime, usingTimeString(startTime));
    if (this.isPause) {
        this.sleep(Config.gameContinueDelay);
        this.tap(Button.gameContinue);
        this.sleep(Config.gameContinueDelay / 2);
        this.tap(Button.gameContinue);
        this.sleep(Config.gameContinueDelay / 2);
    }
    return board;
};
// GamePlaying is recognized by HUD pixels on the pause/fan buttons, and a
// long burst-skill animation (e.g. Dapper Hat Mickey) covers them for longer
// than the old two-check window (~5s) while the game is still running — the
// play loop would bail mid-game and stall on the "unknown" screen. So an
// unrecognized screen alone is not proof of game over; require positive
// confirmation instead: a game that really ends always reaches a known
// out-of-game page (the score tally lands on ScorePage). Poll until the HUD
// comes back (still playing), a known page shows up (game over), or the
// grace window runs out (assume over — the old behavior, just later).
Tsum.prototype.confirmGameOver = function () {
    log(this.logs.confirmingGameOver);
    var deadline = Date.now() + this.gameOverGraceMs;
    while (this.isRunning) {
        var page = this.findPage(1, 1500);
        if (page === "GamePlaying" /* PageName.GamePlaying */ || page === "GamePause" /* PageName.GamePause */) {
            return false;
        }
        if (page !== "unknown" /* PageName.Unknown */) {
            return true;
        }
        if (Date.now() > deadline) {
            return true;
        }
        this.sleep(250);
    }
    return true;
};
Tsum.prototype.taskPlayGameQuick = function () {
    this.requestTsumMonitor();
    log(this.logs.gameStart);
    this.goGamePlayingPage();
    log(this.logs.fastGaming);
    if (this.isPause) {
        this.sleep(350);
    }
    this.runTimes = 0;
    this.myTsumColor = null; // re-sample MyTsum portrait at the start of each game
    this.myTsumIdx = -1;
    this.overloadPending = false;
    var clearBubbles = 0;
    var zeroPath = 0;
    while (this.isRunning) {
        var board = this.scanBoardQuick();
        if (board == null) {
            break;
        }
        debug(this.logs.calculationPathStart);
        var paths = calculatePaths(board, this.logs, this.myTsumIdx, this.prioritizeMyTsum);
        // Each linked chain is a clear that refreshes the combo timer; the combo
        // is only at risk during the scan gap between batches. More chains per
        // scan means fewer gaps, but chains linked late in a batch can miss
        // because earlier clears already reshuffled the board.
        paths = paths.splice(0, this.maxChainsPerScan);
        // Catch a gauge that filled during the scan/calculation above before linking.
        this.maybeAutoTapSkill(board);
        var isBubble = this.link(paths, board);
        if (isBubble) {
            debug(this.logs.bubbleGenerated);
            clearBubbles++;
        }
        if (paths.length < 3) {
            zeroPath++;
            if (zeroPath === 6) {
                // Same guard as the periodic fan below. Without it this fires the fan
                // with the skill already full, and useSkill() runs immediately after --
                // so the skill activates onto a board that is still being tossed about.
                // It also self-sustains: a churning board scans as few paths, which is
                // what increments this counter in the first place.
                if (!this.fanWouldBeWasted()) {
                    this.tap(Button.gameRand, 60);
                    this.tap(Button.gameRand, 60);
                }
                zeroPath = 0;
            }
        }
        else {
            // Counts *consecutive* barren scans: a board that is producing chains is
            // not stuck, and letting the count carry over between them fires the fan
            // on a board that never needed shuffling.
            zeroPath = 0;
        }
        // click bubbles
        if (this.clearBubbles && clearBubbles >= 2) {
            debug(this.logs.clearBubbles);
            clearBubbles = 0;
            // only clearing lower area in order to speed up the cleaning process
            this.clearAllBubbles(0, 0, (Button.gameBubblesFrom.y + Button.gameBubblesTo.y) / 2);
        }
        if (this.useFan && this.runTimes % 4 === 3) {
            // Skip the fan when the skill is ready or about to be — useSkill() will
            // fire it next (or the next clear will fill the gauge), so the fan would
            // just be wasted on tsums about to be cleared.
            if (!this.fanWouldBeWasted()) {
                this.tap(Button.gameRand, 60);
                this.tap(Button.gameRand, 60);
            }
        }
        if (this.isPause) {
            this.sleep(300);
        }
        while (this.useSkill(board)) {
            if (this.skillType !== "block_cpt_ly_s" /* SkillType.CptLightyear */) {
                clearBubbles++;
            }
        }
        // double check
        var page = this.findPage(1, 2500);
        if (page !== "GamePlaying" /* PageName.GamePlaying */ && page !== "GamePause" /* PageName.GamePause */) {
            if (this.handleLongSkillAnimations) {
                if (this.confirmGameOver()) {
                    log(this.logs.gameOver);
                    break;
                }
            }
            else {
                this.sleep(500);
                page = this.findPage(1, 2500);
                if (page !== "GamePlaying" /* PageName.GamePlaying */ && page !== "GamePause" /* PageName.GamePause */) {
                    log(this.logs.gameOver);
                    break;
                }
            }
        }
        this.runTimes++;
    }
};
Tsum.prototype.taskReceiveAllItems = function () {
    if (this.findPage() === "GamePause" /* PageName.GamePause */)
        return;
    this.requestTsumMonitor();
    log(this.logs.friendsPage);
    this.goFriendPage();
    this.sleep(1000);
    log(this.logs.receiveAllGifts);
    this.tap(Button.outReceive);
    this.sleep(3500);
    this.tap(Button.outReceiveAll);
    this.sleep(2500);
    this.fetchAllMails();
    this.sleep(2000);
    this.tap(Button.outReceiveClose);
    this.sleep(1500);
    this.tap(Button.outClose);
    this.goFriendPage();
    log(this.logs.allGiftsReceived);
};
Tsum.prototype.fetchAllMails = function () {
    var intlOkButton = Button.outReceiveOk;
    var jpOkButton = Button.outReceiveAllOkJP;
    var img = this.screenshot();
    try {
        if (this.isOnScreenshot(img, intlOkButton, 35)) {
            this.tap(intlOkButton);
        }
        else if (this.isOnScreenshot(img, jpOkButton, 35)) {
            // check important previous buttons before pressing OK
            if (this.keepRuby && this.isOnScreenshot(img, Button.outReceiveAllRubiesEnabledJP)) {
                this.tap(Button.outReceiveAllRubiesEnabledJP);
                this.sleep(500);
            }
            if (this.isOnScreenshot(img, Button.outReceiveAllHeartsDisabledJP)) {
                this.tap(Button.outReceiveAllHeartsDisabledJP);
                this.sleep(500);
            }
            this.tap(jpOkButton);
        }
        else {
            log("ERROR! No OK button found!");
            this.exitUnknownPage();
        }
    }
    finally {
        releaseImage(img);
    }
};
Tsum.prototype.readRecord = function () {
    log(this.logs.readRecords);
    var recordDir = this.storagePath + '/' + Config.recordDir;
    var recordFile = recordDir + '/record.txt';
    var txt = readFile(recordFile);
    if (txt !== undefined && txt !== "") {
        this.record = JSON.parse(txt);
    }
    // Only load the most recently seen senders as match candidates; the full
    // history stays in record.txt and on disk. Opening every portrait pinned
    // native memory for the whole session, growing with each recorded friend.
    var names = [];
    for (var filename in this.record) {
        if (filename !== "hearts_count" /* RecordKey.HeartsCount */) {
            names.push(filename);
        }
    }
    var record = this.record;
    names.sort(function (a, b) {
        return (record[b].lastReceiveTime || 0) - (record[a].lastReceiveTime || 0);
    });
    for (var i = 0; i < names.length && i < this.maxRecordImages; i++) {
        this.recordImages[names[i]] = openImage(recordDir + '/' + names[i]);
    }
};
Tsum.prototype.recognizeSender = function (img) {
    log(this.logs.recognizingHeartSender);
    var recordDir = this.storagePath + '/' + Config.recordDir;
    var from = this.toResizeXYs(Button.outReceiveNameFrom);
    var to = this.toResizeXYs(Button.outReceiveNameTo);
    var nameImg = cropImage(img, Math.floor(from.x), Math.floor(from.y), Math.floor(to.x - from.x), Math.floor(to.y - from.y));
    // nameImg is only kept (in recordImages) when the sender is new; every
    // other path out of this function — match found or getIdentityScore
    // throwing — must release it.
    var retained = false;
    try {
        var score = 0;
        var existFilename = '';
        for (var key in this.recordImages) {
            if (this.recordImages[key] !== 0) {
                score = getIdentityScore(nameImg, this.recordImages[key]);
                if (score >= 0.98) {
                    existFilename = key;
                    log(this.logs.recognitionScore + " > 0.98", key, score);
                    break;
                }
            }
        }
        // console.log("Score: " + score);
        if (existFilename === '') {
            var now = nowTime();
            var dayTime = Math.floor(now / (24 * 60 * 60 * 1000));
            // not found, new friend
            var filename = 'f_' + now + '.png';
            this.record[filename] = {
                receiveCounts: {},
                lastReceiveTime: now
            };
            this.record[filename].receiveCounts[dayTime] = 1;
            this.recordImages[filename] = nameImg;
            retained = true;
            var path = recordDir + '/' + filename;
            log(this.logs.saveNewFriend, path);
            saveImage(nameImg, path);
            this.sleep(80);
            var check = execute("ls " + path);
            if (check.indexOf(filename) === -1) {
                log(this.logs.saveNewFriendAgain);
                saveImage(nameImg, path);
            }
            this.evictOldRecordImages();
        }
        return existFilename;
    }
    finally {
        if (!retained) {
            releaseImage(nameImg);
        }
    }
};
Tsum.prototype.countReceiveHeart = function (existFilename) {
    if (!existFilename) {
        return;
    }
    log(this.logs.calculatingHeartSender);
    var now = nowTime();
    var dayTime = Math.floor(now / (24 * 60 * 60 * 1000));
    // found
    if (this.record[existFilename].receiveCounts[dayTime] === undefined) {
        this.record[existFilename].receiveCounts[dayTime] = 0;
    }
    this.record[existFilename].receiveCounts[dayTime]++;
    this.record[existFilename].lastReceiveTime = now;
    log(this.logs.receiveHeartFromHeartSender, this.record[existFilename].receiveCounts[dayTime], this.logs.hearts);
};
Tsum.prototype.saveRecord = function () {
    log(this.logs.saveRecords);
    var recordFile = this.storagePath + '/' + Config.recordDir + '/record.txt';
    writeFile(recordFile, JSON.stringify(this.record));
};
// Drop the oldest in-memory sender portraits once the cap is exceeded. Only
// the match candidates are released — the on-disk PNGs and record.txt stats
// are untouched. An evicted sender who shows up again is recorded under a
// fresh image, the same outcome as a failed match.
Tsum.prototype.evictOldRecordImages = function () {
    var names = [];
    for (var key in this.recordImages) {
        names.push(key);
    }
    if (names.length <= this.maxRecordImages) {
        return;
    }
    var record = this.record;
    names.sort(function (a, b) {
        var ta = record[a] ? (record[a].lastReceiveTime || 0) : 0;
        var tb = record[b] ? (record[b].lastReceiveTime || 0) : 0;
        return tb - ta; // newest first
    });
    for (var i = this.maxRecordImages; i < names.length; i++) {
        var img = this.recordImages[names[i]];
        if (img !== 0) {
            releaseImage(img);
        }
        delete this.recordImages[names[i]];
    }
    debug("Released", names.length - this.maxRecordImages, "old sender images (cap", this.maxRecordImages, ")");
};
Tsum.prototype.releaseRecord = function () {
    for (var filename in this.recordImages) {
        var img = this.recordImages[filename];
        if (img !== 0) {
            releaseImage(img);
        }
    }
    this.record = {};
    this.recordImages = {};
};
Tsum.prototype.clear = function () {
    var recordDir = getStoragePath() + '/' + Config.recordDir;
    execute('rm -r ' + recordDir);
};
Tsum.prototype.skipAd = function () {
    this.tap(Button.outReceiveOne);
    this.sleep(1000);
    // also gets called for skill and premium tickets, so check we really have an ad!!!
    if (this.matchesPage("ReceiveSkillTicket" /* PageName.ReceiveSkillTicket */) || this.matchesPage("ReceivePremiumTicket" /* PageName.ReceivePremiumTicket */)) {
        // mcs: I improved ad detection here because I don't get ad mails. So I cannot improve detection in list view
        log("Receive ticket");
        this.tap(Button.outReceiveOk);
    }
    else {
        log("Ignore Ad");
        if (Config.debugLogs) {
            var img = this.screenshot();
            try {
                saveImage(img, this.storagePath + "/tmp/" + this.runTimes + "-detectedAd.jpg");
            }
            finally {
                releaseImage(img);
            }
        }
        this.sleep(4000);
        // delete ad
        this.tap({ x: 462, y: 1095 });
        this.sleep(4000);
        this.tap({ x: 172, y: 1220 });
        this.sleep(2000);
        this.tap({ x: 556, y: 1417 });
    }
};
Tsum.prototype.taskReceiveOneItem = function () {
    if (this.findPage() === "GamePause" /* PageName.GamePause */)
        return;
    log(this.logs.friendsPage);
    this.goFriendPage();
    this.sleep(1000);
    this.tap(Button.outReceive);
    log(this.logs.receiveGiftsOneByOne);
    this.sleep(1000);
    var receivedCount = 0;
    var receiveCheckLimit = 1;
    var sender = undefined;
    var receiveTime = Date.now();
    var timeoutCounter = 0;
    var maxTimeoutCount = 100;
    var receivedHeartWithoutCoins = 0;
    while (this.isRunning && timeoutCounter < maxTimeoutCount) {
        this.requestTsumMonitor();
        var img = this.screenshot();
        // Declared outside the try so the if-chain below (and the later
        // `isNonItem = true`) can read them after the screenshot is released.
        var isItem = void 0, isRuby = void 0, isNonItem = void 0, isAd = void 0, isOk = void 0, isOk2 = void 0, isTimeout = void 0, isHeartWithoutCoins = void 0;
        try {
            isItem = isSameColor(Button.outReceiveOne.color, this.getColor(img, Button.outReceiveOne), 35);
            isRuby = isSameColor(Button.outReceiveOneRuby.color, this.getColor(img, Button.outReceiveOneRuby), 35);
            isNonItem = isSameColor(Button.outReceiveOne.color2, this.getColor(img, Button.outReceiveOne), 35);
            isAd = isSameColor(Button.outReceiveOneAd.color, this.getColor(img, Button.outReceiveOneAd), 35);
            isOk = isSameColor(Button.outReceiveOk.color, this.getColor(img, Button.outReceiveOk), 35);
            isOk2 = isSameColor(Button.outReceiveItemSetOk.color, this.getColor(img, Button.outReceiveItemSetOk), 35);
            isTimeout = isSameColor(Button.outReceiveTimeout.color, this.getColor(img, Button.outReceiveTimeout), 35);
            isHeartWithoutCoins = this.matchesPage("ReceiveHeartWithoutCoins" /* PageName.ReceiveHeartWithoutCoins */);
            debug({
                isItem: isItem, isRuby: isRuby, isNonItem: isNonItem, isAd: isAd, isOk: isOk,
                isTimeout: isTimeout, timeoutCounter: timeoutCounter
            });
        }
        finally {
            releaseImage(img);
        }
        if (isItem) {
            if (isAd) {
                debug("handle ad");
                this.skipAd();
                this.sleep(2000);
                this.lastVisitedPages.receiveOneItemIsAd = true;
                continue;
            }
            if (receivedHeartWithoutCoins > 2) {
                if (receivedCount <= 5 + receivedHeartWithoutCoins) {
                    this.sleep(2000);
                    debug("Should receive all now");
                    this.taskReceiveAllItems();
                    this.tap(Button.outReceive);
                    this.sleep(1500);
                }
                debug("Closing");
                this.tap(Button.outClose);
                receivedHeartWithoutCoins = 0;
                this.tap(Button.outClose);
                this.goFriendPage();
                this.sleep(500);
                receivedCount = 0;
                sender = "";
                timeoutCounter = 0;
                log(this.logs.checkUnreceivedGift);
                this.sleep(500);
                this.tap(Button.outReceive);
                this.sleep(1500);
            }
            else if (!this.keepRuby || !isRuby) {
                this.lastVisitedPages.receiveOneItemReceiving = true;
                if (this.recordReceive) {
                    img = this.screenshot();
                    try {
                        var isItem2 = isSameColor(Button.outReceiveOne.color, this.getColor(img, Button.outReceiveOne), 30);
                        if (isItem2) {
                            this.tap(Button.outReceiveOne);
                            sender = this.recognizeSender(img);
                        }
                    }
                    finally {
                        releaseImage(img);
                    }
                }
                else {
                    sender = "";
                }
                this.tap(Button.outReceiveOne);
                this.sleep(200);
                timeoutCounter = 0;
            }
            else {
                isNonItem = true;
                receiveTime = 0;
            }
        }
        else if (isTimeout) {
            debug("isTimeout", "taskReceiveOneItem");
            log(this.logs.receiveGiftAgain);
            this.tap(Button.outReceiveOk);
            this.sleep(1000);
            timeoutCounter = 0;
        }
        else if (isOk || isOk2) {
            if (this.recordReceive && sender !== undefined && sender !== "") {
                this.countReceiveHeart(sender);
                this.saveRecord();
            }
            this.sleep(100);
            if (isOk) {
                debug("isOK", "taskReceiveOneItem");
                this.lastVisitedPages.receiveOneItemIsOK = true;
                this.tap(Button.outReceiveOk);
            }
            else {
                debug("isOK2", "taskReceiveOneItem");
                this.lastVisitedPages.receiveOneItemIsOK2 = true;
                this.tap(Button.outReceiveItemSetOk);
            }
            if (sender !== undefined) {
                this.record["hearts_count" /* RecordKey.HeartsCount */].receivedCount++;
                receivedCount++;
            }
            sender = undefined;
            timeoutCounter = 0;
            if (this.claimAllWithoutCoins && isHeartWithoutCoins)
                receivedHeartWithoutCoins++;
        }
        else {
            debug("fetched all so far", "taskReceiveOneItem");
            this.tap(Button.outReceiveClose); // usual close button
        }
        this.sleep(200);
        if (!isNonItem) {
            receiveTime = Date.now();
        }
        if (Date.now() - receiveTime > 3000) {
            debug("took more than 3 seconds", "taskReceiveOneItem");
            this.tap(Button.outClose);
            this.goFriendPage();
            this.sleep(500);
            if (receivedCount === 0 || receiveCheckLimit >= this.receiveCheckLimit) {
                log(this.logs.receivingGiftsCompleted);
                break;
            }
            else {
                receiveCheckLimit++;
                receivedCount = 0;
                sender = "";
                timeoutCounter = 0;
                this.lastVisitedPages.receiveOneItemNextCheckCycle = true;
                log(this.logs.checkUnreceivedGift);
                this.sleep(500);
                this.tap(Button.outReceive);
                this.sleep(1500);
            }
        }
        timeoutCounter++;
        if (timeoutCounter % 10 === 0) {
            log("Timeout counter = " + timeoutCounter + " / 100");
        }
    }
    if (maxTimeoutCount <= timeoutCounter) {
        // we seem to be trapped, try to exit the trap
        log("I'm stuck! Trying exit...");
        this.exitUnknownPage();
        this.sleep(1000);
        if (this.findPage() === "unknown" /* PageName.Unknown */) {
            // last attempt
            log("Still stuck! Last try...");
            this.exitUnknownPage();
            this.sleep(1000);
        }
    }
};
Tsum.prototype.friendPageGoToSelf = function () {
    debug("'Scrolling' to own player ranking");
    this.tap(Button.outHomePage, 100);
    this.sleep(2000);
    this.tap(Button.outFriendPage, 100);
    debug("'Scrolled' to own player ranking");
    this.sleep(2000);
};
Tsum.prototype.doHeartSending = function (startTime) {
    var retry = 0;
    var times = 0;
    var hfx = Button.outSendHeartFrom.x;
    var hfy = Button.outSendHeartFrom.y - 40; // hearts from y
    var hty = Button.outSendHeartTo.y + 30; // hearts to y
    var finished;
    // Called with `.call(this)`, so `this` is the live Tsum instance.
    function scrollToNextHearts() {
        if (this.sendHeartsDownwards) {
            this.tapDown({ x: Button.outSendHeart3.x - 10, y: Button.outSendHeart3.y }, 50);
            this.moveTo({ x: Button.outSendHeart3.x - 10, y: Button.outSendHeart3.y }, 50);
            this.moveTo({ x: Button.outSendHeart3.x - 10, y: Button.outSendHeart2.y }, 50);
            this.moveTo({ x: Button.outSendHeart3.x - 10, y: Button.outSendHeart1.y }, 50);
            this.moveTo({ x: Button.outSendHeart3.x - 10, y: Button.outSendHeart0.y }, 50);
            this.moveTo({ x: Button.outSendHeart3.x - 10, y: Button.outSendHeartTop.y }, 500);
            this.tapUp({ x: Button.outSendHeart3.x - 10, y: Button.outSendHeartTop.y }, 100);
        }
        else {
            this.tapDown({ x: Button.outSendHeart3.x - 10, y: Button.outSendHeart0.y }, 50);
            this.moveTo({ x: Button.outSendHeart3.x - 10, y: Button.outSendHeart0.y }, 50);
            this.moveTo({ x: Button.outSendHeart3.x - 10, y: Button.outSendHeart1.y }, 50);
            this.moveTo({ x: Button.outSendHeart3.x - 10, y: Button.outSendHeart2.y }, 50);
            this.moveTo({ x: Button.outSendHeart3.x - 10, y: Button.outSendHeart3.y }, 50);
            this.moveTo({ x: Button.outSendHeart3.x - 10, y: Button.outSendHeartBottom.y }, 500);
            this.tapUp({ x: Button.outSendHeart3.x - 10, y: Button.outSendHeartBottom.y }, 100);
        }
    }
    while (this.isRunning && typeof finished === 'undefined') {
        this.requestTsumMonitor();
        times++;
        if (times % 15 === 0) {
            debug("Ensuring friends page");
            this.goFriendPage();
            this.lastVisitedPages.friends = true;
            debug("Ensured friends page");
        }
        var heartsPos = [];
        var img = this.screenshot();
        // Declared outside the try so the end/zero/top checks below can read them
        // after the screenshot is released.
        var isOk = void 0, isZero = void 0, isNotEnd = void 0, isEnd1 = void 0, isEnd2 = void 0, isEnd3 = void 0, isTop = void 0;
        try {
            isOk = isSameColor(Button.outReceiveOk.color, this.getColor(img, Button.outReceiveOk), 40);
            for (var y = hfy; y <= hty; y += 8) {
                var isHs = isSameColor(Button.outSendHeart0.color, this.getColor(img, { x: hfx, y: y }), 40);
                if (isHs) {
                    heartsPos.push({ x: hfx, y: y, color: Button.outSendHeart0.color, color2: Button.outSendHeart0.color2 });
                    y += 140;
                }
            }
            debug("Found " + heartsPos.length + " hearts on current page");
            isZero = true;
            var fx = Button.outFriendScoreFrom.x;
            var tx = Button.outFriendScoreTo.x;
            var sy = heartsPos.length === 0 ? Button.outFriendScoreFrom.y : (heartsPos[0].y + 35);
            for (var px = fx; px <= tx; px += 20) {
                isZero = isSameColor(Button.outFriendScoreFrom.color, this.getColor(img, { x: px, y: sy }), 40);
                if (!isZero) {
                    break;
                }
            }
            isNotEnd = isSameColor(Button.outSendHeartEnd2.color, this.getColor(img, { x: 225, y: 1056 }), 40);
            isEnd1 = isSameColor({ r: 162, g: 84, b: 53 }, this.getColor(img, { x: 225, y: 1056 }), 40);
            isEnd2 = isSameColor(Button.outSendHeartEnd.color, this.getColor(img, Button.outSendHeartEnd), 40);
            isEnd3 = isSameColor(Button.outSendHeartEnd3.color, this.getColor(img, { x: 315, y: 1020 }), 40);
            isTop = isSameColor({ r: 255, g: 227, b: 115 }, this.getColor(img, { x: 200, y: 670 }));
        }
        finally {
            releaseImage(img);
        }
        var isEnd = !isNotEnd && isEnd1 && isEnd2 && isEnd3;
        debug('isNotEnd', isNotEnd, 'isEnd1', isEnd1, 'isEnd2', isEnd2, 'isEnd3', isEnd3, 'isEnd', isEnd, 'retry', retry, 'heartsLength', heartsPos.length, 'isZero', isZero);
        if (isOk && heartsPos.length === 0) {
            this.tap(Button.outReceiveOk);
        }
        if ((heartsPos.length === 0 && (isEnd || isTop)) || (!this.sentToZero && isZero && heartsPos.length !== 0)) {
            log("'isEnd'=" + isEnd + ", 'isZero'=" + isZero + ", 'isTop'=" + isTop);
            if (retry < 3) {
                scrollToNextHearts.call(this);
                retry++;
                log(this.logs.checkSendingHearts, retry);
                this.sleep(1000);
            }
            else {
                if (this.sendHeartMaxDuring !== 0) {
                    this.sleep(1000);
                    this.friendPageGoToSelf();
                }
                debug("Ending taskSendHearts");
                this.sendHeartsDownwards = !this.sendHeartsDownwards;
                // we're finished if we reached the top of the ranking and will send downwards again on the next run
                finished = this.sendHeartsDownwards;
            }
        }
        else {
            var rTimes = 0;
            for (var h in heartsPos) {
                debug("Try sending heart to", h);
                var success = this.sendHeart(heartsPos[h]);
                debug("Tried sending heart to", h, "with success=" + success);
                if (!success) {
                    debug("Try again sending heart to", h);
                    success = this.sendHeart(heartsPos[h]);
                    debug("Tried again sending heart to", h, "with success=" + success);
                }
                if (success) {
                    rTimes++;
                    this.record["hearts_count" /* RecordKey.HeartsCount */].sentCount++;
                    this.lastVisitedPages.sendHeartSuccess = true;
                }
                else {
                    debug("Try return to FriendPage");
                    this.goFriendPage();
                    this.sleep(1000);
                    debug("Tried return to FriendPage");
                }
                if (!this.isRunning) {
                    return true; // don't let the surrounding job retry this immediately, so we pretend to be finished
                }
            }
            if (heartsPos.length !== 0 && rTimes === 0) {
                continue;
            }
            if (this.recordReceive && heartsPos.length !== 0) {
                this.saveRecord();
            }
            this.sleep(250);
            scrollToNextHearts.call(this);
            this.sleep(400);
            if (this.sendHeartMaxDuring !== 0) {
                if (Date.now() - startTime > this.sendHeartMaxDuring) {
                    // we exceeded the maximum allowed sending time. leaving unfinished.
                    log(this.logs.timeIsUp);
                    finished = true;
                }
            }
            if (heartsPos.length === 0 && isEnd2) {
                this.sleep(700); // end bug
            }
        }
    }
    return finished;
};
Tsum.prototype.taskSendHearts = function () {
    debug("Started taskSendHearts");
    if (this.findPage() === "GamePause" /* PageName.GamePause */)
        return;
    log(this.logs.friendsPage);
    this.goFriendPage();
    log(this.logs.startSendingHearts);
    this.sleep(1000);
    if (this.sendHeartMaxDuring === 0) {
        this.friendPageGoToSelf();
        tap(0, 0, 20); // Avoid overlap between zero score and pointer location
    }
    var startTime = Date.now();
    var finished;
    do {
        finished = this.doHeartSending(startTime);
        debug("Finished doHeartSending with result " + finished);
        this.sleep(2000);
        if (!finished) {
            this.friendPageGoToSelf();
            tap(0, 0, 20); // Avoid overlap between zero score and pointer location
        }
        this.sleep(2000);
    } while (!finished);
    debug("Finished taskSendHearts");
};
Tsum.prototype.taskAutoUnlockLevel = function () {
    if (this.findPage() === "GamePause" /* PageName.GamePause */)
        return;
    var btn;
    var i;
    var img;
    var formerOrderButton = null;
    var orderButtons;
    var buttonCloseTsumCollectionOrder;
    var buttonOrderByLevelLock;
    log(this.logs.tsumsPage);
    this.goTsumsPage();
    this.lastVisitedPages.autoUnlockLevelTsum = true;
    log(this.logs.startUnlockLevel);
    // Switch order to "By Level Lock" and remember former selection
    this.tap(Button.outOpenTsumCollectionOrder);
    this.sleep(1000);
    img = this.screenshot();
    try {
        // detect old or new ordering view
        if (isSameColor(Button.outCloseTsumCollectionOrderNew, this.getColor(img, Button.outCloseTsumCollectionOrderNew))) {
            orderButtons = [
                Button.outTsumCollectionOrderByReleaseDateNew,
                Button.outTsumCollectionOrderByLevelLockNew,
                Button.outTsumCollectionOrderBySkillNew,
                Button.outTsumCollectionOrderFavoritesNew,
                Button.outTsumCollectionOrderByEntryDateNew
            ];
            buttonCloseTsumCollectionOrder = Button.outCloseTsumCollectionOrderNew;
            buttonOrderByLevelLock = Button.outTsumCollectionOrderByLevelLockNew;
        }
        else {
            orderButtons = [
                Button.outTsumCollectionOrderByReleaseDateOld,
                Button.outTsumCollectionOrderByLevelLockOld,
                Button.outTsumCollectionOrderBySkillOld,
                Button.outTsumCollectionOrderFavoritesOld
            ];
            buttonCloseTsumCollectionOrder = Button.outCloseTsumCollectionOrderOld;
            buttonOrderByLevelLock = Button.outTsumCollectionOrderByLevelLockOld;
        }
        for (i = 0; i < orderButtons.length; i++) {
            btn = orderButtons[i];
            if (isSameColor(btn, this.getColor(img, btn))) {
                formerOrderButton = btn;
                debug("Found active button: " + btn.name);
                break;
            }
        }
    }
    finally {
        releaseImage(img);
    }
    this.tap(buttonOrderByLevelLock);
    this.sleep();
    this.tap(buttonCloseTsumCollectionOrder);
    this.sleep(1000);
    // Start looking for locks from first entries
    this.tap({ x: 1, y: 1892 }); // jump to first Tsum entries
    this.sleep(3000);
    // check all
    // Declared outside the do/while so the loop condition can read it.
    var allLocked = true;
    do {
        this.requestTsumMonitor();
        allLocked = true;
        var lockIcons = Page.TsumsPage.lockIcons;
        img = this.screenshot();
        try {
            for (i = 0; i < lockIcons.length; i++) {
                var lockIcon = lockIcons[i];
                debug("Checking for lock on i=" + i);
                var realColor = this.getColor(img, lockIcon);
                debug("For i=" + i + " I found color " + JSON.stringify(realColor));
                if (isSameColor(lockIcon, realColor)) {
                    debug("Unlocking i=" + i);
                    this.lastVisitedPages.autoUnlockLevelUnlock = true;
                    var tsumButton = { x: lockIcon.x, y: lockIcon.y - 100 };
                    this.tap(tsumButton);
                    this.sleep(1000);
                    this.tap(Button.outTsumCollectionDoUnlock);
                    this.sleep(1000);
                    this.tap({ x: 814, y: 1071, r: 247, g: 174, b: 8 }); // OK button
                    this.sleep(5000);
                    this.tap({ x: 600, y: 600 }); // just tap anywhere to close the confirmation dialog
                    this.sleep(1000);
                    debug("Unlocked i=" + i);
                }
                else {
                    debug("No lock found for i=" + i);
                    allLocked = false;
                    break;
                }
            }
        }
        finally {
            releaseImage(img);
        }
        // scroll to next page if all Tsums were locked
        if (allLocked) {
            debug("Clicking scroll button to move to next page");
            this.tap({ x: 1030, y: 1193, r: 212, g: 239, b: 246 }); // arrow, scroll right to next page
            this.sleep(3000);
        }
        // Progress until no more locks exist
    } while (this.isRunning && allLocked);
    // Reset order to former selection
    if (formerOrderButton != null && formerOrderButton !== buttonOrderByLevelLock) {
        this.tap(Button.outOpenTsumCollectionOrder);
        this.sleep(1000);
        this.tap(formerOrderButton);
        this.sleep();
        this.tap(buttonCloseTsumCollectionOrder);
        this.sleep(1000);
    }
    log(this.logs.endUnlockLevel);
};
Tsum.prototype.taskAutoBuyBoxes = function () {
    if (this.findPage() === "GamePause" /* PageName.GamePause */)
        return;
    log("Starting taskAutoBuyBoxes");
    if (this.autobuyBoxes === 0) {
        log("Nothing to do", "taskAutoBuyBoxes");
        return;
    }
    var storeHasOpened = this.goTsumTsumStorePage();
    var lastPage = this.findPageObject(1, 200);
    if (!storeHasOpened) {
        log("Leaving AutoBuy Boxes.");
        this.autobuyBoxes = 0;
        return;
    }
    this.lastVisitedPages.autoBuyBoxesStore = true;
    log("Start buying ", this.autobuyBoxes, "boxes - taskAutoBuyBoxes");
    var countUnknownPages = 0, countSamePage = 0;
    while (this.isRunning && storeHasOpened && this.autobuyBoxes > 0 && countSamePage < 60) {
        this.requestTsumMonitor();
        var page = this.findPageObject(1, 200);
        if (page != null) {
            countUnknownPages = 0;
            this.lastVisitedPages['autoBuyBoxes' + page.name] = true;
            if (page.name === "OutOfMedals" /* PageName.OutOfMedals */) {
                log("Out Of Medals");
                this.autobuyBoxes = 0;
                break;
            }
            if (page.name === "TsumTsumStorePage" /* PageName.TsumTsumStorePage */) {
                if (page !== lastPage) {
                    this.autobuyBoxes--;
                    log("Bought box.", this.autobuyBoxes, "left");
                }
                var img = this.screenshot();
                var nextColor = void 0;
                try {
                    nextColor = this.getColor(img, page.next);
                }
                finally {
                    releaseImage(img);
                }
                if (this.autobuyBoxes === 0) {
                    log("Buying finished");
                    break;
                }
                if (!isSameColor(page.next, nextColor, 50)) {
                    // wait and test again
                    //
                    // LATENT: this re-read can return null (nothing recognised within the
                    // 200ms budget) and is dereferenced unchecked, both here and at the
                    // `this.tap(page.next)` below -- a TypeError the task controller
                    // swallows as one more error towards its restart threshold. The `!`
                    // preserves that existing behaviour rather than quietly adding a
                    // guard; see the note in DEVELOPMENT.md.
                    this.sleep(500);
                    page = this.findPageObject(1, 200);
                    if (page.name === "TsumTsumStorePage" /* PageName.TsumTsumStorePage */ && !isSameColor(page.next, nextColor, 50)) {
                        log("Finish with", this.autobuyBoxes, "boxes zu buy due to empty box");
                        break;
                    }
                }
            }
            this.tap(page.next);
            if (page === lastPage) {
                countSamePage++;
                debug("countSamePage =", countSamePage);
                if (countSamePage % 10 === 0) {
                    debug("I'm stuck?!");
                    this.exitUnknownPage();
                }
            }
            else {
                countSamePage = 0;
            }
            if (countSamePage === 30) {
                // we didn't change the page for at least 15 seconds (30 * 0.500) so try escaping from wherever we are
                log("I'm stuck on buying!");
                this.exitUnknownPage();
                countSamePage = 0;
                this.autobuyBoxes = 0;
            }
            else if (page.name === Page.Received.name
                || page.name === Page.FriendPage.name
                || page.name === Page.TsumsPage.name) {
                log("Collected all Tsums.");
                this.autobuyBoxes = 0;
            }
            else if (page.name === Page.MailBox.name) { // matches when "Buy coins for rubies" appears
                // test again, sometimes falsely matched while page transition
                // (same unchecked re-read as above)
                this.sleep(500);
                page = this.findPageObject(1, 200);
                if (page.name === Page.MailBox.name) {
                    log("Not enough coins.");
                    this.autobuyBoxes = 0;
                }
            }
            lastPage = page;
        }
        else {
            countUnknownPages++;
            if (countUnknownPages === 20) {
                // sometimes the final confirmation after having bought doesn't get clicked, so let's use this method
                log("Stuck?");
                this.exitUnknownPage();
            }
            else if (countUnknownPages > 30) {
                // this probably didn't work on 10, but let's try it again as we don't have something better here
                log("Stuck! Exit...");
                this.exitUnknownPage();
                countUnknownPages = 0;
                this.autobuyBoxes = 0;
            }
        }
        this.sleep(500);
    }
    log("Finished taskAutoBuyBoxes");
};
Tsum.prototype.taskRequestTsumMonitor = function () {
    this.requestTsumMonitor(true);
};
Tsum.prototype.requestTsumMonitor = function (force) {
    var url = this.tsumMonitorUrl;
    if (url.length === 0)
        return;
    if (this.nextMonitorExecution <= Date.now() && Object.keys(this.lastVisitedPages).length >= 2) {
        log("TsumMonitor - GET", url);
        var response = httpClient('GET', url, '', {});
        log("TsumMonitor - Response:", response.trim());
        this.nextMonitorExecution = Date.now() + 60 * 1000;
        this.lastVisitedPages = {};
    }
    else {
        debug("Skipping TsumMonitor call");
    }
};
// Layer 2 watchdog: detects when the game stops making progress and restarts
// the app. "Progress" = the number of lastVisitedPages keys changing (it grows
// as pages are visited and is reset to {} by requestTsumMonitor after a ping;
// either way a change means something happened). Runs between tasks, so it
// recovers from a stuck game screen, not from a task wedged in its own loop.
Tsum.prototype.taskWatchdog = function () {
    // const count = Object.keys(this.lastVisitedPages).length;
    // if (count !== this._lastSeenCount) {
    //   this._lastSeenCount = count;
    //   this._lastProgress = Date.now();
    //   return;
    // }
    // const stalledMs = Date.now() - this._lastProgress;
    // if (stalledMs >= this.stuckTimeoutMs) {
    //   log("[Watchdog] no progress for " + Math.round(stalledMs / 1000) + "s, restarting Tsum app");
    //   try { this.taskTsumAppRestart(); } catch (e) { log("[Watchdog] restart failed: " + e); }
    //   this._lastProgress = Date.now();
    //   this._lastSeenCount = Object.keys(this.lastVisitedPages).length;
    // }
};
Tsum.prototype.taskTsumAppRestart = function () {
    log("Preparing restarting TsumApp");
    if (!this.isAppOn()) {
        this.startApp();
    }
    this.goFriendPage();
    log("Restarting TsumApp");
    // Inlined rather than routed through forceRestartApp(): that helper is the
    // stall-recovery path (dialogs.ts) and differs from TsumBeta here — it is
    // gated on "Auto launch app", waits 3s, and always relaunches. This task
    // matches Beta exactly.
    execute("am force-stop " + getPackageName(this.isJP));
    this.sleep(10000);
    if (!this.isAppOn()) {
        this.startApp();
    }
    this.goFriendPage();
    log("TsumTsumApp restarted");
};
Tsum.prototype.sendHeart = function (btn) {
    var unknownCount = 0;
    var isGift = false;
    var isSent = false;
    // log("sendHeart");
    while (this.isRunning) {
        var page = this.findPage(1, 300);
        if (page === "FriendPage" /* PageName.FriendPage */) {
            // log("sendHeart A", Date.now() / 1000);
            var img = this.screenshot();
            var isSendBtn = void 0, isSentBtn = void 0;
            try {
                isSendBtn = isSameColor(btn.color, this.getColor(img, btn), 40);
                isSentBtn = isSameColor(btn.color2, this.getColor(img, btn), 40);
            }
            finally {
                releaseImage(img);
            }
            if ((isSendBtn || !isSentBtn) && !isGift && !isSent) {
                debug("sendHeart A-A", Date.now() / 1000);
                this.tap(btn);
            }
            else {
                debug("sendHeart A-B", Date.now() / 1000);
                unknownCount += 1;
            }
        }
        else if (page === "GiftHeart" /* PageName.GiftHeart */) {
            this.lastVisitedPages.sendHeartGiftHeart = true;
            this.tap(Button.outReceiveOk);
            isGift = true;
            debug("sendHeart B", Date.now() / 1000);
        }
        else if (page === "Received" /* PageName.Received */) {
            this.lastVisitedPages.sendHeartReceived = true;
            this.sleep(100);
            this.tap(Button.outSendHeartClose);
            debug("sendHeart C", Date.now() / 1000);
            if (isGift) {
                isSent = true;
                debug("sendHeart C-C", Date.now() / 1000);
                this.sleep(100);
                return true;
            }
        }
        else if (page === "FriendInfo" /* PageName.FriendInfo */) {
            this.tap(Page.FriendInfo.back);
        }
        else if (page === "ClosePage" /* PageName.ClosePage */) {
            this.tap(Page.ClosePage.back);
            this.tap({ x: 310, y: 1588 - 140 });
        }
        else {
            unknownCount++;
        }
        if (unknownCount >= 15) {
            debug(this.logs.UnknownState);
            return false;
        }
        // this.sleep(150);
    }
    return false; // not running: the heart was not sent
};
Tsum.prototype.sleep = function (t) {
    if (typeof t !== 'number') {
        t = 1000;
    }
    var waitTime = t;
    while (this.isRunning && waitTime > 0) {
        if (waitTime <= 500) {
            sleep(waitTime);
            break;
        }
        else {
            sleep(500);
            waitTime -= 500;
        }
    }
};
Tsum.prototype.isOnScreenshot = function (img, pageObject, colorDiff) {
    return !!(pageObject && pageObject.color
        && isSameColor(pageObject.color, this.getColor(img, pageObject), colorDiff));
};
// ---------------------------------------------------------------------------
// Skill dispatch
//
// Every playable skill lives in its own file under src/skills/ and registers a
// handler here. useSkill owns the parts that are the same for all of them --
// checking the gauge, the fever hold-off, the activation tap(s) -- and hands the
// skill-specific choreography to the registered handler.
//
// Files are concatenated in tsconfig order, so this file must come before the
// individual skill files: their registerSkill calls run at load time.
// ---------------------------------------------------------------------------
// Keyed loosely, valued as possibly-absent: a miss is normal (SkillType.NoSkill has no
// handler, and a stale setting from an older build still has to play). What is
// checked is *registration* -- registerSkill takes SkillType[], so a handler
// cannot be filed under an id the dropdown does not offer, which is the
// direction typos actually go.
var SkillHandlers = {};
function registerSkill(handler) {
    for (var i = 0; i < handler.types.length; i++) {
        SkillHandlers[handler.types[i]] = handler;
    }
}
// Skills with no choreography of their own: tap randomize (tsums that support it
// reshuffle) and wait out skillInterval. Also what an unregistered skillType
// falls back to, so a stale setting still plays.
function skillRandomizeAndWait(ts) {
    ts.tap(Button.gameRand, 100);
    ts.sleep(ts.skillInterval - 100);
}
function skillBareTapActivates(skillType) {
    var handler = SkillHandlers[skillType];
    return !!(handler && handler.bareTapActivates);
}
// The skill button reads one of these colors while the gauge is not yet full.
// Don't know the reason why these are checked instead of the "active skill"
// colors, but hopefully for a good reason.
var SkillNotActiveColors = [
    { "a": 0, "b": 157, "g": 112, "r": 85 },
    { "a": 0, "b": 181, "g": 139, "r": 72 },
    { "a": 0, "b": 128, "g": 73, "r": 16 },
    { "a": 0, "b": 178, "g": 153, "r": 3 },
    { "a": 0, "b": 255, "g": 215, "r": 33 }
];
// Tiered gauge read against SkillNotActiveColors, at two thresholds: tight (25)
// means firmly empty; loose (60) is the plain not-active match. Returns
// 'active', 'almost', or 'far'.
Tsum.prototype.checkSkillReadiness = function (img, skillButton) {
    var c = this.getColor(img, skillButton);
    var matchesTight = false, matchesLoose = false;
    for (var i = 0; i < SkillNotActiveColors.length; i++) {
        var nc = SkillNotActiveColors[i];
        if (isSameColor(nc, c, 25)) {
            matchesTight = true;
        }
        if (isSameColor(nc, c, 60)) {
            matchesLoose = true;
        }
    }
    if (!matchesLoose) {
        return "active" /* SkillReadiness.Active */;
    }
    if (!matchesTight) {
        return "almost" /* SkillReadiness.Almost */;
    }
    return "far" /* SkillReadiness.Far */;
};
// Whether firing the fan now would be a waste: the tsums it shuffles are about
// to be cleared by a skill that is ready or nearly so. It also leaves the board
// churning right as the skill activates, which matters for skills that read the
// board on activation (Tiara Minnie+ blows up whatever is under her pick).
// Costs one screenshot, so only call it where a fan tap is actually pending.
Tsum.prototype.fanWouldBeWasted = function () {
    var img = this.screenshot();
    try {
        return this.checkSkillReadiness(img, Button.gameSkill1) !== "far" /* SkillReadiness.Far */;
    }
    finally {
        releaseImage(img);
    }
};
// When skillAutoTap is on, fire the skill the moment it's ready instead of
// waiting for the next useSkill at the end of the board-scan cycle. The gauge
// can fill and sit ready for seconds while we scan, calculate and link; this is
// called often (e.g. between chains) but only does a real screenshot/check once
// per skillAutoTapInterval ms, so the timestamp guard keeps frequent calls cheap.
// Routes through useSkill so every skill type's activation (and choreography) is
// handled exactly as the normal end-of-cycle path.
Tsum.prototype.maybeAutoTapSkill = function (board) {
    if (!this.skillAutoTap) {
        return;
    }
    var now = Date.now();
    if (now - this._lastSkillAutoTap < this.skillAutoTapInterval) {
        return;
    }
    this._lastSkillAutoTap = now;
    if (skillBareTapActivates(this.skillType)) {
        // A bare tap is a complete activation for burst skills, and it's a no-op
        // while the gauge isn't full -- skip the screenshots entirely.
        this.tap(Button.gameSkill1, 10);
        return;
    }
    // One readiness read before the full useSkill probe (findPage plus a double
    // gauge check, several screenshots) so the recurring cost while the gauge is
    // still filling stays at a single screenshot.
    var img = this.screenshot();
    var status;
    try {
        status = this.checkSkillReadiness(img, Button.gameSkill1);
    }
    finally {
        releaseImage(img);
    }
    if (status === "active" /* SkillReadiness.Active */) {
        this.useSkill(board);
    }
};
// Hold off activating while a fever is about to end, so the skill's clear lands
// in the next fever rather than being spent on its last moments.
function skillWaitOutEndingFever(ts) {
    var feverAlmostOver = null;
    do {
        if (feverAlmostOver) {
            ts.sleep(100);
        }
        var img = ts.screenshot();
        try {
            var fever1 = isSameColor(ts.getColor(img, { x: 340, y: 310 }), { r: 0, g: 40, b: 49 }, 80);
            var feverRingLeft = rgb2hsv(ts.getColor(img, { x: 332, y: 1666 }));
            var feverRingRight = rgb2hsv(ts.getColor(img, { x: 746, y: 1666 }));
            var hueDifference = Math.min(Math.abs(feverRingLeft.h - feverRingRight.h), 360 - Math.abs(feverRingLeft.h - feverRingRight.h));
            var fever2 = hueDifference > 20;
            var feverStartColorHsv = rgb2hsv(ts.getColor(img, { x: 345, y: 1670 }));
            var offsetX = Math.floor((733 - 345) * ts.noSkillLastFeverSec / 10);
            var feverEndColorHsv = rgb2hsv(ts.getColor(img, { x: 345 + offsetX, y: 1670 }));
            var nearlyDone = feverEndColorHsv.v < 90 || Math.abs(feverStartColorHsv.v - feverEndColorHsv.v) > 10;
            var remainingTimeColor = ts.getColor(img, { x: 155, y: 190 });
            var fewSecondsLeftColor = ts.getColor(img, { x: 144, y: 195 });
            var enoughSecondsRemaining = isSameColor(remainingTimeColor, fewSecondsLeftColor, 60);
            // debug({fever1: fever1, fever2: fever2, almostOver: nearlyDone, enoughTime: enoughSecondsRemaining});
            feverAlmostOver = fever1 && fever2 && nearlyDone && enoughSecondsRemaining;
        }
        finally {
            releaseImage(img);
        }
    } while (feverAlmostOver);
}
Tsum.prototype.useSkill = function (board) {
    if (this.skillType === "no_skill" /* SkillType.NoSkill */) {
        return false;
    }
    var page = this.findPage(1, 500);
    if (page !== "GamePlaying" /* PageName.GamePlaying */ && page !== "GamePause" /* PageName.GamePause */) {
        return false;
    }
    var handler = SkillHandlers[this.skillType];
    var usesSecondButton = !!(handler && handler.usesSecondButton);
    // Checked twice, a moment apart: a single read can catch the button mid-flash.
    var skillActive2 = false;
    for (var i = 0; i < 2; i++) {
        var img = this.screenshot();
        var skillActive1 = void 0;
        try {
            skillActive1 = this.checkSkillReadiness(img, Button.gameSkill1) === "active" /* SkillReadiness.Active */;
            skillActive2 = usesSecondButton
                && this.checkSkillReadiness(img, Button.gameSkill2) === "active" /* SkillReadiness.Active */;
        }
        finally {
            releaseImage(img);
        }
        if (skillActive1 || skillActive2) {
            if (i === 0) {
                this.sleep(200);
            }
        }
        else {
            this.lastVisitedPages.gameSkillInactive = true;
            return false;
        }
    }
    this.lastVisitedPages.gameSkillActive = true;
    if (this.noSkillLastFeverSec > 0) {
        skillWaitOutEndingFever(this);
    }
    log(this.logs.useSkill);
    if (handler && handler.beforeActivate) {
        handler.beforeActivate(this);
    }
    this.tap(Button.gameSkill1);
    this.sleep(30);
    if (skillActive2) {
        this.tap(Button.gameSkill2);
        this.sleep(30);
    }
    if (handler && handler.afterActivate) {
        return handler.afterActivate(this, board) !== false;
    }
    skillRandomizeAndWait(this);
    return true;
};
// Burst — the plain clearing skills.
//
// No aiming and no follow-up: the tap is the whole activation, which is what
// lets the play loop fire these blind between chains (see Tsum.link).
registerSkill({
    types: ["burst" /* SkillType.Burst */],
    bareTapActivates: true,
    afterActivate: function (ts) {
        skillRandomizeAndWait(ts);
    }
});
// Same skill, on a board that leaves bubbles behind: sweep them after the clear.
registerSkill({
    types: ["burst_bubbles" /* SkillType.BurstBubbles */],
    bareTapActivates: true,
    afterActivate: function (ts) {
        skillRandomizeAndWait(ts);
        ts.clearAllBubbles(0, 0, 1000, 300);
    }
});
// Pair Tsum — two halves on two skill buttons.
//
// Either gauge filling counts as ready, and whichever ones are ready get their
// own activation tap (handled by useSkill via usesSecondButton). No choreography
// beyond that.
registerSkill({
    types: ["block_pair_tsum" /* SkillType.PairTsum */],
    usesSecondButton: true,
    afterActivate: function (ts) {
        skillRandomizeAndWait(ts);
    }
});
// Donald / Holiday Donald — the skill scatters tappable targets over the board.
//
// Nothing is detected: the whole play area is covered on a coarse grid, three
// times over. A tap that lands on nothing costs nothing.
registerSkill({
    types: ["block_donald_s" /* SkillType.Donald */, "block_donaldx_s" /* SkillType.HolidayDonald */],
    afterActivate: function (ts) {
        for (var pass = 0; pass < 3; pass++) {
            for (var bx = Button.gameBubblesFrom.x - 40; bx <= Button.gameBubblesTo.x + 40; bx += 150) {
                for (var by = Button.gameBubblesFrom.y; by <= Button.gameBubblesTo.y + 100; by += 150) {
                    ts.tap({ x: bx, y: by }, 10);
                }
            }
        }
    }
});
// Jedi Luke — the only skill with taps on both sides of the activation.
//
// The four skillLuke positions are tapped before activating (clearing whatever
// is already on them), then the skill is flown with five upward drags, then the
// same four positions again.
function lukeJTapTargets(ts) {
    ts.tap(Button.skillLuke1, 30);
    ts.tap(Button.skillLuke2, 30);
    ts.tap(Button.skillLuke3, 30);
    ts.tap(Button.skillLuke4, 30);
}
registerSkill({
    types: ["block_lukej_s" /* SkillType.JediLuke */],
    beforeActivate: lukeJTapTargets,
    afterActivate: function (ts) {
        for (var i = 0; i < 5; i++) {
            ts.tapDown({ x: 820, y: 1200 }, 20);
            ts.moveTo({ x: 820, y: 1150 }, 20);
            if (i === 0) {
                // The first run has to wait out the skill's intro animation.
                ts.sleep(1160);
            }
            ts.sleep(350);
            ts.moveTo({ x: 825, y: 1000 }, 20);
            ts.sleep(100);
            ts.moveTo({ x: 835, y: 800 }, 20);
            ts.sleep(100);
            ts.moveTo({ x: 845, y: 600 }, 20);
            ts.sleep(100);
            ts.moveTo({ x: 850, y: 450 }, 20);
            ts.tapUp({ x: 850, y: 420 }, 20);
            ts.sleep(20);
        }
        ts.sleep(400);
        lukeJTapTargets(ts);
        ts.sleep(400);
    }
});
// Marie / Miss Bunny / Rabbit — the skill turns tsums into bubbles that have to
// be popped by hand. Same animation length for all three, so one sweep serves.
registerSkill({
    types: ["block_marie_s" /* SkillType.Marie */, "block_missbunny_s" /* SkillType.MissBunny */, "block_rabbit_s" /* SkillType.Rabbit */],
    afterActivate: function (ts) {
        ts.clearAllBubbles(2000, 50);
    }
});
// Moana — bubbles again, behind a slightly longer intro than Marie's.
registerSkill({
    types: ["block_moana_s" /* SkillType.Moana */],
    afterActivate: function (ts) {
        ts.clearAllBubbles(2500, 50);
    }
});
// Horn Hat Mickey — bubbles, with the shortest intro of the bubble skills.
registerSkill({
    types: ["block_mickeyh2015_s" /* SkillType.HornHatMickey */],
    afterActivate: function (ts) {
        ts.clearAllBubbles(1500, 50);
    }
});
// Snow White — a full sweep once the animation is done, then a second one from
// halfway down the board to catch bubbles that drifted after the first pass.
registerSkill({
    types: ["block_snowwhite_s" /* SkillType.SnowWhite */],
    afterActivate: function (ts) {
        ts.clearAllBubbles(1300);
        ts.clearAllBubbles(10, 50, (Button.gameBubblesFrom.y + Button.gameBubblesTo.y) / 2);
    }
});
// Cinderella — the skill is aimed by drawing over the board, not by tapping.
//
// Ten serpentine passes (five repeats x two horizontal offsets) sweep the whole
// play area, then the bubbles left behind are cleared. The coordinates are in
// the playResize space linkTsums draws in, not screen pixels.
Tsum.prototype.useCinderellaSkill = function () {
    var path, offset, y;
    for (var i = 0; i < 5; i += 1) {
        for (offset = 0; offset <= 200; offset += 200) {
            path = [];
            for (y = 170; y >= 70; y -= 20)
                path.push({ x: Math.abs(offset - 10), y: y });
            for (y = 60; y <= 180; y += 20)
                path.push({ x: Math.abs(offset - 40), y: y });
            for (y = 180; y >= 60; y -= 20)
                path.push({ x: Math.abs(offset - 70), y: y });
            for (y = 60; y <= 180; y += 20)
                path.push({ x: Math.abs(offset - 100), y: y });
            debug("Cinderella i =", i, ", offset =", offset);
            this.linkTsums(path);
        }
    }
    this.sleep(3000);
    this.clearAllBubbles(10, 50, (Button.gameBubblesFrom.y + Button.gameBubblesTo.y) / 2, 200);
};
registerSkill({
    types: ["block_cinderella_s" /* SkillType.Cinderella */],
    afterActivate: function (ts) {
        ts.sleep(1500);
        // Takes no argument: the sweep is a fixed serpentine over the whole play
        // area, not something aimed at the scanned board. (It was being passed
        // `board`, which the function has never had a parameter for.)
        ts.useCinderellaSkill();
    }
});
// Sheriff Woody — the lasso is swung by holding and dragging left/right across
// the middle of the board. Three full sweeps per activation.
registerSkill({
    types: ["block_woody2_s" /* SkillType.SheriffWoody */],
    afterActivate: function (ts) {
        ts.sleep(1800);
        ts.tapDown({ x: 540, y: 960 }, 20);
        ts.moveTo({ x: 980, y: 960 }, 20);
        ts.sleep(50);
        for (var i = 0; i < 3; i++) {
            ts.moveTo({ x: 100, y: 960 }, 20);
            ts.sleep(420);
            ts.moveTo({ x: 980, y: 960 }, 20);
            ts.sleep(480);
        }
        ts.tapUp({ x: 980, y: 960 }, 20);
    }
});
// Cabbage Mickey — the skill buries Mickey among cabbages and the player has to
// find and tap him. This is the only skill that has to actually look at the
// board to aim.
//
// The search is a coarse grid over the play area looking for Mickey's face
// color on a blurred screenshot, retried up to five times while the cabbages
// keep shuffling. If he is never found the activation is written off and the
// bubbles are swept instead.
var CabbageMickeyFaceColor = { r: 245, g: 225, b: 210 };
registerSkill({
    types: ["block_cabbage_mickey_s" /* SkillType.CabbageMickey */],
    afterActivate: function (ts) {
        // wait for all cabbages being placed
        ts.sleep(3300);
        var startTime = Date.now();
        var foundMickey = false;
        var maybeMickey = null;
        var color = null;
        var maxTries = 5;
        var _loop_1 = function (tries) {
            ts.sleep(100);
            var img = ts.screenshot();
            try {
                smooth(img, 2, 5);
                for (var y = 720; y < 1380 && !foundMickey; y += 25) {
                    for (var x = 120; x < 1000 && !foundMickey; x += 60) {
                        maybeMickey = { x: x, y: y };
                        color = ts.getColor(img, maybeMickey);
                        foundMickey = foundMickey || isSameColor(CabbageMickeyFaceColor, color, 20);
                        if (foundMickey) {
                            // NOTE: up/down/left/right all alias maybeMickey, and the four
                            // offsets below cancel out, so all four reads land back on the
                            // center pixel that already matched -- this confirmation step has
                            // never actually rejected anything. Kept as-is: the detection has
                            // been tuned around it, and separating the four points would
                            // change which frames pass.
                            var up = void 0, down = void 0, left = void 0, right = void 0;
                            up = down = left = right = maybeMickey;
                            up.y -= 10;
                            down.y += 10;
                            left.x -= 10;
                            right.x += 10;
                            foundMickey = (isSameColor(CabbageMickeyFaceColor, ts.getColor(img, up), 20)
                                || isSameColor(CabbageMickeyFaceColor, ts.getColor(img, down), 20))
                                && (isSameColor(CabbageMickeyFaceColor, ts.getColor(img, left), 20)
                                    || isSameColor(CabbageMickeyFaceColor, ts.getColor(img, right), 20));
                        }
                        if (ts.debug) {
                            // logical width is 1080, screenshot usually 360, so reduce xy by factor 3
                            drawCircle(img, x / 3, y / 3, 4, foundMickey ? 0 : 255, foundMickey ? 255 : 0, 0, 0);
                        }
                    }
                }
                if (!foundMickey) {
                    debug("*** Didn't find Mickey! ***", function () {
                        if (ts.debug) {
                            saveImage(img, getStoragePath() + "/tmp/boardImg-cabbageMickey_not_found-" + ts.runTimes + "-" + tries + ".jpg");
                            return "Saved screenshot";
                        }
                        else {
                            return "";
                        }
                    });
                }
                else {
                    if (ts.debug) {
                        saveImage(img, getStoragePath() + "/tmp/boardImg-cabbageMickey-" + ts.runTimes + "-" + tries + ".jpg");
                    }
                }
            }
            finally {
                releaseImage(img);
            }
        };
        for (var tries = 1; tries <= maxTries && !foundMickey; tries++) {
            _loop_1(tries);
        }
        if (foundMickey && maybeMickey != null) {
            debug("Found mickey at position", maybeMickey, "with color", color, "in", Date.now() - startTime, "ms.");
            var tapXY = { x: maybeMickey.x + 15, y: maybeMickey.y + 15 };
            for (var i = 0; i < 10; i++)
                ts.tap(tapXY);
            ts.sleep(1000);
        }
        else {
            ts.clearAllBubbles();
        }
    }
});
// Cpt. Lightyear — randomize, then timed aiming taps, then a bubble sweep.
//
// How many aiming taps land depends on the skill level, and the gaps between
// them are the animation's, so they can't be collapsed into one loop.
// Assumes the skill has already been activated (gauge consumed) -- callers tap
// gameSkill1 first.
Tsum.prototype.useCptLySkill = function () {
    this.tap(Button.gameRand, 100);
    this.sleep(2100);
    this.tap(Button.skillCptLy1, 10);
    this.sleep(50);
    this.tap(Button.skillCptLy2, 10);
    if (this.skillLevel >= 2) {
        // 3rd tap
        this.sleep(500);
        this.tap(Button.skillCptLy3, 10);
    }
    if (this.skillLevel >= 4) {
        // 4th tap
        this.sleep(500);
        this.tap(Button.skillCptLy3, 10);
    }
    if (this.skillLevel === 6) {
        // 5th tap
        this.sleep(550);
        this.tap(Button.skillCptLy3, 10);
    }
    this.clearAllBubbles(600, 0, 1000, 300);
};
registerSkill({
    types: ["block_cpt_ly_s" /* SkillType.CptLightyear */],
    afterActivate: function (ts) {
        ts.useCptLySkill();
    }
});
// Lightning McQueen+ — the car accelerates after activation and clears more the
// faster it is going, so the follow-up tap has to wait for top speed.
//
// Top speed is read off a single pixel of the play square going full red; the
// poll gives up after 20 tries and lets the animation finish on its own.
registerSkill({
    types: ["block_lightning_mcqueen_plus_s" /* SkillType.LightningMcQueenPlus */],
    beforeActivate: function (ts) {
        ts.sleep(200); // let tsums settle
    },
    afterActivate: function (ts) {
        ts.sleep(2000);
        for (var i = 1; i <= 20; i += 1) {
            ts.sleep(50);
            var img = ts.playScreenshotSquare();
            try {
                var color = getImageColor(img, 120, 184);
                if (isSameColor({ r: 245, g: 0, b: 0 }, color, 10)) {
                    // max speed detected
                    ts.tap({ x: 670, y: 1050 }, 10); // tap somewhere into the game
                    i = 20;
                }
            }
            finally {
                releaseImage(img);
            }
        }
        ts.sleep(2500);
        // ts.clearAllBubbles(600, 0, 1000, 300);
    }
});
// ---------------------------------------------------------------------------
// Tiara Minnie+
//
// The skill shows Minnie with a thought bubble holding one present, then a
// screen of presents to pick the match from; a fresh bubble comes with every
// pick. Both halves are read by cropping fixed boxes and comparing the pictures
// directly: the bubble is always drawn in the same place, and the presents
// always land on the centres in TiaraLayouts.
//
// Nothing here works out how many presents are on screen. Every centre from
// every layout is scored against the bubble and the best-matching one is
// tapped, so a miscounted screen cannot send the tap to the wrong place -- and
// two centres from different layouts that sit on the same present are both
// right answers. Offline this picked the correct present on all 20 frame/design
// pairs, and kept doing so with every centre shifted by up to 25px.
// ---------------------------------------------------------------------------
// Hue names for the debug line, over OpenCV's 0..179 hue range.
var TiaraHueNames = [
    { to: 8, name: 'red' }, { to: 20, name: 'orange' }, { to: 32, name: 'yellow' },
    { to: 44, name: 'lime' }, { to: 75, name: 'green' }, { to: 95, name: 'teal' },
    { to: 125, name: 'blue' }, { to: 145, name: 'purple' }, { to: 165, name: 'pink' },
    { to: 180, name: 'red' }
];
function tiaraHueName(h) {
    for (var i = 0; i < TiaraHueNames.length; i++) {
        if (h < TiaraHueNames[i].to) {
            return TiaraHueNames[i].name;
        }
    }
    return '?';
}
// A readable "bow/body" summary of a sampled present, so the log says what the
// script thinks it is looking at rather than just a score.
function tiaraDescribe(t, grid) {
    var split = Math.max(1, Math.floor(grid * 0.35));
    var part = function (r0, r1) {
        var sx = 0, sy = 0, w = 0;
        for (var r = r0; r < r1; r++) {
            for (var c = 0; c < grid; c++) {
                var k = (r * grid + c) * 5;
                if (t[k + 4] <= 0) {
                    continue;
                }
                sx += t[k];
                sy += t[k + 1];
                w += t[k + 2];
            }
        }
        if (w <= 0) {
            return 'white';
        }
        var h = Math.atan2(sy, sx) * 90 / Math.PI;
        if (h < 0) {
            h += 180;
        }
        return tiaraHueName(h);
    };
    return part(0, split) + ' bow / ' + part(split, grid) + ' body';
}
// Hue vector lookup. Every sampled cell turns its hue into a unit vector; there
// are a few thousand of those per match, and the hue is a byte.
//
// Filled for all 256 values, not just OpenCV's 0..179 hue range, so the table
// is a total function of the byte and cannot hand back undefined -- an
// out-of-range hue would otherwise turn the whole score into NaN, which fails
// every gate silently. The extra entries are the same wrap Math.cos would give.
var TiaraHueCos = [];
var TiaraHueSin = [];
(function () {
    for (var h = 0; h < 256; h++) {
        TiaraHueCos.push(Math.cos(h * Math.PI / 90));
        TiaraHueSin.push(Math.sin(h * Math.PI / 90));
    }
})();
// Reduce a template sampled by tiaraSample to just the cells it marks as
// present, laid out flat.
//
// Scoring only ever looks at those cells -- so neither the dark tsums behind a
// board present nor the white cloud behind the bubble one can influence the
// result -- which means the other cells of a candidate crop never need to be
// read at all. On the reference bubbles the mask keeps between 8% and 58% of
// the 144 cells, around 38% on average, and that is the factor it takes off
// every candidate.
function tiaraCompileTemplate(t, grid) {
    var idx = [], hx = [], hy = [], sat = [], val = [];
    var cells = grid * grid;
    for (var i = 0; i < cells; i++) {
        var k = i * 5;
        if (t[k + 4] <= 0) {
            continue;
        }
        idx.push(i);
        hx.push(t[k]);
        hy.push(t[k + 1]);
        sat.push(t[k + 2]);
        val.push(t[k + 3]);
    }
    return { idx: idx, hx: hx, hy: hy, sat: sat, val: val, n: idx.length };
}
// A coarse brightness fingerprint of the play area, cheap enough to take over
// and over. Used only to tell whether anything on the board is still moving.
Tsum.prototype.tiaraBoardSignature = function () {
    var cfg = TiaraMinnieConfig;
    var n = cfg.settleCapture;
    var img = getScreenshotModify(this.playOffsetX, this.playOffsetY, this.playWidth, this.playHeight, n, n, 100);
    var out = [];
    try {
        var step = n / cfg.settleGrid;
        for (var gy = 0; gy < cfg.settleGrid; gy++) {
            for (var gx = 0; gx < cfg.settleGrid; gx++) {
                var c = getImageColor(img, Math.floor((gx + 0.5) * step), Math.floor((gy + 0.5) * step));
                out.push((c.r + c.g + c.b) / 3);
            }
        }
    }
    finally {
        releaseImage(img);
    }
    return out;
};
function tiaraSignatureDiff(a, b) {
    var d = 0;
    for (var i = 0; i < a.length; i++) {
        d += Math.abs(a[i] - b[i]);
    }
    return d / a.length / 255;
}
// Hold off activating until the board stops moving.
//
// Tapping a present blows up an area of the board, so it pays to fire when the
// board is full and settled. The play loop clears a chain (and sometimes works
// the fan) immediately before the skill goes off, and a blast that lands while
// the tsums are still falling hits far fewer of them.
Tsum.prototype.tiaraWaitForSettledBoard = function () {
    var cfg = TiaraMinnieConfig;
    var start = Date.now();
    var deadline = start + cfg.settleWaitMs;
    var prev = this.tiaraBoardSignature();
    var quiet = 0;
    var diff = 1;
    while (Date.now() < deadline) {
        this.sleep(cfg.settlePollMs);
        var now = this.tiaraBoardSignature();
        diff = tiaraSignatureDiff(prev, now);
        prev = now;
        // Two quiet readings, not one, so a momentary lull mid-cascade doesn't pass.
        quiet = diff <= cfg.settleMaxDiff ? quiet + 1 : 0;
        if (quiet >= cfg.settleQuietScans && Date.now() - start >= cfg.settleMinMs) {
            if (this.debug) {
                console.log('[Tiara] board settled in ' + (Date.now() - start) + 'ms, diff ' + diff.toFixed(3));
            }
            return true;
        }
    }
    // Fire anyway: a late skill is worth more than a skipped one.
    log(this.logs.tiaraBusy, diff.toFixed(3));
    return false;
};
// Play square at matching resolution, blurred so one pixel read stands in for
// the average of its cell, then HSV -- where getImageColor gives b=hue 0..179,
// g=saturation, r=value.
Tsum.prototype.tiaraCapture = function () {
    var cfg = TiaraMinnieConfig;
    var img = getScreenshotModify(this.playOffsetX, this.playOffsetY, this.playWidth, this.playHeight, cfg.captureSize, cfg.captureSize, 100);
    smooth(img, 1, cfg.captureBlur);
    convertColor(img, 40);
    return img;
};
// The capture pixel each of the grid x grid cells of the logical square
// (lcx, lcy, side) reads from, flat and in row order. Cells falling outside the
// capture are marked -1 and read as black, as they always were.
//
// These depend only on the layout tables and the capture size, so every table
// is worked out once and kept -- the match loop would otherwise redo a few
// thousand of these multiplies per scan for coordinates that never change.
function tiaraCellPixels(lcx, lcy, side) {
    var cfg = TiaraMinnieConfig;
    var g = cfg.grid;
    var scale = cfg.captureSize / 1080;
    var step = side / g;
    var left = lcx - side / 2;
    var top = lcy - side / 2;
    var px = [], py = [];
    for (var cy = 0; cy < g; cy++) {
        for (var cx = 0; cx < g; cx++) {
            var x = Math.round((left + (cx + 0.5) * step) * scale);
            var y = Math.round((top + (cy + 0.5) * step - PlayAreaTopY) * scale);
            var inside = x >= 0 && y >= 0 && x < cfg.captureSize && y < cfg.captureSize;
            px.push(inside ? x : -1);
            py.push(inside ? y : -1);
        }
    }
    return { px: px, py: py };
}
var TiaraBubbleCells = null;
function tiaraBubbleCells() {
    if (TiaraBubbleCells == null) {
        var cfg = TiaraMinnieConfig;
        TiaraBubbleCells = tiaraCellPixels(cfg.bubbleX, cfg.bubbleY, cfg.bubbleSide);
    }
    return TiaraBubbleCells;
}
// Read a cell table into grid x grid cells. Each cell carries a
// saturation-weighted hue vector, saturation, value, and whether it looks like
// part of a present. Hue goes in as a vector so the 179->0 wrap cannot average
// a red into a cyan.
//
// Only the bubble goes through here now; candidates are read and compared in
// one pass by tiaraScoreCandidate, which never materialises this array.
Tsum.prototype.tiaraSample = function (img, cells) {
    var cfg = TiaraMinnieConfig;
    var n = cfg.grid * cfg.grid;
    var out = [];
    for (var i = 0; i < n; i++) {
        var px = cells.px[i];
        var h = 0, s = 0, v = 0;
        if (px >= 0) {
            var col = getImageColor(img, px, cells.py[i]);
            h = col.b;
            s = col.g;
            v = col.r;
        }
        out.push(s * TiaraHueCos[h] / 255);
        out.push(s * TiaraHueSin[h] / 255);
        out.push(s / 255);
        out.push(v / 255);
        out.push((s >= cfg.satMin && v >= cfg.valMin) ? 1 : 0);
    }
    return out;
};
// Small, unblurred capture for the cloud test only. That test is polled in a
// loop and only asks whether a big pale blob is on screen, which survives heavy
// downsampling -- the margin it works with is 0.49 against 0.09.
//
// Grabs the whole play square even though only cloudBox is read from it.
// Cropping to the box was tried: it is 88% less capture area, but it resamples
// the region on a slightly different grid, and this test decides when matching
// starts. Not worth an unproven change to that.
Tsum.prototype.tiaraCloudCapture = function () {
    var n = TiaraMinnieConfig.cloudCaptureSize;
    return getScreenshotModify(this.playOffsetX, this.playOffsetY, this.playWidth, this.playHeight, n, n, 100);
};
var TiaraCloudPoints = null;
// The capture pixels the cloud test reads -- the same points it always read,
// worked out once instead of on every poll, with the present dropped here
// rather than tested each time round.
function tiaraCloudPoints() {
    if (TiaraCloudPoints != null) {
        return TiaraCloudPoints;
    }
    var cfg = TiaraMinnieConfig;
    var box = cfg.cloudBox;
    var size = cfg.cloudCaptureSize;
    var scale = size / 1080;
    var half = cfg.bubbleSide / 2;
    var ex0 = cfg.bubbleX - half, ex1 = cfg.bubbleX + half;
    var ey0 = cfg.bubbleY - half, ey1 = cfg.bubbleY + half;
    var xs = [], ys = [];
    for (var ly = box.y0; ly <= box.y1; ly += cfg.cloudStep) {
        for (var lx = box.x0; lx <= box.x1; lx += cfg.cloudStep) {
            // Skip the present itself: only the cloud around it should count.
            if (lx >= ex0 && lx <= ex1 && ly >= ey0 && ly <= ey1) {
                continue;
            }
            var px = Math.round(lx * scale);
            var py = Math.round((ly - PlayAreaTopY) * scale);
            if (px < 0 || py < 0 || px >= size || py >= size) {
                continue;
            }
            xs.push(px);
            ys.push(py);
        }
    }
    TiaraCloudPoints = { xs: xs, ys: ys, n: xs.length };
    return TiaraCloudPoints;
}
// How much of the area around the bubble is pale cloud. Separates "bubble is
// up" from "presents are up" and from ordinary play by a wide margin: the
// sample frames read 0.48-0.50 with a bubble and 0.02-0.06 without one.
// Takes a capture from tiaraCloudCapture, not the matching one.
//
// Reads the raw BGR pixel: OpenCV's HSV value is max(b,g,r) and its saturation
// is 255*(max-min)/max, so the pale test can be made straight from the pixel
// and the whole-image colour conversion this poll used to run dropped. The
// saturation is rounded the way OpenCV rounds it, so pixels sitting exactly on
// the threshold fall the same side of it as before.
Tsum.prototype.tiaraCloudFrac = function (img) {
    var cfg = TiaraMinnieConfig;
    var pts = tiaraCloudPoints();
    if (pts.n === 0) {
        return 0;
    }
    var hit = 0;
    for (var i = 0; i < pts.n; i++) {
        var col = getImageColor(img, pts.xs[i], pts.ys[i]);
        var mx = col.r > col.g
            ? (col.r > col.b ? col.r : col.b)
            : (col.g > col.b ? col.g : col.b);
        if (mx < cfg.cloudValMin) {
            continue;
        }
        var mn = col.r < col.g
            ? (col.r < col.b ? col.r : col.b)
            : (col.g < col.b ? col.g : col.b);
        if (Math.round(255 * (mx - mn) / mx) <= cfg.cloudSatMax) {
            hit++;
        }
    }
    return hit / pts.n;
};
var TiaraCandidates = null;
// Every present centre from every layout, each with the cell table for the crop
// size that suits its count. Scored together; the count is never decided.
function tiaraCandidates() {
    if (TiaraCandidates != null) {
        return TiaraCandidates;
    }
    var out = [];
    for (var n = 2; n <= 6; n++) {
        var slots = TiaraLayouts[n];
        var side = TiaraSlotSide[n];
        for (var i = 0; i < slots.length; i++) {
            var cells = tiaraCellPixels(slots[i].x, slots[i].y, side);
            out.push({ x: slots[i].x, y: slots[i].y, count: n, px: cells.px, py: cells.py });
        }
    }
    TiaraCandidates = out;
    return out;
}
// Similarity of one candidate crop to the compiled bubble template, 0..1.
//
// Reading the pixel and comparing it happen in the same pass, over the
// template's cells only, so a candidate costs as many pixel reads as the mask
// has cells rather than a full grid. Each cell's difference is divided by
// cellSpread and clipped, which makes the score count clearly-wrong cells
// instead of averaging away small ones -- worth roughly triple the margin of a
// plain mean.
Tsum.prototype.tiaraScoreCandidate = function (img, cand, tpl) {
    var spread = TiaraMinnieConfig.cellSpread;
    if (tpl.n <= 0) {
        return 0;
    }
    var d = 0;
    for (var j = 0; j < tpl.n; j++) {
        var i = tpl.idx[j];
        var px = cand.px[i];
        var chx = 0, chy = 0, cs = 0, cv = 0;
        if (px >= 0) {
            var col = getImageColor(img, px, cand.py[i]);
            cs = col.g / 255;
            cv = col.r / 255;
            chx = cs * TiaraHueCos[col.b];
            chy = cs * TiaraHueSin[col.b];
        }
        var cell = (Math.abs(tpl.hx[j] - chx) + Math.abs(tpl.hy[j] - chy)
            + Math.abs(tpl.sat[j] - cs) + Math.abs(tpl.val[j] - cv)) / 4 / spread;
        if (cell > 1) {
            cell = 1;
        }
        d += cell;
    }
    return 1 - d / tpl.n;
};
Tsum.prototype.tiaraBestMatch = function (img, tpl) {
    var cands = tiaraCandidates();
    var n = cands.length;
    var scores = [];
    var bi = 0;
    for (var i = 0; i < n; i++) {
        scores.push(this.tiaraScoreCandidate(img, cands[i], tpl));
        if (scores[i] > scores[bi]) {
            bi = i;
        }
    }
    var best = cands[bi];
    // Centres from different layouts can land on the same present, and tapping
    // either is correct, so the margin is measured against the best candidate
    // that is somewhere else entirely.
    var rival = -1;
    for (var i = 0; i < n; i++) {
        var dx = cands[i].x - best.x, dy = cands[i].y - best.y;
        if (dx * dx + dy * dy < 100 * 100) {
            continue;
        }
        if (rival < 0 || scores[i] > scores[rival]) {
            rival = i;
        }
    }
    return {
        x: best.x, y: best.y, count: best.count, score: scores[bi],
        margin: rival < 0 ? scores[bi] : scores[bi] - scores[rival]
    };
};
// Wait for the thought bubble, then read the present inside it.
Tsum.prototype.tiaraWaitForDream = function (timeoutMs) {
    var cfg = TiaraMinnieConfig;
    var deadline = Date.now() + timeoutMs;
    var seen = false;
    while (Date.now() < deadline) {
        var img = this.tiaraCloudCapture();
        try {
            seen = this.tiaraCloudFrac(img) >= cfg.cloudMinFrac;
        }
        finally {
            releaseImage(img);
        }
        if (seen) {
            break;
        }
        this.sleep(cfg.pollMs);
    }
    if (!seen) {
        return null;
    }
    // The bubble scales in; reading it mid-animation gives a shrunken present.
    this.sleep(cfg.dreamSettleMs);
    var img2 = this.tiaraCapture();
    try {
        return this.tiaraSample(img2, tiaraBubbleCells());
    }
    finally {
        releaseImage(img2);
    }
};
// Wait for the presents to land, then tap the one matching the template. The
// game timer is stopped for this whole stretch, so every check here is free.
//
// Three things must agree before a tap goes out: the score clears the floor,
// the winner beats everything elsewhere by the margin (which is what actually
// proves a present is there rather than a lucky patch of board), and the same
// centre wins twice running.
Tsum.prototype.tiaraPick = function (tpl) {
    var cfg = TiaraMinnieConfig;
    var deadline = Date.now() + cfg.choiceWaitMs;
    // A template with no cells scores every candidate 0, so no tap can ever clear
    // the floor. Leave now rather than spend choiceWaitMs of full-resolution
    // captures proving it.
    if (tpl.n <= 0) {
        return null;
    }
    // The presents only exist once the bubble has gone.
    while (Date.now() < deadline) {
        var img = this.tiaraCloudCapture();
        var gone = void 0;
        try {
            gone = this.tiaraCloudFrac(img) < cfg.cloudMinFrac;
        }
        finally {
            releaseImage(img);
        }
        if (gone) {
            break;
        }
        this.sleep(cfg.pollMs);
    }
    this.sleep(cfg.choiceLeadMs);
    var agree = 0;
    var last = null;
    while (Date.now() < deadline) {
        var img = this.tiaraCapture();
        var m = void 0;
        try {
            m = this.tiaraBestMatch(img, tpl);
        }
        finally {
            releaseImage(img);
        }
        if (m.score >= cfg.confidenceFloor && m.margin >= cfg.marginFloor) {
            agree = (last != null && last.x === m.x && last.y === m.y) ? agree + 1 : 1;
            last = m;
            if (agree >= cfg.agreeScans) {
                for (var i = 0; i < cfg.pickTaps; i++) {
                    this.tap({ x: m.x, y: m.y }, cfg.pickTapDuring);
                    if (i + 1 < cfg.pickTaps) {
                        this.sleep(cfg.pickTapGapMs);
                    }
                }
                return m;
            }
        }
        else {
            agree = 0;
            last = null;
            if (this.debug) {
                console.log('[Tiara] waiting: best ' + m.score.toFixed(2)
                    + ' margin ' + m.margin.toFixed(2) + ' at ' + m.x + ',' + m.y);
            }
        }
        this.sleep(cfg.matchPollMs);
    }
    return null;
};
// One bubble, one pick, per activation.
//
// The thought bubble is only shown once, straight after the skill fires -- it
// does not come back between picks -- so once the present is tapped there is
// nothing left to wait for and this returns straight away. (The 2-to-6
// progression happens across activations, not inside one.)
Tsum.prototype.useTiaraMinniePlusSkill = function () {
    var cfg = TiaraMinnieConfig;
    var started = Date.now();
    this.sleep(cfg.dreamLeadMs);
    var armed = Date.now();
    var template = this.tiaraWaitForDream(cfg.dreamWaitMs);
    if (template == null) {
        log(this.logs.tiaraNoDream);
        return 0;
    }
    log(this.logs.tiaraDream, tiaraDescribe(template, cfg.grid), 'after ' + (Date.now() - armed) + 'ms');
    // Compiled once and reused by every candidate of every scan.
    var pick = this.tiaraPick(tiaraCompileTemplate(template, cfg.grid));
    if (pick == null) {
        log(this.logs.tiaraUnsure);
        return 0;
    }
    log(this.logs.tiaraPicked, pick.x + ',' + pick.y, 'score ' + pick.score.toFixed(2), 'margin ' + pick.margin.toFixed(2), 'layout ' + pick.count, 'total ' + (Date.now() - started) + 'ms');
    return 1;
};
registerSkill({
    types: ["block_tiara_minnie_plus_s" /* SkillType.TiaraMinniePlus */],
    beforeActivate: function (ts) {
        // Her picks detonate the board, so wait for it to stop moving first.
        ts.tiaraWaitForSettledBoard();
    },
    afterActivate: function (ts) {
        ts.useTiaraMinniePlusSkill();
        // Always report "did not fire", whatever happened. The caller runs
        // `while (useSkill())`, and for a skill that takes seconds of choreography
        // an immediate second go is never right: the gauge still reads active
        // through the outro, so a `true` here buys another settle wait, lead-in and
        // bubble wait -- about six seconds of standing still -- before the missing
        // bubble finally ends it. If the gauge really is full again, the next
        // board-scan cycle picks it up one cycle later, which costs nothing like
        // as much.
        return false;
    }
});
// Click Assist: the user picks the tsum, the script draws the chain.
//
// Instead of scanning and linking on its own cadence, the script sits on the
// touch event stream and reacts to where the user taps. Auto-play and Click
// Assist are mutually exclusive (see start()).
// Locate the touchscreen input device by parsing `getevent -lp`. Cached for the
// life of the Tsum instance -- the device does not change mid-session.
Tsum.prototype.findTouchDevice = function () {
    if (this._touchDevice !== undefined) {
        return this._touchDevice;
    }
    var raw = execute('getevent -lp 2>&1') || '';
    var sections = raw.split(/add device \d+:\s*/);
    var best = null;
    for (var s = 1; s < sections.length; s++) {
        var section = sections[s];
        var firstLineEnd = section.indexOf('\n');
        if (firstLineEnd === -1) {
            continue;
        }
        var path = section.substring(0, firstLineEnd).trim();
        if (path.indexOf('/dev/input/event') !== 0) {
            continue;
        }
        if (section.indexOf('ABS_MT_POSITION_X') === -1) {
            continue;
        }
        var xMax = 0, yMax = 0;
        var xm = section.match(/ABS_MT_POSITION_X[^\n]*max\s+(\d+)/);
        var ym = section.match(/ABS_MT_POSITION_Y[^\n]*max\s+(\d+)/);
        if (xm) {
            xMax = parseInt(xm[1], 10);
        }
        if (ym) {
            yMax = parseInt(ym[1], 10);
        }
        best = { path: path, xMax: xMax, yMax: yMax };
        break;
    }
    this._touchDevice = best;
    if (best) {
        log('Click Assist: input device ' + best.path + ' (max ' + best.xMax + 'x' + best.yMax + ')');
    }
    else {
        log('Click Assist: could not locate touch input device');
    }
    return best;
};
// Block for up to `timeoutSec` seconds waiting for a BTN_TOUCH DOWN with X/Y
// coordinates. Returns the touch position in screen pixels, or null on timeout.
// Uses `timeout` from toybox/busybox; falls back to no-timeout (script must rely
// on the user actually touching the screen) if the timeout command is missing.
Tsum.prototype.pollTouchDown = function (timeoutSec) {
    var device = this.findTouchDevice();
    if (!device) {
        return null;
    }
    // `-c N` exits after N events. We want the X/Y/BTN_TOUCH triplet plus a
    // little headroom for tracking-id/sync events.
    var cmd = 'timeout ' + timeoutSec + ' getevent -lc 12 ' + device.path + ' 2>/dev/null';
    var raw = execute(cmd) || '';
    if (raw.length === 0) {
        return null;
    }
    var lines = raw.split('\n');
    var lastX = null, lastY = null;
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        var m = void 0;
        if ((m = line.match(/ABS_MT_POSITION_X\s+([0-9a-fA-F]+)/))) {
            lastX = parseInt(m[1], 16);
        }
        else if ((m = line.match(/ABS_MT_POSITION_Y\s+([0-9a-fA-F]+)/))) {
            lastY = parseInt(m[1], 16);
        }
    }
    // Any X/Y in the event burst means the user touched (or moved/released) on
    // the screen. We don't gate on BTN_TOUCH because protocol B devices and many
    // emulators omit it. Reacting on the release position is still the position
    // the user intended.
    if (lastX === null || lastY === null) {
        return null;
    }
    // Scale device coords to screen pixels. If the device reports max==0 or
    // matches the screen pixel size already, the touch is treated as direct
    // pixel coordinates.
    var screenX = lastX;
    var screenY = lastY;
    if (device.xMax > 0 && device.xMax !== this.originScreenWidth) {
        screenX = lastX * this.originScreenWidth / device.xMax;
    }
    if (device.yMax > 0 && device.yMax !== this.originScreenHeight) {
        screenY = lastY * this.originScreenHeight / device.yMax;
    }
    return { x: screenX, y: screenY };
};
// Stops auto-linking and waits for the user to tap a tsum. On each tap, finds
// the connected component containing the touched tsum's color and chains them.
// The user supplies the "where", the script supplies the draw.
Tsum.prototype.taskClickAssist = function () {
    this.requestTsumMonitor();
    log('Click Assist: ' + this.logs.gameStart);
    this.goGamePlayingPage();
    log('Click Assist: tap a tsum to connect its chain');
    this.runTimes = 0;
    this.myTsumColor = null;
    this.myTsumIdx = -1;
    var pageCheckEvery = 5;
    var sinceLastPageCheck = 0;
    var lastActTime = 0;
    while (this.isRunning) {
        var touch = this.pollTouchDown(1);
        if (touch === null) {
            sinceLastPageCheck++;
            if (sinceLastPageCheck >= pageCheckEvery) {
                sinceLastPageCheck = 0;
                var page = this.findPage(1, 1500);
                if (page !== "GamePlaying" /* PageName.GamePlaying */ && page !== "GamePause" /* PageName.GamePause */) {
                    this.sleep(500);
                    page = this.findPage(1, 1500);
                    if (page !== "GamePlaying" /* PageName.GamePlaying */ && page !== "GamePause" /* PageName.GamePause */) {
                        log(this.logs.gameOver);
                        break;
                    }
                }
            }
            continue;
        }
        sinceLastPageCheck = 0;
        // Debounce: ignore taps that arrive too soon after we just drew a chain --
        // those are most likely the trailing events of our own synthetic input.
        var now = Date.now();
        if (now - lastActTime < 600) {
            continue;
        }
        // Only react to taps inside the play area; taps on UI chrome (skill button,
        // pause, etc.) should be ignored.
        var inPlay = touch.x >= this.playOffsetX
            && touch.x < this.playOffsetX + this.playWidth
            && touch.y >= this.playOffsetY
            && touch.y < this.playOffsetY + this.playHeight;
        if (!inPlay) {
            debug('Click Assist: tap outside play area at (' + touch.x + ',' + touch.y + ')');
            continue;
        }
        // Map screen-pixel tap to the playResize coordinate space the board uses.
        var boardX = (touch.x - this.playOffsetX) * this.playResizeWidth / this.playWidth - Config.tsumWidth / 2;
        var boardY = (touch.y - this.playOffsetY) * this.playResizeHeight / this.playHeight - Config.tsumWidth / 2;
        // Brief pause so the user's finger lifts before we start our own input.
        this.sleep(120);
        var board = this.scanBoardQuick();
        if (board == null) {
            break;
        }
        var chain = findChainAtTouch(board, boardX, boardY);
        if (chain && chain.length >= 3) {
            log('Click Assist: linking ' + chain.length + ' tsums');
            this.linkTsums(chain);
            lastActTime = Date.now();
            this.sleep(400);
        }
        else {
            debug('Click Assist: no chain at tap (' + boardX + ',' + boardY + ')');
        }
        this.runTimes++;
    }
};
// ---------------------------------------------------------------------------
// Native (system) dialogs: root detection, permission prompts, ...
//
// The game's root warning is an Android AlertDialog, not a game screen, and that
// difference broke the old handling in two ways:
//
//  * Coordinate space. Android lays a dialog out in *device* pixels over the
//    whole display, while every Page/Button coordinate here lives in the game's
//    logical 1080x1920 letterbox space and is converted by toRealXY(). The two
//    only agree on an exactly 9:16 screen, so the per-emulator RootDetection*
//    fingerprints (LDPlayer/Nox/SamsungA20/...) silently miss elsewhere -- and
//    when one of them does match, it may be the variant for a *different* dpi,
//    which puts the "PERMIT" tap next to the button instead of on it.
//  * Fallback. An unrecognized screen went to exitUnknownPage(), whose blind
//    DPAD_DOWN + ENTER can activate the dialog's negative button. "REFUSE" on
//    the root warning quits the game, autoLaunch starts it again, the dialog
//    comes back -- the endless startup loop.
//
// So dialogs are handled structurally in device pixels instead: find the light
// panel floating over the dimmed background, find its button row, and tap the
// rightmost label (Android puts the positive button last). Nothing below depends
// on resolution, dpi, emulator or game language.
// ---------------------------------------------------------------------------
/** Downscale target for dialog scans: coarse enough to be cheap, fine enough to keep button labels legible. */
var DialogScanWidth = 540;
/** Labels that dismiss the dialog the way we want (EN/JP/TW/KR wording). */
var DialogPositiveText = /^(permit|allow|ok|yes|agree|accept|continue|許可|許可する|同意|同意する|はい|確定|確認|允許|允许|확인)$/i;
/** Labels never to tap: "REFUSE" on the root warning closes the game. */
var DialogNegativeText = /(refuse|deny|cancel|exit|quit|later|拒否|拒绝|拒絕|取消|いいえ|終了|취소)/i;
/** The dialog's own background: light and near-neutral (white/off-white panel). */
function isDialogPanelColor(c) {
    if (c === undefined || c === null) {
        return false;
    }
    var max = Math.max(c.r, c.g, c.b);
    var min = Math.min(c.r, c.g, c.b);
    return min >= 200 && (max - min) <= 28;
}
/** Accent-coloured ink. In an AlertDialog only the buttons are coloured; title and message are grey. */
function isDialogAccentColor(c) {
    if (c === undefined || c === null) {
        return false;
    }
    return (Math.max(c.r, c.g, c.b) - Math.min(c.r, c.g, c.b)) >= 30;
}
/** Full-screen capture in device space, downscaled to ~DialogScanWidth. Quality 100: JPEG ringing around dialog edges and thin button text is exactly what we are measuring. */
Tsum.prototype.dialogScreenshot = function (sw, sh) {
    return getScreenshotModify(0, 0, this.originScreenWidth, this.originScreenHeight, sw, sh, 100);
};
/**
 * Structural search for a native dialog: a light, near-neutral panel that spans
 * most of the width, is bounded above and below by darker (dimmed) rows, and
 * never reaches the screen edges. That last part is what separates a dialog
 * from the game's own bright screens (loading, white popups), which run edge to
 * edge. Returns null when no such panel is on screen.
 */
Tsum.prototype.findSystemDialog = function () {
    var scale = Math.max(1, this.originScreenWidth / DialogScanWidth);
    var sw = Math.floor(this.originScreenWidth / scale);
    var sh = Math.floor(this.originScreenHeight / scale);
    var img = this.dialogScreenshot(sw, sh);
    try {
        var probes = [Math.floor(sw * 0.35), Math.floor(sw * 0.5), Math.floor(sw * 0.65)];
        var yStep = 2;
        // A line of message text can darken all three probes at once, so the panel
        // is allowed to drop out for up to one text line without ending the run.
        // Still far below the height of the dimmed band above and below a dialog.
        var gapTol = Math.max(6, Math.round(sh * 0.04));
        var top_1 = -1, bottom = -1, rows = 0;
        var curTop = -1, curRows = 0, lastHit = -1;
        for (var y = 0; y < sh; y += yStep) {
            var lit = 0;
            for (var i = 0; i < probes.length; i++) {
                if (isDialogPanelColor(getImageColor(img, probes[i], y))) {
                    lit++;
                }
            }
            if (lit >= 2) {
                if (curTop < 0) {
                    curTop = y;
                    curRows = 0;
                }
                lastHit = y;
                curRows++;
            }
            else if (curTop >= 0 && (y - lastHit) > gapTol) {
                if (curRows > rows) {
                    rows = curRows;
                    top_1 = curTop;
                    bottom = lastHit;
                }
                curTop = -1;
            }
        }
        if (curTop >= 0 && curRows > rows) {
            rows = curRows;
            top_1 = curTop;
            bottom = lastHit;
        }
        if (top_1 < 0) {
            return null;
        }
        var height = bottom - top_1;
        if (top_1 <= yStep || bottom >= sh - 1 - yStep) {
            return null; // touches an edge: a game screen, not a floating dialog
        }
        if (height < sh * 0.06 || height > sh * 0.8) {
            return null;
        }
        if (rows * yStep < height * 0.55) {
            return null; // mostly gaps: the run was merged across unrelated bands
        }
        // Horizontal extent, read from the padding rows a dialog keeps blank. Three
        // of them, widest wins: a title, an icon or a long message line can cross
        // any single row and cut the measured panel in half.
        var xGap = Math.max(4, Math.round(sw * 0.02));
        var edges = [
            top_1 + Math.max(2, Math.round(height * 0.06)),
            top_1 + Math.max(3, Math.round(height * 0.15)),
            bottom - Math.max(2, Math.round(height * 0.03))
        ];
        var left = -1, right = -1;
        for (var e = 0; e < edges.length; e++) {
            var curLeft = -1, lastX = -1;
            for (var x = 0; x < sw; x += 2) {
                if (isDialogPanelColor(getImageColor(img, x, edges[e]))) {
                    if (curLeft < 0) {
                        curLeft = x;
                    }
                    lastX = x;
                }
                else if (curLeft >= 0 && (x - lastX) > xGap) {
                    if (lastX - curLeft > right - left) {
                        left = curLeft;
                        right = lastX;
                    }
                    curLeft = -1;
                }
            }
            if (curLeft >= 0 && lastX - curLeft > right - left) {
                left = curLeft;
                right = lastX;
            }
        }
        if (left < 0 || right - left < sw * 0.45 || left <= 2 || right >= sw - 3) {
            return null;
        }
        return {
            x0: left, y0: top_1, x1: right, y1: bottom,
            dx0: Math.round(left * scale), dy0: Math.round(top_1 * scale),
            dx1: Math.round(right * scale), dy1: Math.round(bottom * scale),
            scale: scale, sw: sw, sh: sh
        };
    }
    finally {
        releaseImage(img);
    }
};
/**
 * Locate the positive button inside a known dialog panel and return its device
 * coordinates. The button bar is the bottom-most row of ink in the panel; within
 * it the rightmost label is the positive button ("PERMIT"), because Android
 * orders the bar [negative][neutral][positive] left to right.
 *
 * Caveat: a dialog with labels too long for one row stacks its buttons and puts
 * the positive one on *top*, so the bottom-most row would be the negative one.
 * That layout is why tapDialogButtonViaUi() is tried as well -- it reads the
 * button identity from Android instead of inferring it from geometry.
 */
Tsum.prototype.findDialogButton = function (box) {
    var img = this.dialogScreenshot(box.sw, box.sh);
    try {
        var panelW = box.x1 - box.x0;
        var panelH = box.y1 - box.y0;
        // Stay clear of the panel border (and of a scrollbar, if the message scrolls).
        var inset = Math.max(3, Math.round(panelW * 0.03));
        var bx0_1 = box.x0 + inset;
        var bx1_1 = box.x1 - inset;
        var by1 = box.y1 - Math.max(2, Math.round(panelH * 0.02));
        var by0 = box.y1 - Math.max(10, Math.round(panelH * 0.32));
        var xStep_1 = Math.max(2, Math.round(panelW / 120));
        var samples_1 = Math.floor((bx1_1 - bx0_1) / xStep_1) + 1;
        var rowInk = function (y) {
            var ink = 0;
            for (var x = bx0_1; x <= bx1_1; x += xStep_1) {
                if (!isDialogPanelColor(getImageColor(img, x, y))) {
                    ink++;
                }
            }
            return ink;
        };
        // A row inked nearly all the way across is a divider (or the panel's own
        // border), not a label -- text leaves gaps. Treating it as a label would
        // stretch the "rightmost word" to the panel edge and aim the tap past the
        // button, so dividers bound the band instead of joining it.
        var isTextRow = function (ink) { return ink >= 2 && ink < samples_1 * 0.7; };
        var bandBottom = -1;
        for (var y = by1; y >= by0; y -= 2) {
            if (isTextRow(rowInk(y))) {
                bandBottom = y;
                break;
            }
        }
        if (bandBottom < 0) {
            return null; // empty panel bottom: a progress dialog, or no buttons at all
        }
        var lineH = Math.max(6, Math.round(panelH * 0.08));
        var bandTop = bandBottom;
        var blanks = 0;
        for (var y = bandBottom - 2; y >= by0 && bandBottom - y <= lineH * 2; y -= 2) {
            var ink_1 = rowInk(y);
            if (ink_1 >= samples_1 * 0.7) {
                break;
            }
            if (ink_1 >= 2) {
                bandTop = y;
                blanks = 0;
            }
            else if (++blanks >= 2) {
                break;
            }
        }
        // Fine pass over the band only: at this step the sampling actually lands on
        // the thin glyph strokes, so the label's right end is measured, not guessed.
        var accent = [];
        var ink = [];
        for (var y = bandTop; y <= bandBottom; y++) {
            for (var x = bx0_1; x <= bx1_1; x += 2) {
                var c = getImageColor(img, x, y);
                if (isDialogPanelColor(c)) {
                    continue;
                }
                ink.push(x);
                if (isDialogAccentColor(c)) {
                    accent.push(x);
                }
            }
        }
        var hits = accent.length >= 6 ? accent : ink;
        if (hits.length === 0) {
            return null;
        }
        hits.sort(function (a, b) { return a - b; });
        // Cluster into words and keep the rightmost one. The gap threshold sits
        // between a letter gap and the padding between two button labels.
        var gap = Math.max(10, Math.round(panelW * 0.035));
        var clusterMin = hits[0];
        var prev = hits[0];
        for (var i = 1; i < hits.length; i++) {
            if (hits[i] - prev > gap) {
                clusterMin = hits[i];
            }
            prev = hits[i];
        }
        // Aim just inside the label's right end. A button always pads past its text,
        // so this is inside the positive button and as far from "REFUSE" as the
        // label allows -- which keeps the tap safe even if both words, for want of a
        // wide enough gap, ended up in one cluster.
        var targetX = Math.max(clusterMin, prev - Math.max(2, Math.round(panelW * 0.015)));
        var targetY = (bandTop + bandBottom) / 2;
        return {
            x: Math.round((targetX + 0.5) * box.scale),
            y: Math.round((targetY + 0.5) * box.scale)
        };
    }
    finally {
        releaseImage(img);
    }
};
/**
 * Dump the Android view hierarchy. Robotmon's shell starts without a
 * BOOTCLASSPATH, so uiautomator (an app_process shim) cannot boot its VM
 * without the same prefix startTsumTsumApp() uses for `am`. Returns "" when the
 * command is unavailable, and stops trying after two duds so the dialog path
 * does not pay for it on every attempt.
 */
Tsum.prototype.dumpUiXml = function () {
    if (this._uiDumpFailures >= 2) {
        return '';
    }
    var path = this.storagePath + '/tmp/ui_dump.xml';
    execute('rm -f ' + path);
    execute(ShellBootClassPath + ' uiautomator dump ' + path);
    var xml = readFile(path);
    if (typeof xml !== 'string' || xml.indexOf('<hierarchy') === -1) {
        this._uiDumpFailures = (this._uiDumpFailures || 0) + 1;
        log('[Dialog] uiautomator dump unavailable (' + this._uiDumpFailures + '/2), using pixels only');
        return '';
    }
    this._uiDumpFailures = 0;
    return xml;
};
/**
 * Ask Android where the dialog's buttons are and tap the positive one. This is
 * the only path that knows a button's *identity* (`android:id/button1` is the
 * positive button whatever the locale or layout), so it also covers stacked
 * button bars, which the pixel scan can misread. Candidates are restricted to
 * the panel we already found, so a stray clickable view elsewhere on screen
 * cannot be picked. Returns whether a tap was issued.
 */
Tsum.prototype.tapDialogButtonViaUi = function (box) {
    var xml = this.dumpUiXml();
    if (xml === '') {
        return false;
    }
    var nodes = xml.match(/<node[^>]*>/g);
    if (nodes === null) {
        return false;
    }
    var margin = Math.max(8, Math.round(this.originScreenHeight * 0.01));
    var labelled = null, positive = null, button = null, clickable = null;
    for (var i = 0; i < nodes.length; i++) {
        var node = nodes[i];
        var bounds = /bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"/.exec(node);
        if (bounds === null) {
            continue;
        }
        var l = +bounds[1], t = +bounds[2], r = +bounds[3], b = +bounds[4];
        if (r <= l || b <= t) {
            continue;
        }
        if (l < box.dx0 - margin || r > box.dx1 + margin || t < box.dy0 - margin || b > box.dy1 + margin) {
            continue; // outside the panel
        }
        var textMatch = /text="([^"]*)"/.exec(node);
        var text = textMatch === null ? '' : textMatch[1];
        if (DialogNegativeText.test(text)) {
            continue;
        }
        var idMatch = /resource-id="([^"]*)"/.exec(node);
        var resId = idMatch === null ? '' : idMatch[1];
        var target_1 = { x: Math.floor((l + r) / 2), y: Math.floor((t + b) / 2), text: text, left: l };
        if (labelled === null && DialogPositiveText.test(text.replace(/\s+/g, ''))) {
            labelled = target_1;
        }
        if (positive === null && resId === 'android:id/button1') {
            positive = target_1;
        }
        if (node.indexOf('.Button"') !== -1 && (button === null || l > button.left)) {
            button = target_1;
        }
        if (text !== '' && node.indexOf('clickable="true"') !== -1 && (clickable === null || l > clickable.left)) {
            clickable = target_1;
        }
    }
    var target = labelled || positive || button || clickable;
    if (target === null) {
        return false;
    }
    log('[Dialog] uiautomator: tapping "' + target.text + '" at ' + target.x + ',' + target.y);
    tap(target.x, target.y, 60);
    return true;
};
/** Wait out the dismiss animation, then report whether that dialog is gone (or was replaced by a different one). */
Tsum.prototype.dialogChanged = function (box) {
    this.sleep(1200);
    var now = this.findSystemDialog();
    if (now === null) {
        return true;
    }
    var tol = Math.max(8, Math.round(this.originScreenHeight * 0.02));
    return Math.abs(now.dy0 - box.dy0) > tol
        || Math.abs((now.dy1 - now.dy0) - (box.dy1 - box.dy0)) > tol;
};
/**
 * Work through the ways of pressing a dialog's positive button, cheapest and
 * safest first, verifying after each one. `hint` is the coordinate recorded for
 * whichever RootDetection* variant matched -- right for that one emulator and
 * dpi, so it is worth a try, but only after the two self-calibrating paths.
 */
Tsum.prototype.tryDismissDialog = function (box, hint) {
    var btn = this.findDialogButton(box);
    if (btn !== null) {
        log('[Dialog] tapping the rightmost label at ' + btn.x + ',' + btn.y);
        tap(btn.x, btn.y, 60);
        if (this.dialogChanged(box)) {
            return true;
        }
    }
    else {
        log('[Dialog] no button row found in the panel');
    }
    if (this.tapDialogButtonViaUi(box) && this.dialogChanged(box)) {
        return true;
    }
    if (hint !== undefined && hint !== null) {
        log('[Dialog] trying the coordinates recorded for the matched page variant');
        this.tap(hint);
        if (this.dialogChanged(box)) {
            return true;
        }
    }
    if (this.autoLaunch) {
        // Last resort. Android moves dpad focus geometrically, so repeated RIGHT
        // parks it on the rightmost button of the bar -- the positive one in any
        // LTR layout. Gated on autoLaunch because a wrong ENTER here can hit
        // "REFUSE" and close the game, and only then can the script bring it back.
        log('[Dialog] falling back to dpad focus + enter');
        for (var i = 0; i < 5; i++) {
            keycode("KEYCODE_DPAD_RIGHT" /* KeyCode.DpadRight */, 50);
            this.sleep(100);
        }
        keycode("KEYCODE_ENTER" /* KeyCode.Enter */, 50);
        if (this.dialogChanged(box)) {
            return true;
        }
    }
    log('[Dialog] could not dismiss the dialog. Send the saved screenshot if this keeps happening.');
    this.saveDebugScreenshot('dialog');
    return false;
};
/**
 * Dismiss any native dialog on screen (root warning, permission prompt) by
 * pressing its positive button. Returns true when a dialog was found and is
 * gone; false when there was none, or when nothing worked. Dismissing one
 * dialog can reveal the next, so it repeats a few times.
 */
Tsum.prototype.dismissSystemDialog = function (hint) {
    var dismissed = false;
    for (var round = 0; round < 3 && this.isRunning; round++) {
        var box = this.findSystemDialog();
        if (box === null) {
            return dismissed;
        }
        log('[Dialog] native dialog at ' + box.dx0 + ',' + box.dy0 + ' '
            + (box.dx1 - box.dx0) + 'x' + (box.dy1 - box.dy0) + ' (device px)');
        if (!this.tryDismissDialog(box, hint)) {
            return dismissed;
        }
        dismissed = true;
        this.isStartupPhase = true; // whatever it interrupted, the game is still coming up
    }
    return dismissed;
};
/** Full-resolution screen dump for calibrating what the script could not read. Rate-limited so a stuck screen cannot fill up storage. */
Tsum.prototype.saveDebugScreenshot = function (tag) {
    if (Date.now() - (this._lastDebugShot || 0) < 5 * 60 * 1000) {
        return;
    }
    this._lastDebugShot = Date.now();
    var path = this.storagePath + '/tmp/' + tag + '_' + Date.now() + '.png';
    var img = this.dialogScreenshot(this.originScreenWidth, this.originScreenHeight);
    try {
        saveImage(img, path);
        log('[Dialog] saved screen to ' + path);
    }
    catch (e) {
        log('[Dialog] could not save screen: ' + e);
    }
    finally {
        releaseImage(img);
    }
};
// ---------------------------------------------------------------------------
// Stall guard
//
// The navigation loops (goFriendPage, goGamePlayingPage, goTsumsPage) only exit
// by reaching their target page, so one screen they cannot leave wedged the
// whole script: taskPlayGameQuick never returns, which means the task
// controller never gets to run anything else either -- including the app
// restart task. Each loop now reports the page it just handled; when the screen
// stops moving, escalate: look for a modal dialog first, then restart the app.
// ---------------------------------------------------------------------------
var StallDialogAfter = 12; // ~15s stuck: look for a modal dialog
var StallRestartAfter = 30; // ~40s stuck: bounce the game app
var StallMaxRestarts = 3;
Tsum.prototype.newStallGuard = function (where) {
    return { where: where, page: '', repeats: 0, rounds: 0, dialogTried: false, restarts: 0 };
};
Tsum.prototype.checkStall = function (guard, page) {
    guard.rounds++;
    if (page !== guard.page) {
        guard.page = page;
        guard.repeats = 0;
    }
    else {
        guard.repeats++;
    }
    // Two signals: the same screen coming back (the common case) and the loop
    // simply never reaching its target, which also covers a screen that flickers
    // between two detections -- that keeps the repeat counter at zero forever.
    var stuck = Math.max(guard.repeats, Math.floor(guard.rounds / 2));
    if (!guard.dialogTried && stuck >= StallDialogAfter) {
        // A fingerprint can match the wrong screen, and a native dialog on top of
        // the game matches nothing at all -- either way it is worth a look before
        // reaching for the restart.
        guard.dialogTried = true;
        log('[Stall] ' + guard.where + ': stuck on ' + page + ', checking for a native dialog');
        this.dismissSystemDialog();
        return;
    }
    if (stuck < StallRestartAfter) {
        return;
    }
    guard.repeats = 0;
    guard.rounds = 0;
    guard.dialogTried = false;
    if (guard.restarts >= StallMaxRestarts || !this.autoLaunch) {
        log('[Stall] ' + guard.where + ': still stuck on ' + page + '. '
            + (this.autoLaunch
                ? 'Restarted the game ' + guard.restarts + ' time(s) already.'
                : 'Enable "Auto launch app" to let the script restart the game.')
            + ' Waiting 30s.');
        this.saveDebugScreenshot('stall');
        this.sleep(30000);
        return;
    }
    guard.restarts++;
    log('[Stall] ' + guard.where + ': restarting the game app (' + guard.restarts + '/' + StallMaxRestarts + ')');
    this.forceRestartApp();
};
function start(settings) {
    ts = new Tsum(settings['jpVersion'], settings['specialScreenRatio'], settings['langTaiwan'] ? LogsTW : Logs);
    ts.settings = settings;
    log(ts.logs.start);
    ts.debug = settings['debugGame'];
    ts.bonus5to4 = !!settings['bonus5to4'];
    if (ts.bonus5to4) {
        ts.tsumCount = 4;
    }
    ts.prioritizeMyTsum = !!settings['prioritizeMyTsum'];
    ts.autoLaunch = settings['autoLaunchApp'];
    ts.scoreItem = settings['bonusScore'];
    ts.coinItem = settings['bonusCoin'];
    ts.expItem = settings['bonusExp'];
    ts.timeItem = settings['bonusTime'];
    ts.bubbleItem = settings['bonusBubble'];
    ts.comboItem = settings['bonusCombo'];
    ts.isPause = settings['pauseWhenCalc'];
    ts.receiveOneItem = settings['receiveHeartsOneByOne'];
    ts.receiveSecondItem = settings['receiveHeartsSkipFirst'] || false;
    ts.recordReceive = settings['recordSender'];
    ts.sentToZero = settings['sendHeartsToZeroScore'];
    ts.receiveCheckLimit = settings['mailOpenMax'];
    ts.clearBubbles = settings['clearBubbles'];
    ts.skillInterval = settings['skillWaitingTime'] * 1000;
    ts.skillLevel = settings['skillLevel'];
    ts.skillType = settings['skillType'];
    ts.skillAutoTap = !!settings['skillAutoTap'];
    ts.handleLongSkillAnimations = settings['handleLongSkillAnimations'] || false;
    ts.unlockLevelHoursWait = settings["unlockLevelHoursWait"];
    ts.sendHearts = settings['sendHeartsAuto'];
    ts.showHeartLog = true;
    ts.keepRuby = settings['receiveHeartsSkipRuby'];
    ts.sendHeartMaxDuring = settings['sendHeartsMaxRuntime'] * 60 * 1000;
    ts.useFan = settings['useFan'];
    if (typeof settings['maxChainsPerScan'] === 'number' && settings['maxChainsPerScan'] >= 1) {
        ts.maxChainsPerScan = settings['maxChainsPerScan'];
    }
    if (settings['recordSenderEnlarge']) {
        ts.resizeRatio = 1;
    }
    var yOffset = ts.receiveSecondItem ? 202 : 0;
    Button.outReceiveOne.y = Button.outReceiveOneBase.y + yOffset;
    Button.outReceiveOneRuby.y = Button.outReceiveOneRubyBase.y + yOffset;
    Button.outReceiveOneAd.y = Button.outReceiveOneAdBase.y + yOffset;
    Button.outReceiveNameFrom.y = Button.outReceiveNameFromBase.y + yOffset;
    Button.outReceiveNameTo.y = Button.outReceiveNameToBase.y + yOffset;
    if (ts.recordReceive) {
        ts.readRecord();
    }
    if (ts.record["hearts_count" /* RecordKey.HeartsCount */] === undefined) {
        ts.record["hearts_count" /* RecordKey.HeartsCount */] = {
            receivedCount: 0,
            sentCount: 0
        };
    }
    Config.debugLogs = settings['debugLogs'];
    Config.maxChain = settings['maxChain'];
    ts.autobuyBoxes = settings['autobuyBoxes'];
    ts.noSkillLastFeverSec = settings['noSkillLastFeverSec'];
    ts.claimAllWithoutCoins = settings['claimAllWithoutCoins'];
    ts.tsumMonitorUrl = settings['tsumMonitorUrl'] || "";
    ts.tsumAppRestartFrequency = settings['tsumAppRestartFrequency'];
    if (!checkFunction(TsumTaskController)) {
        console.log("File lose...");
        return;
    }
    gTaskController = new TsumTaskController();
    if (ts.tsumMonitorUrl.length > 0) {
        gTaskController.newTask('requestTsumMonitor', ts.taskRequestTsumMonitor.bind(ts), 30 * 1000, 0);
    }
    gTaskController.newTask('taskAutoBuyBoxes', ts.taskAutoBuyBoxes.bind(ts), 60 * 1000, 0);
    if (settings['receiveHeartsOneByOne']) {
        gTaskController.newTask('receiveOneItem', ts.taskReceiveOneItem.bind(ts), settings['mailMinWait'] * 60 * 1000, 0);
    }
    if (settings['receiveAllHearts']) {
        gTaskController.newTask('receiveItems', ts.taskReceiveAllItems.bind(ts), settings['receiveAllHeartsMinWait'] * 60 * 1000, 0);
    }
    if (settings['sendHeartsAuto']) {
        gTaskController.newTask('sendHearts', ts.taskSendHearts.bind(ts), settings['sendHeartsMinWait'] * 60 * 1000, 0);
    }
    if (settings['autoLaunchApp'] && settings['tsumAppRestartFrequency'] > 0) {
        gTaskController.newTask('taskTsumAppRestart', ts.taskTsumAppRestart.bind(ts), settings['tsumAppRestartFrequency'] * 60 * 60 * 1000, 0, true);
    }
    // Layer 2: stuck watchdog. Restarts the game app if no progress for stuckTimeoutMs.
    // gTaskController.newTask('taskWatchdog', ts.taskWatchdog.bind(ts), 10 * 1000, 0);
    if (checkFunction(outRange)) {
        // Click Assist replaces auto-play: the user picks the tsum, the script
        // draws the chain. Mutually exclusive with autoPlayGame.
        if (settings['clickAssist']) {
            gTaskController.newTask('taskClickAssist', ts.taskClickAssist.bind(ts), 3 * 1000, 0);
        }
        else if (settings['autoPlayGame']) {
            if (settings['unlockLevelHoursWait'] > 0) {
                gTaskController.newTask('autoUnlockLevel', ts.taskAutoUnlockLevel.bind(ts), settings['unlockLevelHoursWait'] * 60 * 60 * 1000, 0);
            }
            gTaskController.newTask('taskPlayGameQuick', ts.taskPlayGameQuick.bind(ts), 3 * 1000, 0);
        }
    }
    sleep(500);
    gTaskController.start();
    log(ts.logs.TaskControllerStop);
}
function stop() {
    if (ts != null) {
        log(ts.logs.stop);
        sleep(500);
        ts.isRunning = false;
        sleep(2000);
        // loop stop here...
        if (ts.recordReceive) {
            ts.releaseRecord();
        }
    }
    if (gTaskController !== undefined)
        gTaskController.removeAllTasks();
    if (gTaskController !== undefined)
        gTaskController.stop();
    ts = undefined;
}
// Renders record.txt as a standalone HTML table. Reached from the settings UI
// via runScriptCallback('genRecordTable();', ...), so it has to stay a global.
function genRecordTable() {
    console.log("Generate Record...");
    var recordFile = getStoragePath() + "/tsum_record/record.txt";
    var txt = readFile(recordFile);
    var record = {};
    if (txt !== undefined && txt !== "") {
        try {
            record = JSON.parse(txt);
        }
        catch (e) {
            return "Can not parse record.txt " + JSON.stringify(e);
        }
    }
    else {
        return "Can not read record.txt";
    }
    // enhance records with total and average hearts per filename
    var dayMapCount = {};
    var renderRecords = [];
    // Reused across the sibling loops below (previously function-scoped vars).
    var filename, dayTime, j;
    for (filename in record) {
        (function (filename) {
            if (filename !== "hearts_count" /* RecordKey.HeartsCount */) {
                var totalDay = 0;
                var totalCount = 0;
                var recordElement = record[filename];
                for (var dayTime_1 in recordElement.receiveCounts) {
                    var dayCount = recordElement.receiveCounts[dayTime_1];
                    if (dayMapCount[+dayTime_1] === undefined) {
                        dayMapCount[+dayTime_1] = 0;
                    }
                    dayMapCount[+dayTime_1] += dayCount;
                    totalDay++;
                    totalCount += dayCount;
                }
                var avg = 0;
                if (totalDay !== 0) {
                    avg = (totalCount / totalDay).toFixed(1);
                }
                recordElement.all = totalCount;
                recordElement.avg = avg;
                recordElement.filename = filename;
                renderRecords.push(recordElement);
            }
        })(filename);
    }
    // sort records descending by total
    renderRecords.sort(function (a, b) {
        // `all` and `filename` are stamped onto every entry by the loop above, so
        // they are present here even though the persisted shape has them optional.
        return b.all - a.all;
    });
    // create sorted dayTime array
    var dayTimesSorted = [];
    for (dayTime in dayMapCount) {
        if (dayMapCount.hasOwnProperty(dayTime)) {
            dayTimesSorted.push(dayTime);
        }
    }
    dayTimesSorted.sort(function (a, b) {
        return +a - +b;
    });
    // render records
    var html = "<html><body><style>table { border-collapse: collapse; } th, td { border: solid 1px black; text-align: right; padding: 4px 10px 4px 10px; } .records td:nth-child(2n+5), .records th:nth-child(2n+5) { background-color: lightgray; } .all { background-color: darkseagreen; } .avg { background-color: lightsteelblue; border-right-width: 5px; }</style>";
    html += "<table class='records'>";
    html += "<tr><th>UserImage</th><th class='all'>All</th><th class='avg'>Avg</th>";
    for (j = 0; j < dayTimesSorted.length; j++) {
        dayTime = dayTimesSorted[j];
        html += '<th>' + getDayTimeString(new Date(+dayTime * (24 * 60 * 60 * 1000))) + '</th>';
    }
    html += "</tr>";
    for (var i = 0; i < renderRecords.length; i += 1) {
        var renderRecord = renderRecords[i];
        filename = renderRecord.filename;
        html += "<tr>";
        // user image
        var filePath = getStoragePath() + "/tsum_record/" + filename;
        var tmpImg = openImage(filePath);
        var base64 = void 0;
        try {
            base64 = getBase64FromImage(tmpImg);
        }
        finally {
            releaseImage(tmpImg);
        }
        html += "<td><img src='data:image/png;base64," + base64 + "' /></td>";
        var totalDay = 0;
        var totalCount = 0;
        var tmpHtml = "";
        for (j = 0; j < dayTimesSorted.length; j++) {
            dayTime = dayTimesSorted[j];
            // The counts are written as numbers, but parseInt has always guarded this
            // read against a hand-edited record.txt; String() keeps that coercion
            // explicit rather than relying on parseInt's own.
            var dayCount = parseInt(String(renderRecord.receiveCounts[dayTime])) || 0;
            tmpHtml += '<td>' + dayCount + '</td>';
            totalDay++;
            totalCount += dayCount;
        }
        var avg = 0;
        if (totalDay !== 0) {
            avg = (totalCount / totalDay).toFixed(1);
        }
        html += "<td class='all'>" + totalCount + "</td>";
        html += "<td class='avg'>" + avg + "</td>";
        html += tmpHtml;
        html += "</tr>";
    }
    html += "</table>";
    html += "<br /> <br />";
    // day count
    html += "<table>";
    html += "<tr><th>Date</th><th>Hearts</th></tr>";
    for (j = 0; j < dayTimesSorted.length; j++) {
        dayTime = dayTimesSorted[j];
        var date = new Date(+dayTime * (24 * 60 * 60 * 1000));
        html += "<tr>";
        html += "<td>" + getDayTimeString(date) + "</td>";
        html += "<td>" + dayMapCount[+dayTime] + "</td>";
        html += "</tr>";
    }
    html += "</table>";
    html += "</body></html>";
    var recordName = getRecordFilename();
    var oPath = getStoragePath() + "/tsum_record/" + recordName;
    writeFile(oPath, html);
    return "Download: " + getStoragePath() + "/tsum_record to PC" + "<br />Open: " + recordName;
}
function getDayTimeString(d) {
    return (d.getMonth() + 1) + '/' + d.getDate();
}
function getRecordFilename() {
    var d = new Date();
    return 'recordTable_' + d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate() + '_' + d.getHours() + '-' + d.getMinutes() + '-' + d.getSeconds() + '.html';
}
// input: rgb in [0,255], out: h in [0,360) and s,v in [0,100]
function rgb2hsv(rgb) {
    var r = rgb.r / 255;
    var g = rgb.g / 255;
    var b = rgb.b / 255;
    var v = Math.max(r, g, b), c = v - Math.min(r, g, b);
    var h = c && ((v === r) ? (g - b) / c : ((v === g) ? 2 + (b - r) / c : 4 + (r - g) / c));
    return { h: 60 * (h < 0 ? h + 6 : h), s: Math.round(v && c / v * 100), v: Math.round(v * 100) };
}
